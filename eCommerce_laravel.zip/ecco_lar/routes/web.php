<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\MasterAdminController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// Route::get('/', function () {
//     return view('welcome');
// });

route::get('/', [HomeController::class, 'index']);

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

route::get('/redirect', [HomeController::class, 'redirect']);

// Masteradmin Routes
route::get('/masteradmin', [HomeController::class, 'masteradmin']);
route::get('/admindetails', [MasterAdminController::class, 'admindetails'])->name('masteradmin.admindetails');
route::get('/userdetails', [MasterAdminController::class, 'userdetails'])->name('masteradmin.userdetails');
route::get('/edit_admin/{id}', [MasterAdminController::class, 'edit_admin']);
route::get('/edit_user/{id}', [MasterAdminController::class, 'edit_user']);
// route::get('/delete_admin/{id}', [AdminController::class, 'delete_admin']);
Route::get('/delete_admin/{id}', [MasterAdminController::class, 'delete_admin']);
Route::get('/delete_User/{id}', [MasterAdminController::class, 'delete_user']);
route::get('/create_new_web', [MasterAdminController::class, 'create_new_web']);

// For updating admin data
Route::post('/update_admin/{id}', [MasterAdminController::class, 'update_admin'])->name('update_admin');
Route::put('/update_admin/{id}', [MasterAdminController::class, 'update_admin'])->name('update_admin');


Route::post('/update_user/{id}', [MasterAdminController::class, 'update_user'])->name('update_user');
Route::put('/update_user/{id}', [MasterAdminController::class, 'update_user'])->name('update_user');


route::get('/redirect_admindetails', [MasterAdminController::class, 'redirect_admindetails']);

// route::put('/user/{id}/updateRole', [::class, 'updateRole'])->name('updateRole');

Route::post('/users/toggle-type/{id}', [MasterAdminController::class, 'toggleUserType']);

Route::post('/updateUserType/{id}', [MasterAdminController::class, 'updateUserType'])->name('updateUserType');
route::get('/view_catagory', [AdminController::class, 'view_catagory']);
route::post('/add_catagory', [AdminController::class, 'add_catagory']);
route::get('/delete_catagory/{id}', [AdminController::class, 'delete_catagory']);

route::get('/view_product', [AdminController::class, 'view_product']);
route::post('/add_product', [AdminController::class, 'add_product']);
route::get('/show_product', [AdminController::class, 'show_product'])->name('show.product');

route::get('/delete_product/{id}', [AdminController::class, 'delete_product']);
route::get('/update_product/{id}', [AdminController::class, 'update_product']);
route::put('/update_product_confirm/{id}', [AdminController::class, 'update_product_confirm'])->name('update.product');
route::get('/order', [AdminController::class, 'order']);
route::get('/delivered/{id}', [AdminController::class, 'delivered']);
route::get('/print_pdf/{id}', [AdminController::class, 'print_pdf']);
route::get('/search', [AdminController::class, 'searchdata']);
Route::get('/cancel/{id}', [AdminController::class, 'cancel'])->name('order.cancel');
Route::get('/products_by_category/{id}', [ProductController::class, 'showByCategory'])->name('product.product_by_category');

route::get('/order_details/{id}', [AdminController::class, 'order_details']);
Route::get('/products', [ProductController::class, 'index'])->name('product.index');
route::get('/product_details/{id}', [HomeController::class, 'product_details']);
route::post('/add_cart/{id}', [HomeController::class, 'add_cart']);
route::get('/show_cart', [HomeController::class, 'show_cart']);
route::get('/remove_cart/{id}', [HomeController::class, 'remove_cart']);
// route::get('/contact', [HomeController::class, 'contact']);

route::get('/cash_order', [HomeController::class, 'cash_order']);
route::get('/stripe/{totalprice}', [HomeController::class, 'stripe']);
route::get('/show_order', [HomeController::class, 'show_order']);
route::get('/cancel_order/{id}', [HomeController::class, 'cancel_order']);

route::post('/add_comment', [HomeController::class, 'add_comment']);
route::post('/add_reply', [HomeController::class, 'add_reply']);

Route::get('/contact', [HomeController::class, 'showForm'])->name('contact.form');
Route::post('/submit-contact', [HomeController::class, 'submitContact'])->name('submit-contact');

Route::post('/coupons/create', [CouponController::class, 'create'])->name('coupons.create');
Route::post('/coupons/validate', [CouponController::class, 'validateCoupon'])->name('coupons.validate');
route::get('/coupon_delete/{id}', [CouponController::class, 'coupon_delete']);
Route::get('/edit_coupon/{id}', [CouponController::class, 'edit_coupon'])->name('edit_coupon');

route::get('/show_coupon', [CouponController::class, 'show_coupon'])->name('show_coupon');

Route::get('/delivered/{id}', [OrderController::class, 'markAsDelivered'])->name('order.delivered');


Route::get('/coupons', function () {
    return view('coupons');
});


// Location Routes
Route::get('/add_country', [LocationController::class, 'add_country'])->name('location.add_country');
Route::get('/add_state', [LocationController::class, 'add_state'])->name('location.add_state');
Route::get('/add_city', [LocationController::class, 'add_city'])->name('location.add_city');

Route::get('/edit_country/{id}', [LocationController::class, 'edit_country'])->name('location.edit_country');
Route::post('/edit_country/{id}', [LocationController::class, 'update_country'])->name('location.update_country');

route::get('/edit_state/{id}', [LocationController::class, 'edit_state'])->name('location.edit_state');
Route::post('/edit_state/{id}', [LocationController::class, 'update_state'])->name('location.update_state');

route::get('/edit_city/{id}', [LocationController::class, 'edit_city'])->name('location.edit_city');
Route::post('/edit_city/{id}', [LocationController::class, 'update_city'])->name('location.update_city');



Route::patch('/countries/{id}/toggle', [LocationController::class, 'toggle'])->name('countries.toggle');


// AJAX routes to fetch states and cities
Route::get('/get-states/{country_id}', [LocationController::class, 'getStates']);
Route::get('/get-cities/{state_id}', [LocationController::class, 'getCities']);

Route::post('/store-country', [LocationController::class, 'storeCountry'])->name('store-country');
Route::post('/store-state', [LocationController::class, 'storeState'])->name('store-state');
Route::post('/store-city', [LocationController::class, 'storeCity']);
Route::get('/states/{countryId}', [LocationController::class, 'getStates']);


Route::get('/countries/{id}/edit', [LocationController::class, 'edit_country'])->name('edit_country');
Route::post('/countries/{id}/toggle', [LocationController::class, 'toggleCountryStatus'])->name('toggle_country_status');

Route::put('/edit_country/{id}', [LocationController::class, 'update_country'])->name('update_country');

Route::get('/countries/{id}/edit', [LocationController::class, 'edit_state'])->name('edit_state');
Route::post('/states/{id}/toggle', [LocationController::class, 'toggleStateStatus'])->name('toggle_country_status');

Route::put('/edit_state/{id}', [LocationController::class, 'update_state'])->name('update_state');


Route::get('/countries/{id}/edit', [LocationController::class, 'edit_city'])->name('edit_city');
Route::put('/edit_city/{id}', [LocationController::class, 'update_city'])->name('update_city');
Route::post('/cities/{id}/toggle', [LocationController::class, 'toggleCityStatus'])->name('toggle_country_status');


route::get('/delete_country/{id}', [LocationController::class, 'delete_country']);
route::get('/delete_state/{id}', [LocationController::class, 'delete_state']);
route::get('/delete_city/{id}', [LocationController::class, 'delete_city']);

// ceate new web routes

route::post('/add_new_web', [MasterAdminController::class, 'add_new_web']);
Route::get('/states/{countryId}', [MasterAdminController::class, 'getStates']);
Route::get('/cities/{stateId}', [MasterAdminController::class, 'getCities']);
Route::get('/cities/{state}', [MasterAdminController::class, 'getCities']);
Route::get('/countries', [MasterAdminController::class, 'getCountries']);
Route::get('/states/{countryId}', [MasterAdminController::class, 'getStates']);
Route::get('/cities/{stateId}', [MasterAdminController::class, 'getCities']);
