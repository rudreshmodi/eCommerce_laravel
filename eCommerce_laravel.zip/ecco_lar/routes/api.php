<?php

use App\Http\Controllers\ApiAdminController;
use App\Http\Controllers\ApiApiHomeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiHomeController;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/products', [ApiHomeController::class, 'index']);
    Route::get('/product-details/{id}', [ApiHomeController::class, 'productDetails']);
    Route::post('/contact', [ApiHomeController::class, 'submitContact']);
    Route::get('/redirect', [ApiHomeController::class, 'redirect']);
    Route::get('/product/{id}', [ApiHomeController::class, 'productDetails']);
    Route::post('/cart/add/{id}', [ApiHomeController::class, 'addCart']);
    Route::get('/cart', [ApiHomeController::class, 'showCart']);
    Route::delete('/cart/remove/{id}', [ApiHomeController::class, 'removeCart']);
    Route::post('/order/cash', [ApiHomeController::class, 'cashOrder']);
    Route::get('/orders', [ApiHomeController::class, 'showOrder']);
    Route::put('/order/cancel/{id}', [ApiHomeController::class, 'cancelOrder']);
    Route::post('/comment', [ApiHomeController::class, 'addComment']);
    Route::post('/reply', [ApiHomeController::class, 'addReply']);
});


Route::get('/products', [ApiHomeController::class, 'index']); // List all products
Route::get('/product-details/{id}', [ApiHomeController::class, 'product_details']); // Get product details
Route::post('/add-cart/{id}', [ApiHomeController::class, 'add_cart']); // Add product to cart
Route::get('/show-cart', [ApiHomeController::class, 'showCart']); // Show cart
Route::delete('/remove-cart/{id}', [ApiHomeController::class, 'remove_cart']); // Remove cart item
Route::post('/cash-order', [ApiHomeController::class, 'cash_order']); // Place a cash order
Route::post('/add-comment', [ApiHomeController::class, 'add_comment']); // Add a comment
Route::post('/add-reply', [ApiHomeController::class, 'add_reply']); // Add a reply to a comment
Route::post('/contact', [ApiHomeController::class, 'submitContact']); // Submit contact form


Route::middleware('auth:api')->post('/update-product/{id}', [ProductController::class, 'update_product']);
Route::middleware('auth:api')->delete('/delete-product/{id}', [ProductController::class, 'delete_product']);


Route::get('/dashboard', [ApiAdminController::class, 'showDashboard']);

Route::get('/categories', [ApiAdminController::class, 'view_catagory']);
Route::post('/categories', [ApiAdminController::class, 'add_catagory']);
Route::delete('/categories/{id}', [ApiAdminController::class, 'delete_catagory']);

Route::get('/products', [ApiAdminController::class, 'show_product']);
Route::post('/products', [ApiAdminController::class, 'add_product']);
Route::get('/products/{id}', [ApiAdminController::class, 'update_product']);
Route::put('/products/{id}', [ApiAdminController::class, 'update_product_confirm']);
Route::delete('/products/{id}', [ApiAdminController::class, 'delete_product']);

Route::get('/orders', [ApiAdminController::class, 'order']);
Route::get('/orders/{id}', [ApiAdminController::class, 'order_details']);
Route::put('/orders/{id}/delivered', [ApiAdminController::class, 'delivered']);
Route::put('/orders/{id}/cancel', [ApiAdminController::class, 'cancel']);
Route::get('/orders/{id}/print', [ApiAdminController::class, 'print_pdf']);
Route::get('/orders/search', [ApiAdminController::class, 'searchdata']);

Route::post('/contact', [ApiHomeController::class, 'submitContact']);
Route::post('/cart/{id}', [ApiHomeController::class, 'addCart']);
Route::post('/order/cash', [ApiHomeController::class, 'cashOrder']);
Route::get('/orders', [ApiHomeController::class, 'showOrder']);
Route::post('/order/cancel/{id}', [ApiHomeController::class, 'cancelOrder']);
Route::delete('/category/{id}', [ApiAdminController::class, 'delete_catagory']);

//GET http://localhost:8000/api/products
//GET http://localhost:8000/api/product-details/6
//GET http://localhost:8000/api/categories
//GET http://localhost:8000/api/categories/1
//POST http://localhost:8000/api/contact
//DELETE http://localhost:8000/api/category/15

//GET http://localhost:8000/api/dashboard
//GET http://localhost:8000/api/orders/32
//PUT http://localhost:8000/api/orders/32/delivered
//PUT http://localhost:8000/api/orders/33/cancel
//GET http://localhost:8000/api/orders/34/print