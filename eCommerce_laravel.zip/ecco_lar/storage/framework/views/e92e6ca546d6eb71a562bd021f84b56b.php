<div class="main-container">
    <div class="xs-pd-20-10 pd-ltr-20">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Overall View</h2>
        </div>

        <div class="row pb-10">
            <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
                <a href="<?php echo e(url('/admindetails')); ?>" style="text-decoration: none; color:white;">
                    <div class="card-box height-100-p widget-style3">
                        <div class="d-flex flex-wrap">
                            <div class="widget-data">
                                <div class="weight-700 font-24 text-dark"><?php echo e($total_admin); ?></div>
                                <div class="font-14 text-secondary weight-500">
                                    Total Admin
                                </div>
                            </div>
                            <div class="widget-icon">
                                <div class="icon" data-color="#00eccf">
                                    <span class="micon bi bi-person-gear" style="font-size: 30px;"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
                <a href="<?php echo e(url('/userdetails')); ?>" style="text-decoration: none; color:white;">
                    <div class="card-box height-100-p widget-style3">
                        <div class="d-flex flex-wrap">
                            <div class="widget-data">
                                <div class="weight-700 font-24 text-dark"><?php echo e($total_user); ?></div>
                                <div class="font-14 text-secondary weight-500">
                                    Total User's
                                </div>
                            </div>
                            <div class="widget-icon">
                                <div class="icon" data-color="#ff5b5b">
                                    <span class="micon bi bi-people"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
                <div class="card-box height-100-p widget-style3">
                    <div class="d-flex flex-wrap">
                        <div class="widget-data">
                            <div class="weight-700 font-24 text-dark">400+</div>
                            <div class="font-14 text-secondary weight-500">
                                Total Doctor
                            </div>
                        </div>
                        <div class="widget-icon">
                            <div class="icon">
                                <i
                                    class="icon-copy fa fa-stethoscope"
                                    aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
                <div class="card-box height-100-p widget-style3">
                    <div class="d-flex flex-wrap">
                        <div class="widget-data">
                            <div class="weight-700 font-24 text-dark">$ <?php echo e($total_revenue); ?></div>
                            <div class="font-14 text-secondary weight-500">Earning</div>
                        </div>
                        <div class="widget-icon">
                            <div class="icon" data-color="#09cc06">
                                $
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-4 col-md-6 mb-20">
                <div class="card-box height-100-p pd-20 min-height-200px">
                    <div class="d-flex justify-content-between pb-10">
                        <div class="h5 mb-0">Top Doctors</div>
                        <div class="dropdown">
                            <a
                                class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
                                data-color="#1b3133"
                                href="#"
                                role="button"
                                data-toggle="dropdown">
                                <i class="dw dw-more"></i>
                            </a>
                            <div
                                class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                <a class="dropdown-item" href="#"><i class="dw dw-eye"></i> View</a>
                                <a class="dropdown-item" href="#"><i class="dw dw-edit2"></i> Edit</a>
                                <a class="dropdown-item" href="#"><i class="dw dw-delete-3"></i> Delete</a>
                            </div>
                        </div>
                    </div>
                    <div class="user-list">
                        <ul>
                            <li class="d-flex align-items-center justify-content-between">
                                <div class="name-avatar d-flex align-items-center pr-2">
                                    <div class="avatar mr-2 flex-shrink-0">
                                        <img
                                            src="<?php echo e(asset('masteradmin/images/photo1.jpg')); ?>"
                                            class="border-radius-100 box-shadow"
                                            width="50"
                                            height="50"
                                            alt="" />
                                    </div>
                                    <div class="txt">
                                        <span
                                            class="badge badge-pill badge-sm"
                                            data-bgcolor="#e7ebf5"
                                            data-color="#265ed7">4.9</span>
                                        <div class="font-14 weight-600">Dr. Neil Wagner</div>
                                        <div class="font-12 weight-500" data-color="#b2b1b6">
                                            Pediatrician
                                        </div>
                                    </div>
                                </div>
                                <div class="cta flex-shrink-0">
                                    <a href="#" class="btn btn-sm btn-outline-primary">Schedule</a>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-20">
                <div class="card-box height-100-p pd-20 min-height-200px">
                    <div class="d-flex justify-content-between">
                        <div class="h5 mb-0">Diseases Report</div>
                        <div class="dropdown">
                            <a
                                class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
                                data-color="#1b3133"
                                href="#"
                                role="button"
                                data-toggle="dropdown">
                                <i class="dw dw-more"></i>
                            </a>
                            <div
                                class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                <a class="dropdown-item" href="#"><i class="dw dw-eye"></i> View</a>
                                <a class="dropdown-item" href="#"><i class="dw dw-edit2"></i> Edit</a>
                                <a class="dropdown-item" href="#"><i class="dw dw-delete-3"></i> Delete</a>
                            </div>
                        </div>
                    </div>

                    <div id="diseases-chart"></div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 mb-20">
                <div class="card-box height-100-p pd-20 min-height-200px">
                    <div class="max-width-300 mx-auto">
                        <img src="<?php echo e(asset('masteradmin/images/upgrade.svg')); ?>" alt="" />
                    </div>
                    <div class="text-center">
                        <div class="h5 mb-1">Upgrade to Pro</div>
                        <div
                            class="font-14 weight-500 max-width-200 mx-auto pb-20"
                            data-color="#a6a6a7">
                            You can enjoy all our features by upgrading to pro.
                        </div>
                        <a href="#" class="btn btn-primary btn-lg">Upgrade</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-box pb-10">
            <div class="h5 pd-20 mb-0">Recent Patient</div>
            <table class="data-table table nowrap">
                <thead>
                    <tr>
                        <th class="table-plus">Name</th>
                        <th>Gender</th>
                        <th>Weight</th>
                        <th>Assigned Doctor</th>
                        <th>Admit Date</th>
                        <th>Disease</th>
                        <th class="datatable-nosort">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="table-plus">
                            <div class="name-avatar d-flex align-items-center">
                                <div class="avatar mr-2 flex-shrink-0">
                                    <img
                                        src="<?php echo e(asset('masteradmin/images/photo4.jpg')); ?>"
                                        class="border-radius-100 shadow"
                                        width="40"
                                        height="40"
                                        alt="" />
                                </div>
                                <div class="txt">
                                    <div class="weight-600">Jennifer O. Oster</div>
                                </div>
                            </div>
                        </td>
                        <td>Female</td>
                        <td>45 kg</td>
                        <td>Dr. Callie Reed</td>
                        <td>19 Oct 2020</td>
                        <td>
                            <span
                                class="badge badge-pill"
                                data-bgcolor="#e7ebf5"
                                data-color="#265ed7">Typhoid</span>
                        </td>
                        <td>
                            <div class="table-actions">
                                <a href="#" data-color="#265ed7"><i class="icon-copy dw dw-edit2"></i></a>
                                <a href="#" data-color="#e95959"><i class="icon-copy dw dw-delete-3"></i></a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td class="table-plus">
                            <div class="name-avatar d-flex align-items-center">
                                <div class="avatar mr-2 flex-shrink-0">
                                    <img
                                        src="<?php echo e(asset('masteradmin/images/photo5.jpg')); ?>"
                                        class="border-radius-100 shadow"
                                        width="40"
                                        height="40"
                                        alt="" />
                                </div>
                                <div class="txt">
                                    <div class="weight-600">Doris L. Larson</div>
                                </div>
                            </div>
                        </td>
                        <td>Male</td>
                        <td>76 kg</td>
                        <td>Dr. Ren Delan</td>
                        <td>22 Jul 2020</td>
                        <td>
                            <span
                                class="badge badge-pill"
                                data-bgcolor="#e7ebf5"
                                data-color="#265ed7">Dengue</span>
                        </td>
                        <td>
                            <div class="table-actions">
                                <a href="#" data-color="#265ed7"><i class="icon-copy dw dw-edit2"></i></a>
                                <a href="#" data-color="#e95959"><i class="icon-copy dw dw-delete-3"></i></a>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="title pb-20 pt-20">
            <h2 class="h3 mb-0">Quick Start</h2>
        </div>

        <div class="row">
            <div class="col-md-4 mb-20">
                <a href="#" class="card-box d-block mx-auto pd-20 text-secondary">
                    <div class="img pb-30">
                        <img src="<?php echo e(asset('masteradmin/images/medicine-bro.svg')); ?>" alt="" />
                    </div>
                    <div class="content">
                        <h3 class="h4">Services</h3>
                        <p class="max-width-200">
                            We provide superior health care in a compassionate maner
                        </p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-20">
                <a href="#" class="card-box d-block mx-auto pd-20 text-secondary">
                    <div class="img pb-30">
                        <img src="<?php echo e(asset('masteradmin/images/remedy-amico.svg')); ?>" alt="" />
                    </div>
                    <div class="content">
                        <h3 class="h4">Medications</h3>
                        <p class="max-width-200">
                            Look for prescription and over-the-counter drug information.
                        </p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-20">
                <a href="#" class="card-box d-block mx-auto pd-20 text-secondary">
                    <div class="img pb-30">
                        <img src="<?php echo e(asset('masteradmin/images/paper-map-cuate.svg')); ?>" alt="" />
                    </div>
                    <div class="content">
                        <h3 class="h4">Locations</h3>
                        <p class="max-width-200">
                            Convenient locations when and where you need them.
                        </p>
                    </div>
                </a>
            </div>
        </div>

        <div class="footer-wrap pd-20 mb-20 card-box">
            <!-- DeskApp - Bootstrap 4 Admin Template By
                    <a href="https://github.com/dropways" target="_blank">Ankit Hingarajiya</a> -->
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="<?php echo e(asset('masteradmin/scripts/js/core.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/scripts/js/script.min.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/scripts/js/process.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/scripts/js/layout-settings.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/src/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/js/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/js/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/js/datatables/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/js/datatables/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('masteradmin/js/dashboard3.js')); ?>"></script>



</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/masteradmin/body.blade.php ENDPATH**/ ?>