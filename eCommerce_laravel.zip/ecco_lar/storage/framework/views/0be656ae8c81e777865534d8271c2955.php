<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Super Admin Dashboard</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('masteradmin/images/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('masteradmin/images/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('masteradmin/images/favicon-16x16.png')); ?>" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Bootstrap & Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />

    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/css/styles/core.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/css/style.css')); ?>" />

    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/src/plugins/datatables/css/dataTables.bootstrap4.min.css')); ?>" />

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</head>

<style>
    body {
        font-family: 'Inter', sans-serif;
        background-color: #f8f9fa;
        color: #495057;
    }

    .container {
        margin-top: 20px;
    }

    .card-box {
        border: none;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        background-color: #ffffff;
        padding: 20px;
    }

    .btn-submit {
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 15px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn-submit:hover {
        background-color: #0056b3;
    }

    h2 {
        color: #007bff;
    }

    label {
        font-weight: 600;
    }
</style>

<body>
    <?php echo $__env->make('masteradmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('masteradmin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="pd-20 card-box mb-30 " style="margin-left:21%; margin-top:80px;">

        <div class="container">
            <div class="card-box mb-30">
                <div class="d-flex align-items-center mb-3">
                    <a class="nav-link refresh-link" href="<?php echo e(url('/add_state')); ?>" title="Back">
                        <div class="icon-wrapper">
                            <i class="fa-solid fa-arrow-left fa-xl" style="color: #007bff;"></i>
                            <span class="icon-text">Back</span>
                        </div>
                    </a>
                </div>

                <h2>Edit State</h2>
                <form action="<?php echo e(route('update_state', $state->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="country">Country Name:</label>
                                <select name="country_id" id="country" class="form-control" required>
                                    <option style="background-color:#a7ccc3;" value="">Select Country</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="state">State Name:</label>
                                <input type="text" name="state" value="<?php echo e($state->state); ?>" id="state" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Update State</button>
                </form>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                // JavaScript code for handling toggles and modals can go here
            });
        </script>
    </div>
    <script>
        $(document).ready(function() {
            // Toggle submenu on click
            $('.dropdown-toggle').on('click', function() {
                // Close other open submenus
                $('.submenu').not($(this).next()).slideUp();
                // Toggle the current submenu
                $(this).next('.submenu').slideToggle();
            });
        });
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/location/edit_state.blade.php ENDPATH**/ ?>