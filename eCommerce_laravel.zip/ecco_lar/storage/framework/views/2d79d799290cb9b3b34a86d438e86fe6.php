<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link href="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css"
        integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="">
    <!-- End layout styles -->
    <link href="<?php echo e(asset('admin/assets/images/favicon.png')); ?>" rel="stylesheet" />

    <style>
        .div_center {
            text-align: center;
            padding-top: 30px;
        }

        .h2_font {
            font-size: 30px;
            padding-bottom: 30px;
        }

        .input_color {
            color: black;
        }

        .center {
            margin: auto;
            width: 50%;
            text-align: center;
            margin-top: 30px;
            border: 2px solid white;
        }

        .label {
            display: inline-block;
            width: 200px;
        }

        .div_design {
            padding-bottom: 15px;
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table img {
            border-radius: 5px;
            border: 1px solid #ddd;
            padding: 3px;
        }

        thead th {
            text-align: center;
            font-weight: bold;
        }

        td {
            vertical-align: middle;
            text-align: center;
        }

        .text {
            color: #ddd;
        }

        .search-form {
            width: 100%;
            max-width: 600px;
            /* Limit maximum width */
            margin: 20px auto;
            /* Center the form */
            display: flex;
            align-items: center;
            border-radius: 5px;
            background-color: #2a2a2a;
            /* Dark background for the form */
            padding: 10px;
            /* Padding around the form */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
            /* Subtle shadow */
        }

        .search-input {
            flex: 1;
            /* Take remaining space */
            border-radius: 25px 0 0 25px;
            border: 2px solid #74C0FC;
            /* Light blue border */
            padding: 10px 20px;
            /* Adjust padding for comfort */
            font-size: 16px;
            /* Increase font size for better readability */
            color: white;
            /* Text color */
            background-color: #1a1a1a;
            /* Dark input background */
        }

        .search-input::placeholder {
            color: #6c757d;
            /* Placeholder color */
            font-style: italic;
        }

        .btn-search {
            border-radius: 0 25px 25px 0;
            /* Rounded right corners */
            border: 2px solid #74C0FC;
            /* Match the border color with the input */
            background-color: #74C0FC;
            /* Light blue background */
            color: white;
            /* White text color */
            padding: 10px 15px;
            /* Adjust padding */
            font-size: 16px;
            /* Font size */
            transition: background-color 0.3s, border-color 0.3s;
            /* Smooth transition */
        }

        .btn-search:hover {
            background-color: #58a3db;
            /* Darker blue on hover */
            border-color: #58a3db;
            /* Darker blue on hover */
        }

        .order-row {
            background-color: #343a40;
            /* Dark background for order rows */
            transition: background-color 0.3s;
            /* Smooth transition */
        }

        .order-row:hover {
            background-color: #495057;
            /* Darker on hover */
        }

        .text-white {
            color: white !important;
            /* Force white text color */
        }

        .custom-btn {
            width: 90px;
            height: 35px;
            font-size: 16px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .nav-link:hover {
            background-color: rgba(0, 123, 255, 0.1);
        }

        .icon-wrapper {
            display: flex;
            align-items: center;
            margin-left: 10px;
        }

        .icon-text {
            margin-left: 8px;
            font-weight: 500;
            color: #58a3db;
            /* Change to your desired color */
        }

        .wrap-text {
            white-space: normal;
            /* Allow text to wrap */
            word-wrap: break-word;
            /* Break long words */
            overflow-wrap: break-word;
            /* Support for browsers */
        }

        /* Add this to remove any default margin on tables */
        table {
            margin: 0;
        }
    </style>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- page-body-wrapper ends -->
        <div class="main-panel">
            <div class="content-wrapper">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    <?php echo e(session()->get('message')); ?>


                </div>
                <?php endif; ?>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
                    rel="stylesheet">

                <h4 class="mb-1" style="color: white;">Order Details</h4>
                <form action="<?php echo e(url('search')); ?>" method="get"
                    class="nav-link mt-2 mt-md-0 d-none d-lg-flex search-form align-items-center">
                    <div class="input-group">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="search" class="form-control search-input"
                            placeholder="Search Orders" aria-label="Search products">
                        <input type="submit" value="Search" class="btn btn-primary search-button">
                    </div>

                    <a class="nav-link refresh-link" href="<?php echo e(url('order')); ?>" title="View Orders">
                        <div class="icon-wrapper">
                            <i class="fa-solid fa-arrows-rotate fa-xl" style="color: #74C0FC;"></i>
                            <span class="icon-text">Refresh</span>
                        </div>
                    </a>
                </form>


                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th style="color:#fff;">Name</th>
                            <th style="color:#fff;">Email</th>
                            <!-- <th>Address</th> -->
                            <th style="color:#fff;">Product Name</th>
                            <th style="color:#fff;">Quantity</th>
                            <th style="color:#fff;">Price</th>
                            <th style="color:#fff;">Payment Status</th>
                            <!-- <th>Delivery Status</th> -->
                            <th style="color:#fff;">Deliver or Cancel</th>
                            <th style="color:#fff;">View Details</th>
                            <th style="color:#fff;">PDF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="order-row">
                            <td class="text-white"><?php echo e($order->name); ?></td>
                            <td class="text-white"><?php echo e($order->email); ?></td>
                            <!-- <td class="text-white"><?php echo e($order->address); ?></td> -->
                            <td class="text-white wrap-text">
                                <?php $__currentLoopData = explode(',', $order->product_title); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e(trim($title)); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td class="text-white"><?php echo e($order->quantity); ?></td>
                            <td class="text-white">$<?php echo e(number_format($order->price, 2)); ?></td>
                            <td class="text-white"><?php echo e($order->payment_status); ?></td>
                            <td class="text-white">
                                <span
                                    class="badge
                <?php if($order->delivery_status == 'Delivered'): ?> badge-secondary
                <?php elseif($order->delivery_status == 'Processing'): ?>
                    badge-danger
                <?php else: ?>
                    badge-info <?php endif; ?>
                custom-badge">
                                    <?php echo e($order->delivery_status); ?>

                                </span>

                            </td>
                            <td>
                                <a href="<?php echo e(url('order_details', $order->id)); ?>" class="option1"><i
                                        class="fa-solid fa-eye"></i></a>
                                <!-- <img src="/product/<?php echo e($order->image); ?>" alt="Product Image" width="50" class="rounded"> -->
                            </td>
                            <!-- <td>
                                <?php if($order->delivery_status == 'Processing' || $order->delivery_status == 'Pending'): ?>
<a href="<?php echo e(url('delivered', $order->id)); ?>"
                                    onclick="return confirm('Are you sure this Product is Delivered?')"
                                    class="btn btn-primary "><i class="fa-solid fa-check"></i></a>
                                <a href="<?php echo e(url('cancel', $order->id)); ?>"
                                    onclick="return confirm('Are you sure you want to cancel this order?')"
                                    class="btn btn-danger "><i class="fa-solid fa-xmark" style="color: #000000;"></i></a>
<?php elseif($order->delivery_status == 'Cancelled'): ?>
<p class="text-danger">Order Cancelled</p>
<?php else: ?>
<p class="text-white">Delivered</p>
<?php endif; ?>

                            </td> -->
                            <td>

                                <a href="<?php echo e(url('print_pdf', $order->id)); ?>" class="btn btn-secondary"><i
                                        class="fa-solid fa-file-arrow-down"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div style="padding-top: 20px; text-align: center;">
                    <div class="mb-3">
                        Showing <?php echo e($orders->firstItem()); ?> to <?php echo e($orders->lastItem()); ?> of <?php echo e($orders->total()); ?>

                        results
                    </div>
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <?php echo e($orders->links('pagination::bootstrap-4')); ?>

                        </ul>
                    </nav>
                </div>

            </div>
        </div>

    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src=""></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?php echo e(asset('admin/assets/vendors/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.js')); ?>"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>

    <!-- End custom js for this page -->
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/order.blade.php ENDPATH**/ ?>