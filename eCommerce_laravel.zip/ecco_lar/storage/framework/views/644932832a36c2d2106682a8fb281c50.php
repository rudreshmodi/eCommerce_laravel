<div class="min-h-screen flex flex-col sm:justify-center items-center pt-4 sm:pt-0 bg-gray-100 w-1">
    <div>
         <?php $__env->slot('logo', null, []); ?> 
            <img src="<?php echo e($logo ?? asset('path/to/default/logo.png')); ?>" style="width:100px; height:100px;"
                alt="Logo" />
         <?php $__env->endSlot(); ?>
    </div>

    <div class="w-1/2 md:max-w-lg mt-0 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">

        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/components/authentication-card.blade.php ENDPATH**/ ?>