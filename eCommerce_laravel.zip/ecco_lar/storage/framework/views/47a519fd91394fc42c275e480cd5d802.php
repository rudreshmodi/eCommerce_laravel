<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="<?php echo e(asset('home/css/bootstrap.css')); ?>" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="<?php echo e(asset('home/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('home/css/style.css')); ?>" rel="stylesheet" />
    <!-- responsive style -->
    <link href="<?php echo e(asset('home/css/responsive.css')); ?>" rel="stylesheet" />
</head>

<body>
    <?php if(session()->has('message')): ?>
        <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert"
            aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
            <div class="d-flex">
                <div class="toast-body toast-body-custom">
                    <?php echo e(session()->get('message')); ?>

                    <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"
                        aria-label="Close"></button>
                </div>

            </div>
        </div>
    <?php endif; ?>
    <style>
        .toast {

            background-color: aquamarine;
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            min-width: 300px;
        }

        .toast-body-custom {
            font-size: 16px;
            padding: 15px;
        }

        .btn-close-custom {
            color: #fff;
        }
    </style>

    <div class="hero_area">
        <!-- header section strats -->
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header section -->
        <!-- end client section -->
        <div class="col-sm-6 col-md-4 col-lg-4" style="margin:auto; width:50%; padding:30px">
            <div class="box">
                <div class="img-box" style="padding: 20px; width: 200px; height: 200px; overflow: hidden;">
                    <img src="/product/<?php echo e($product->image); ?>" alt=""
                        style="width: 100%; height: 100%; object-fit: cover;">
                </div>

                <div class="detail-box">
                    <h5><?php echo e($product->title); ?></h5>

                    <?php if($product->discount_price != null): ?>
                        <h6 style="color:green">
                            Discount Price
                            <br>
                            $<?php echo e($product->discount_price); ?>

                        </h6>
                        <h6 style="text-decoration:line-through; color:red ">
                            Price
                            <br>
                            $<?php echo e($product->price); ?>

                        </h6>
                    <?php else: ?>
                        <h6 style="color:green">
                            Price
                            <br>
                            $<?php echo e($product->price); ?>

                        </h6>
                    <?php endif; ?>
                    <h6>Product catagory: <?php echo e($product->catagory); ?></h6>
                    <h6>Description: <?php echo e($product->description); ?></h6>
                    <h6>Available Product Quantity: <?php echo e($product->quantity); ?></h6>

                    <form action="<?php echo e(url('add_cart', $product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <div class="col-md-4">
                                <input type="number" style="width:175px" name="quantity" value="1" min="1">

                            </div>
                            <div class="col-md-4">
                                <input type="submit" value="Add To Cart">

                            </div>


                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- footer start -->
        <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end -->
        <div class="cpy_">
            <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>

                Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>

            </p>
        </div>
        <!-- jQery -->
        <script src="<?php echo e(asset('home/js/jquery-3.4.1.min.js')); ?>"></script>
        <!-- popper js -->
        <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
        <!-- bootstrap js -->
        <script src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
        <!-- custom js -->
        <script src="<?php echo e(asset('home/js/custom.js')); ?>"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var toastEl = document.getElementById('toastMessage');
                var toast = new bootstrap.Toast(toastEl, {
                    delay: 3000 // Show for 5 seconds
                });
                toast.show();
            });
        </script>
</body>

</html>
<?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/home/product_details.blade.php ENDPATH**/ ?>