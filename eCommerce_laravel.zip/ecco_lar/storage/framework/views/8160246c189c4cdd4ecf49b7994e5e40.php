<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Super Admin Dashboard</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('masteradmin/images/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('masteradmin/images/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('masteradmin/images/favicon-16x16.png')); ?>" />

    <!-- Mobile Specific Metas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <!-- Google Font -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Bootstrap JavaScript (Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/css/styles/core.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/cssstyles/icon-font.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('masteradmin/src/plugins/datatables/css/dataTables.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('masteradmin/src/plugins/datatables/css/responsive.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/css/style.css')); ?>" />

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
        crossorigin="anonymous"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-GBZ3SGGX85");
    </script>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                "gtm.start": new Date().getTime(),
                event: "gtm.js"
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != "dataLayer" ? "&l=" + l : "";
            j.async = true;
            j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, "script", "dataLayer", "GTM-NXZMQSS");
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- End Google Tag Manager -->
</head>

<style>
    body {
        font-family: 'Inter', sans-serif;
        background-color: #f8f9fa;
        color: #495057;
    }

    .container {
        margin-top: 20px;
    }

    .card-box {
        border: none;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        background-color: #ffffff;
        padding: 20px;
    }

    h2 {
        color: #007bff;
    }

    label {
        font-weight: 600;
    }

    .btn-submit {
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 15px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn-submit:hover {
        background-color: #0056b3;
    }
</style>

<body>
    <?php echo $__env->make('masteradmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('masteradmin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="pd-20 card-box mb-30 " style="margin-left:21%; margin-top:80px;">

        <div class="container">
            <div class="card-box mb-30">
                <div class="d-flex align-items-center mb-3">
                    <a class="nav-link refresh-link" href="<?php echo e(url('/add_country')); ?>" title="Back">
                        <div class="icon-wrapper">
                            <i class="fa-solid fa-arrow-left fa-xl" style="color: #007bff;"></i>
                            <span class="icon-text">Back</span>
                        </div>
                    </a>
                </div>

                <h2>Edit Country</h2>
                <form action="<?php echo e(route('update_country', $country->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="country">Country Name:</label>
                                <input type="text" name="country" value="<?php echo e($country->country); ?>" id="country" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="country_code">Country Code:</label>
                                <input type="text" name="country_code" value="<?php echo e($country->country_code); ?>" id="country_code" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Update Country</button>
                </form>
            </div>
        </div>
    </div>
</body>

<script>
    $(document).ready(function() {
        // Toggle submenu on click
        $('.dropdown-toggle').on('click', function() {
            // Close other open submenus
            $('.submenu').not($(this).next()).slideUp();
            // Toggle the current submenu
            $(this).next('.submenu').slideToggle();
        });
    });
</script>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/location/edit_country.blade.php ENDPATH**/ ?>