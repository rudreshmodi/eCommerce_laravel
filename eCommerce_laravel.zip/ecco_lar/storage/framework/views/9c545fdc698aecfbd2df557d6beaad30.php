<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link href="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">


    <!-- Layout styles -->
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/images/favicon.png')); ?>" rel="stylesheet" />

    <style>
        body {
            background-color: #1c1c1e;
            color: #ffffff;
            font-family: 'Arial', sans-serif;
        }

        .container {
            margin-top: 50px;
            max-width: 800px;
            padding: 30px;
            background-color: #2c2c2e;
            border-radius: 10px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        h2 {
            color: #00bcd4;
            text-align: center;
            font-weight: bold;
            margin-bottom: 25px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            color: #ffffff;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 12px;
            background-color: #404040;
            border: 1px solid #505050;
            border-radius: 5px;
            color: #ffffff;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="date"]:focus,
        select:focus {
            border-color: #00bcd4;
            outline: none;
            box-shadow: 0 0 10px rgba(0, 188, 212, 0.4);
        }

        .btn-submit {
            background-color: #00bcd4;
            color: #ffffff;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            float: right;
            margin-top: 20px;
        }

        .btn-submit:hover {
            background-color: #0097a7;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .text-danger {
            color: red;
        }

        .error-message {
            color: red;
            font-size: 0.85rem;
        }

        .alert {
            padding: 15px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .image-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .image-preview {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
        }

        a.btn-secondary i {
            margin-right: 5px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
                margin-top: 30px;
            }

            h2 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>

            <div class="text-start">
                <a href="<?php echo e(url('show_coupon')); ?>" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Back
                </a>
                <h2>Update Coupon</h2>
            </div>

            <form action="<?php echo e(route('edit_coupon', $coupon->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($coupon)): ?>
                <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="code">Coupon Code</label>
                        <input id="code" type="text" name="code" placeholder="Enter coupon code" value="<?php echo e($coupon->code); ?>">
                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="discount">Discount Amount</label>
                        <input id="discount" type="number" min="0" name="discount" placeholder="Enter discount" value="<?php echo e($coupon->discount); ?>">
                        <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <label for="usage_option">Select Type <span class="text-danger">*</span></label>
                        <select name="usage_option" required>
                            <option value="">Select Option</option>
                            <option value="once" <?php echo e($coupon->usage_option == 'once' ? 'selected' : ''); ?>>Once (One-time use)</option>
                            <option value="repeating" <?php echo e($coupon->usage_option == 'repeating' ? 'selected' : ''); ?>>Repeating (Multiple uses)</option>
                        </select>
                        <?php $__errorArgs = ['usage_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <label for="valid_from">Valid From <span class="text-danger">*</span></label>
                        <input type="date" name="valid_from" value="<?php echo e($coupon->valid_from); ?>" required>
                        <?php $__errorArgs = ['valid_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="valid_to">Valid To <span class="text-danger">*</span></label>
                        <input type="date" name="valid_to" value="<?php echo e($coupon->valid_to); ?>" required>
                        <?php $__errorArgs = ['valid_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group">
                    <input type="submit" value="<?php echo e(isset($coupon) ? 'Update Coupon' : 'Add Coupon'); ?>" class="btn-submit">
                </div>
            </form>
        </div>
    </div>

    <!-- JS Links -->
    <script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/edit_coupon.blade.php ENDPATH**/ ?>