<!DOCTYPE html>
<html lang="en">

<head>
    <!--   meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link href="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Layout styles -->
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/images/favicon.png')); ?>" rel="stylesheet" />

    <style>
        body {
            background-color: black;
        }

        .container {
            margin-top: 80px;
            max-width: 900px;
            height: auto;
            max-height: 550px;
            padding: 20px;
            background-color: #424242;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #007bff;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .text-start {
            text-align: left;
            /* Ensures the text is aligned to the left */
        }

        label {
            color: white;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            transition: border-color 0.3s;
        }

        input:focus,
        select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-submit {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            float: right;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }

        .alert {
            margin-bottom: 20px;
        }

        .error-message {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .image-preview {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
            margin-left: 15px;
        }

        .image-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="text-start">
                <a href="<?php echo e(url('show_product')); ?>" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Back
                </a>
                <h2>Add Product</h2>
            </div>

            <form action="<?php echo e(url('/add_product')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="title">Product Title <span style="color:red;">*</span></label>
                        <input id="title" type="text" name="title" placeholder="Title">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="catagory">Product Category <span style="color:red;">*</span></label>
                        <select name="catagory" id="catagory">
                            <option value="" selected>Select a Category</option>
                            <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($catagory->catagory_name); ?>"><?php echo e($catagory->catagory_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['catagory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="quantity">Product Quantity <span style="color:red;">*</span></label>
                        <input id="quantity" type="number" min="0" name="quantity" placeholder="Quantity">
                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="price">Product Price <span style="color:red;">*</span></label>
                        <input id="price" type="number" name="price" placeholder="Price">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="discount_price">Discount Price <span style="color:red;">*</span></label>
                        <input id="discount_price" type="number" name="discount_price" placeholder="Discount Price">
                        <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 form-group image-container">
                        <label for="image">Product Image <span style="color:red;">*</span></label>
                        <input id="image" type="file" name="image" onchange="previewImage(event)">
                        <img id="imagePreview" class="image-preview" src="#" alt="Image Preview"
                            style="display:none;">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Product Description <span style="color:red;">*</span></label>
                    <textarea id="description" type="text" name="description" placeholder="Description"></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <input type="submit" value="Add Product" class="btn-submit">
                </div>
            </form>
        </div>
    </div>

    <!-- JS Links -->
    <script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>

    <script>
        function previewImage(event) {
            const imagePreview = document.getElementById('imagePreview');
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
            }

            if (file) {
                reader.readAsDataURL(file);
            } else {
                imagePreview.style.display = 'none';
            }
        }
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/product.blade.php ENDPATH**/ ?>