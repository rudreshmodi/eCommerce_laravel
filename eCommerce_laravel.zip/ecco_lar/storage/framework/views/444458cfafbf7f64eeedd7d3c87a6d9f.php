<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="<?php echo e(asset('home/css/bootstrap.css')); ?>" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="<?php echo e(asset('home/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('home/css/style.css')); ?>" rel="stylesheet" />
    <!-- responsive style -->
    <link href="<?php echo e(asset('home/css/responsive.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css" integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <?php if(session()->has('message')): ?>
    <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
        <div class="d-flex">
            <div class="toast-body toast-body-custom">
                <?php echo e(session()->get('message')); ?>

                <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>

        </div>
    </div>
    <?php endif; ?>

    <style>
        .toast {

            background-color: aquamarine;
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            min-width: 300px;
        }

        .toast-body-custom {
            font-size: 16px;
            padding: 15px;
        }

        .btn-close-custom {
            color: #fff;
        }
    </style>

    <div class="hero_area">
        <!-- header section strats -->
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header section -->
        <div>
            <section class="inner_page_head">
                <div class="container_fuild">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="full">
                                <h3>Contact us</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- end inner page section -->
            <!-- why section -->
            <section class="why_section layout_padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                            <div class="full">
                                <form action="<?php echo e(url('submit-contact')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <fieldset>
                                        <!-- Name field -->
                                        <p>Name<span style="color: red;"> *</span></p>
                                        <input type="text" placeholder="Enter your full name" name="name" value="<?php echo e(old('name')); ?>" />
                                        <?php if($errors->has('name')): ?>
                                        <span style="color: red; margin-top: 0;"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>

                                        <!-- Email field -->
                                        <p>Email<span style="color: red;"> *</span></p>
                                        <input type="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" />
                                        <?php if($errors->has('email')): ?>
                                        <span style="color: red;"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>

                                        <!-- Subject field -->
                                        <p>Subject<span style="color: red;"> *</span></p>
                                        <input type="text" placeholder="Enter subject" name="subject" value="<?php echo e(old('subject')); ?>" />
                                        <?php if($errors->has('subject')): ?>
                                        <span style="color: red;"><?php echo e($errors->first('subject')); ?></span>
                                        <?php endif; ?>

                                        <!-- Message field -->
                                        <p>Message<span style="color: red;"> *</span></p>
                                        <textarea name="message" placeholder="Enter your message"><?php echo e(old('message')); ?></textarea>
                                        <?php if($errors->has('message')): ?>
                                        <span style="color: red;"><?php echo e($errors->first('message')); ?></span>
                                        <?php endif; ?>

                                        <input type="submit" value="Submit" />
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end -->
        <div class="cpy_">
            <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>

                Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>

            </p>
        </div>
        <!-- jQery -->
        <script src="<?php echo e(asset('home/js/jquery-3.4.1.min.js')); ?>"></script>
        <!-- popper js -->
        <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
        <!-- bootstrap js -->
        <script src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
        <!-- custom js -->
        <script src="<?php echo e(asset('home/js/custom.js')); ?>"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var toastEl = document.getElementById('toastMessage');
                var toast = new bootstrap.Toast(toastEl, {
                    delay: 3000 // Show for 5 seconds
                });
                toast.show();
            });
        </script>
</body>

</html>
<!-- mzg7I4i6CiPvEP
rudresh.modi@xceltec.in --><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/home/contact.blade.php ENDPATH**/ ?>