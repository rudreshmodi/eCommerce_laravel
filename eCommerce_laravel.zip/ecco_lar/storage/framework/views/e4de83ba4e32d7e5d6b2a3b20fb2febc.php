<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Website Title</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .header_section {
            background-color: white;
            /* Change this to your desired background color */
            z-index: 1000;
            /* Ensure the header is above other content */
        }

        /* Fixed header styles */
        .fixed-top {
            position: fixed;
            /* Fixes the position */
            top: 0;
            background-color: white;

            /* Aligns it to the top of the viewport */
            width: 100%;
            /* Ensures it takes full width */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            /* Optional shadow for better visibility */
        }

        .toggle-button-group {
            display: flex;
            justify-content: center;
            /* Center the buttons */
        }

        .btn-toggle {
            border-radius: 5px;
            /* Rounded corners */
            margin: 0;
            /* Remove default margins */
            transition: background-color 0.3s ease, color 0.3s ease;
            /* Smooth transition */
        }

        .btn-toggle.active {
            background-color: #007bff;
            /* Active button color */
            color: white;
            /* Active button text color */
        }

        .btn-toggle:not(.active) {
            background-color: transparent;
            /* Inactive button color */
            color: #007bff;
            /* Inactive button text color */
            border: 2px solid #007bff;
            /* Border for inactive button */
        }

        .btn-toggle:hover {
            background-color: rgba(0, 123, 255, 0.1);
            /* Hover effect */
        }
    </style>
</head>

<body>

    <header class="header_section">
        <div class="container">
            <nav class="navbar navbar-expand-lg custom_nav-container fixed-top">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img width="250" class="py-2 pl-4" src="<?php echo e(asset('home/images/logo.png')); ?>" alt="#" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class=""> </span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <?php if(!request()->is('login') && !request()->is('register')): ?>
                        <li class="nav-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('show_cart') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(url('show_cart')); ?>">Cart</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('show_order') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(url('show_order')); ?>">Order</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('product') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(route('product.index')); ?>">Shop</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('contact') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(url('contact')); ?>">Contact us</a>
                        </li>
                        <?php endif; ?>

                        <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item" style="border-radius: 50%;">
                            <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
                        </li>
                        <?php else: ?>
                        <?php if(request()->is('login')): ?>
                        <li class="nav-item <?php echo e(request()->is('register') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(route('register')); ?>">Register</a>
                        </li>
                        <?php elseif(request()->is('register')): ?>
                        <li class="nav-item <?php echo e(request()->is('login') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <?php else: ?>
                        <li class="nav-item <?php echo e(request()->is('login') ? 'active' : ''); ?>">
                            <a class="nav-link" style="margin-right: 10px; margin-top: 5px;"
                                href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <?php endif; ?>

                        

                        <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>

            </nav>
        </div>
    </header>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/home/header.blade.php ENDPATH**/ ?>