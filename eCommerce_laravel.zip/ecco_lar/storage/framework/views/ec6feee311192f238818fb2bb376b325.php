<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link href="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">


    <!-- Layout styles -->
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />

    <style>
        body {
            background-color: #121212;
            color: #f5f5f5;
            font-family: 'Arial', sans-serif;
            transition: background-color 0.3s ease;
        }

        .container {
            margin-top: 100px;
            max-width: 900px;
            height: max-content;
            padding: 15px 25px;
            background-color: #1e1e1e;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.5s;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        h2 {
            color: #007bff;
            text-align: center;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        label {
            color: #ffffff;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #303030;
            border-radius: 8px;
            background-color: #424242;
            color: #ffffff;
            transition: border-color 0.3s, background-color 0.3s;
        }

        input:focus,
        select:focus {
            border-color: #007bff;
            outline: none;
            background-color: #2a2a2a;
        }

        .btn-submit,
        input[type="button"] {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }

        .alert {
            margin-bottom: 20px;
            border-radius: 8px;
        }

        .error-message {
            color: #ff4d4d;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .btn-primary {
            background-color: #0069d9;
            border-radius: 5px;
            transition: transform 0.2s;
        }

        .btn-primary:hover {
            transform: scale(1.05);
        }

        .success-message {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            margin-top: 20px;
        }
    </style>

    <script>
        const usedCodes = new Set(); // Track generated codes for uniqueness

        function generateCouponCode() {
            const prefix = 'SAVE-';
            const totalLength = 12; // Total length of the coupon code
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()'; // Expanded character set
            let randomCode;

            do {
                randomCode = prefix + generateRandomString(totalLength - prefix.length);
            } while (usedCodes.has(randomCode)); // Ensure uniqueness

            usedCodes.add(randomCode); // Store the generated code
            document.getElementById('coupon_code').value = randomCode;
        }

        function generateRandomString(length) {
            let result = '';
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()'; // Same set of characters used here
            for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * chars.length);
                result += chars[randomIndex];
            }
            return result;
        }
    </script>

</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            
            <?php if(session('success')): ?>
            <div class="success-message mt-4">
                <p><?php echo e(session('success')); ?></p>
            </div>
            <?php endif; ?>

            <div class="text-start mb-2">
                <h2><b>Create Coupon Code</b></h2>
            </div>

            <form method="POST" action="<?php echo e(route('coupons.create')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="coupon_code">Coupon Code <span style="color:red;">*</span></label>
                    <div class="row">
                        <div class="col-md-9">
                            <input type="text" id="coupon_code" name="code" placeholder="Coupon Code" readonly>
                        </div>
                        <div class="col-md-3">
                            <button type="button" class="btn btn-primary" style="padding:15px 20px; width:180px;"
                                onclick="generateCouponCode()">
                                <i class="fas fa-random"></i> Generate
                            </button>
                        </div>
                    </div>
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="discount">Discount Amount (%):</label>
                    <div class="row">
                        <div class="col-md-6">
                            <input type="number" id="discount" name="discount" placeholder="Discount Amount"
                                value="10" required step="0.01">
                            <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6">
                            <label for="usage_option">Select Type <span style="color:red;">*</span></label>
                            <select name="usage_option" id="" required>
                                <option value="">Select Option</option>
                                <option value="once">Once (One-time use)</option>
                                <option value="repeating">Repeating (Multiple uses)</option>
                            </select>
                            <?php $__errorArgs = ['usage_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="mb-3 col-md-6">
                        <label for="valid_from">Valid From <span style="color:red;">*</span></label>
                        <input type="date" name="valid_from" id="valid_from" required>
                        <?php $__errorArgs = ['valid_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="valid_to">Valid To <span style="color:red;">*</span></label>
                        <input type="date" name="valid_to" id="valid_to" required>
                        <?php $__errorArgs = ['valid_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group">
                    <input type="submit" value="Create Coupon" class="btn btn-primary btn-submit float-end">
                </div>


            </form>

        </div>
    </div>

    <!-- JS Links -->
    <script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/coupons.blade.php ENDPATH**/ ?>