<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Super Admin Dashboard</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('masteradmin/images/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('masteradmin/images/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('masteradmin/images/favicon-16x16.png')); ?>" />

    <!-- Mobile Specific Metas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <!-- Google Font -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Bootstrap JavaScript (Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/css/styles/core.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/cssstyles/icon-font.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('masteradmin/src/plugins/datatables/css/dataTables.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('masteradmin/src/plugins/datatables/css/responsive.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('masteradmin/css/style.css')); ?>" />

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
        crossorigin="anonymous"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-GBZ3SGGX85");
    </script>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                "gtm.start": new Date().getTime(),
                event: "gtm.js"
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != "dataLayer" ? "&l=" + l : "";
            j.async = true;
            j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, "script", "dataLayer", "GTM-NXZMQSS");
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- End Google Tag Manager -->
</head>

<body>
    <?php echo $__env->make('masteradmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('masteradmin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="pd-20 card-box mb-30" style="margin-left:21%; margin-top:80px;">
        <div class="clearfix mb-20">
            <div class="pull-left">
                <h4 class="text-blue h4 ml-4">Admin Details</h4>
            </div>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Address</th>
                    <th scope="col">Role &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Change Role</th>
                    <th scope="col">Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($admin->name); ?></td>
                    <td><?php echo e($admin->email); ?></td>
                    <td><?php echo e($admin->phone); ?></td>
                    <td><?php echo e($admin->address); ?></td>
                    <td>
                        <?php if($admin->usertype == 1): ?>
                        <span class="badge badge-success">Admin</span>
                        <?php else: ?>
                        <span class="badge badge-secondary">User</span>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-toggle" data-user-id="<?php echo e($admin->id); ?>"
                            data-user-type="<?php echo e($admin->usertype); ?>">
                            <i class="fa-solid fa-circle-check"
                                style="color: #357929; font-size:28px; margin-left:20px;"></i>
                        </button>
                    </td>
                    <td>
                        <a href="<?php echo e(url('/edit_admin',$admin->id)); ?>">
                            <span class="badge">
                                <i class="fas fa-edit fa-xl"></i>
                            </span>
                        </a>
                        <a href="<?php echo e(url('delete_admin', $admin->id)); ?>" admin-id="<?php echo e($admin->id); ?>">
                            <span class="badge">
                                <i class="fa-solid fa-trash-can fa-xl" style="color: #e61e1e;"></i>
                            </span>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmToggleModal" tabindex="-1" aria-labelledby="confirmToggleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmToggleModalLabel">Confirm Toggle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to change this user's role?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmToggleBtn">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Delete Confirmation -->
    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this product? This action cannot be undone.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // For description modal
            const buttons = document.querySelectorAll('[data-bs-toggle="modal"]');
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const description = this.getAttribute('data-description');
                    const title = this.closest('tr').querySelector('td:nth-child(2)')
                        .textContent; // Adjust if title position changes

                    document.getElementById('modal-description').textContent = description;
                    document.getElementById('descriptionModalLabel').textContent =
                        `${title} - Description`; // Set the title dynamically
                });
            });

            // For image modal
            const imgButtons = document.querySelectorAll('img[data-bs-toggle="modal"]');
            imgButtons.forEach(img => {
                img.addEventListener('click', function() {
                    const imageUrl = this.getAttribute('data-image');
                    document.getElementById('modal-image').src = imageUrl;
                });
            });
        });


        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.delete-btn');
            let deleteProductId;

            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    deleteProductId = this.getAttribute('data-id');
                });
            });

            document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
                if (deleteProductId) {
                    window.location.href = "<?php echo e(url('delete_product')); ?>/" + deleteProductId;
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            let userId, currentType, toggleButton;

            $('.btn-toggle').click(function() {
                userId = $(this).data('user-id');
                currentType = $(this).data('user-type');
                toggleButton = $(this);
                $('#confirmToggleModal').modal('show');
            });

            $('#confirmToggleBtn').click(function() {
                var newType = currentType == 1 ? 0 : 1;

                $.ajax({
                    url: '/users/toggle-type/' + userId,
                    method: 'POST',
                    data: {
                        usertype: newType,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        if (response.usertype == 1) {
                            toggleButton.prev('.badge').removeClass('badge-secondary').addClass(
                                'badge-success').text('Admin');
                        } else {
                            toggleButton.prev('.badge').removeClass('badge-success').addClass(
                                'badge-secondary').text('User');
                        }
                        toggleButton.data('user-type', response.usertype);
                        $('#confirmToggleModal').modal('hide');
                        location.reload(); // Reload the page after toggling
                    },
                    error: function(xhr) {
                        alert('An error occurred: ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Toggle submenu on click
            $('.dropdown-toggle').on('click', function() {
                // Close other open submenus
                $('.submenu').not($(this).next()).slideUp();
                // Toggle the current submenu
                $(this).next('.submenu').slideToggle();
            });
        });
    </script>

    <script src="<?php echo e(asset('masteradmin/scripts/js/core.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/scripts/js/script.min.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/scripts/js/process.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/scripts/js/layout-settings.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/src/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/js/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/js/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/js/datatables/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/js/datatables/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('masteradmin/js/dashboard3.js')); ?>"></script>

</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/masteradmin/admindetails.blade.php ENDPATH**/ ?>