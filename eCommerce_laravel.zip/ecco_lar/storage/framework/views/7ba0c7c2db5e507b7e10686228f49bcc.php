<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            padding: 20px;
            background-color: #f8f9fa;
        }

        .header {
            margin-bottom: 30px;
            border-bottom: 2px solid #343a40;
            padding-bottom: 10px;
            display: flex;
            align-items: center;
        }

        .logo {
            max-width: 150px;
            /* Adjust logo width */
            margin-right: 20px;
        }

        .header h2 {
            margin: 0;
            color: #343a40;
            font-size: 24px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        h3 {
            margin-top: 20px;
            color: #495057;
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 5px;
            font-size: 18px;
        }

        .order-details {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .order-details th,
        .order-details td {
            padding: 12px 15px;
            border: 1px solid #dee2e6;
            text-align: left;
            font-size: 14px;
        }

        .order-details th {
            background-color: #f1f3f5;
            color: #343a40;
            font-weight: bold;
            text-transform: uppercase;
        }

        .order-details td {
            background-color: #ffffff;
            color: #495057;
        }

        .text-right {
            text-align: right;
        }

        .total {
            margin-top: 30px;
            font-weight: bold;
            border-collapse: collapse;
        }

        .total td,
        .total th {
            padding: 10px 15px;
            border: 1px solid #dee2e6;
            font-size: 16px;
        }

        .total td {
            background-color: #f8f9fa;
        }

        .highlight {
            color: #dc3545;
            font-weight: bold;
        }

        .grand-total {
            color: #28a745;
            font-weight: bold;
        }

        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 12px;
            color: #6c757d;
        }

        .order-number {
            font-size: 16px;
            color: #343a40;
            font-weight: bold;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .order-details,
            .total {
                width: 100%;
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

    <div class="header">
        <!-- <img src="<?php echo e(url('admin/assets/images/faces/Company_Logo.jpg')); ?>" class="logo"> -->
        <h2 style="color: #467fdb;">Order Details</h2>
    </div>

    <h3>Customer Details</h3>
    <table class="order-details">
        <tr>
            <th>Name</th>
            <td><?php echo e($order->name); ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php echo e($order->email); ?></td>
        </tr>
        <tr>
            <th>Phone</th>
            <td><?php echo e($order->phone); ?></td>
        </tr>
        <tr>
            <th>Shipping Address</th>
            <td><?php echo e($order->address); ?></td>
        </tr>
        <tr>
            <th>Payment Type</th>
            <td><?php echo e($order->payment_status); ?></td>
        </tr>
    </table>

    <h3>Order Items</h3>
    <table class="order-details">
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            use App\Models\Product; // Import the Product model

            $productTitles = explode(', ', $order->product_title);
            $productQuantities = explode(', ', $order->quantity);
            $productIds = explode(', ', $order->product_id);

            $groupedProducts = [];

            foreach ($productIds as $index => $id) {
            $product = Product::find($id);
            if ($product) {
            $title = $productTitles[$index];
            $price = $product->discount_price;
            $quantity = $productQuantities[$index];

            if (!isset($groupedProducts[$title])) {
            $groupedProducts[$title] = [
            'quantity' => 0,
            'price' => $price,
            'total' => 0,
            ];
            }

            $groupedProducts[$title]['quantity'] += $quantity;
            $groupedProducts[$title]['total'] += $quantity * $price;
            }
            }

            $totalPrice = 0;
            ?>

            <?php if(count($groupedProducts) > 0): ?>
            <?php $__currentLoopData = $groupedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($title); ?></td>
                <td><?php echo e($data['quantity']); ?></td>
                <td class="text-right">$<?php echo e(number_format($data['price'], 2)); ?></td>
                <td class="text-right">$<?php echo e(number_format($data['total'], 2)); ?></td>
            </tr>
            <?php
            $totalPrice += $data['total'];
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="4" class="text-right highlight">No items in this order.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <table class="order-details total">
        <tr>
            <th>Total Quantity</th>
            <td class="text-right"><?php echo e(array_sum(array_column($groupedProducts, 'quantity'))); ?></td>
        </tr>
        <tr>
            <th>Total Items</th>
            <td class="text-right"><?php echo e(count($groupedProducts)); ?></td>
        </tr>
        <tr>
            <td>Total Price</td>
            <td class="text-right">$<?php echo e(number_format($totalPrice, 2)); ?></td>
        </tr>
        <tr>
            <td>Shipping Fee</td>
            <?php $shipping_fee = 10; ?>
            <td class="text-right highlight" style="color:#dc3545;">$<?php echo e(number_format($shipping_fee, 2)); ?></td>
        </tr>
        <tr>
            <td><strong>Grand Total</strong></td>
            <td class="text-right grand-total" style="color:green;">$<?php echo e(number_format($totalPrice + $shipping_fee, 2)); ?></td>
        </tr>
    </table>

    <div class="footer">
        <p>Thank you for your order! If you have any questions, please contact us.</p>
    </div>

</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/pdf.blade.php ENDPATH**/ ?>