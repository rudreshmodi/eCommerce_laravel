<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="shortcut icon" href="images/favicon.png" type="image/png">
    <title>Famms - Fashion HTML Template</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('home/css/bootstrap.css')); ?>" rel="stylesheet" />
    <!-- Font Awesome style -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('home/css/style.css')); ?>" rel="stylesheet" />
    <!-- Responsive style -->
    <link href="<?php echo e(asset('home/css/responsive.css')); ?>" rel="stylesheet" />

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            text-align: center;
            text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.1);
        }

        .card {
            display: flex;
            /* Use flexbox to align items */
            flex-direction: column;
            /* Align children vertically */
            border-radius: 15px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            transition: transform 0.3s;
            overflow: hidden;
            border: none;
            height: 350px;
            margin-bottom: 20px;
        }

        .card img {
            width: 100%;
            /* Full width of the card */
            height: 150px;
            /* Set a fixed height for images */
            object-fit: cover;
            /* Ensure image covers area */
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0px 15px 40px rgba(0, 0, 0, 0.2);
        }

        .card-title {
            font-weight: bold;
            color: #007bff;
            font-size: 1.25rem;
        }

        .card-text {
            color: #555;
            font-size: 1rem;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eaeaea;
        }

        .summary-item:last-child {
            border-bottom: none;
        }

        .gross-total {
            font-size: 1.5rem;
            font-weight: bold;
            color: #007bff;
            margin-top: 15px;
            text-align: right;
        }

        .btn-proceed {
            margin-top: 20px;
        }

        .bill-summary-container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .bill-summary-container:hover {
            box-shadow: 0px 8px 30px rgba(0, 0, 0, 0.2);
        }

        /* Other existing styles... */

        /* Add necessary styles for responsiveness */
        @media (max-width: 767.98px) {
            .card {
                height: auto;
                /* Allow cards to grow on smaller screens */
            }
        }
    </style>
</head>

<body>
    <?php if(session()->has('message')): ?>
    <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert"
        aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
        <div class="d-flex">
            <div class="toast-body toast-body-custom">
                <?php echo e(session()->get('message')); ?>

                <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="hero_area">
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container" style="margin-top: 70px;">
            <?php
            $totalprice = 0; // Initialize total price
            ?>

            <?php if($cart->isEmpty()): ?>
            <div class="col-12 text-center empty-cart-container">
                <div class="card text-center p-4">
                    <h5 class="card-title">Your Cart is Empty</h5>
                    <p class="card-text">Looks like you haven't added anything to your cart yet.</p>
                    <p class="card-text">Browse our collection and add products to your cart!</p>
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-danger shop-now-btn"
                        aria-label="Shop Now">
                        <i class="fas fa-shopping-cart"></i> Shop Now
                    </a>
                </div>
            </div>
            <?php else: ?>
            <div class="row"> <!-- Add this row to align cards side by side -->
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $totalprice += $item->price * $item->quantity; // Calculate total price
                ?>
                <div class="col-md-4">
                    <div class="card text-center p-3">
                        <img src="/product/<?php echo e($item->image); ?>" alt="Product Image" class="img-thumbnail mb-3">
                        <h5 class="card-title"><?php echo e($item->product_title); ?></h5>
                        <p class="card-text">Quantity: <?php echo e($item->quantity); ?></p>
                        <p class="card-text">Price: $<?php echo e(number_format($item->price, 2)); ?></p>
                        <a onclick="return confirm('Are you sure to delete this Product?')"
                            style="margin-bottom:20px;" href="<?php echo e(url('remove_cart', $item->id)); ?>">
                            <button class="btn btn-danger">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <h2>Do you have a Coupon Code? Apply Here</h2>
            <form method="POST" action="<?php echo e(route('coupons.validate')); ?>"
                class="d-flex flex-column align-items-center p-4 bg-light rounded shadow-sm">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input type="text" name="coupon_code" class="form-control" placeholder="Enter Coupon Code"
                        required>
                    <button type="submit" class="btn btn-success" onclick="celebrate()">
                        <i class="fas fa-ticket-alt"></i> Apply Coupon
                    </button>
                </div>
                <small class="coupon-hint">Hint: Use code <strong>WELCOME10</strong> for 10% off!</small>
            </form>

            
            <?php if(session('message')): ?>
            <div class="alert alert-info mt-3">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>

            <?php
            $discountedPrice = session('discounted_price', $totalprice);
            $shippingFee = rand(1, 9); // Random shipping fee between 1 and 9
            $grossTotal = $discountedPrice + $shippingFee; // Gross total calculation
            ?>

            <div class="container text-center mt-5">
                <div class="bill-summary-container">
                    <h1 class="display-5 text-primary">Bill Summary</h1>
                    <div class="summary-item">
                        <span>Total Price:</span>
                        <span>$<?php echo e(number_format($totalprice, 2)); ?></span>
                    </div>
                    <div class="summary-item">
                        <span>Discounted Price:</span>
                        <span>$<?php echo e(number_format($discountedPrice, 2)); ?></span>
                    </div>
                    <div class="summary-item">
                        <span style="color: #28a745;">You Saved:</span>
                        <span style="color: #28a745;">$<?php echo e(number_format($totalprice - $discountedPrice, 2)); ?></span>
                    </div>
                    <div class="summary-item">
                        <span>Shipping Fee:</span>
                        <span>$<?php echo e(number_format($shippingFee, 2)); ?></span>
                    </div>
                    <div class="gross-total">
                        Gross Total: $<?php echo e(number_format($grossTotal, 2)); ?>

                    </div>
                    <div class="d-grid gap-2 btn-proceed">
                        <a class="btn btn-danger btn-lg rounded-pill" href="<?php echo e(url('cash_order')); ?>">Cash on
                            Delivery</a>
                        <a class="btn btn-success btn-lg rounded-pill" href="<?php echo e(url('stripe', $grossTotal)); ?>">Pay
                            Using Card</a>
                    </div>
                </div>
            </div>

            <?php endif; ?>
        </div>

        <div class="celebration" id="celebration">
            <div class="party-crackers"></div>
        </div>
    </div>

    <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="cpy_">
        <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
        </p>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('home/js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/custom.js')); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var toastEl = document.getElementById('toastMessage');
            if (toastEl) {
                var toast = new bootstrap.Toast(toastEl, {
                    delay: 3000 // Show for 3 seconds
                });
                toast.show();
            }
        });

        function celebrate() {
            const celebrationDiv = document.getElementById('celebration');
            celebrationDiv.style.display = 'flex';
            setTimeout(() => {
                celebrationDiv.style.display = 'none';
            }, 2000); // Hide after 2 seconds
        }
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/home/show_cart.blade.php ENDPATH**/ ?>