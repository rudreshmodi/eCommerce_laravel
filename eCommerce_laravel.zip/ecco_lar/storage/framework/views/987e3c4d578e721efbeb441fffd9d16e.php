<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="<?php echo e(asset('home/css/bootstrap.css')); ?>" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="<?php echo e(asset('home/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('home/css/style.css')); ?>" rel="stylesheet" />
    <!-- responsive style -->
    <link href="<?php echo e(asset('home/css/responsive.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css"
        integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .not-available {
            background-color: #ffcccc;
            /* Light red background to indicate unavailability */
            border: 1px solid #ff0000;
            /* Red border */
            padding: 10px;
            text-align: center;
            margin-top: 10px;
            border-radius: 5px;
        }

        .unavailable-text {
            color: #ff0000;
            /* Red text color */
            font-size: 16px;
            font-weight: bold;
        }

        .toast {
            background-color: #ffcc00;
            /* Changed to a more attractive color */
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            min-width: 300px;
            border-radius: 8px;
            /* Added rounded corners */
        }

        .toast-body-custom {
            font-size: 16px;
            padding: 15px;
            color: #333;
            /* Changed text color for better readability */
        }

        .btn-close-custom {
            color: #333;
            /* Changed close button color to match text */
            opacity: 1;
            /* Ensured the close button is fully opaque */
        }

        /* Additional Styles for Product Cards */
        .product-card {
            position: relative;
            border: none;
            /* Removed border for a cleaner look */
            border-radius: 15px;
            /* Increased border radius for smoother corners */
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.3s;
            margin: 15px;
            background-color: #fff;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            /* Enhanced shadow for depth */
            padding: 20px;
            /* Increased padding for better spacing */
        }

        .product-card:hover {
            transform: translateY(-5px);
            /* Subtle lift effect on hover */
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
            /* Increased shadow on hover */
        }

        .product-card a {
            text-decoration: none;
            color: inherit;
        }

        .img-box {
            overflow: hidden;
            height: 220px;
            /* Adjusted height for better image display */
            border-radius: 15px;
            /* Match card corners */
        }

        .img-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s;
        }

        .img-box:hover img {
            transform: scale(1.1);
            /* Zoom effect on hover */
        }

        .detail-box {
            padding: 15px;
            text-align: center;
        }

        .add-to-cart {
            background-color: #28a745;
            /* Changed to a green color */
            color: white;
            border: none;
            padding: 12px 20px;
            /* Increased padding */
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.2s;
            width: 100%;
            cursor: pointer;
        }

        .add-to-cart:hover {
            background-color: #218838;
            /* Darker green on hover */
            transform: scale(1.05);
            /* Slightly larger on hover */
        }

        /* Quantity control styles */
        .quantity-controls {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
        }

        .quantity-controls button {
            border: none;
            background-color: #007bff;
            /* Button color */
            color: white;
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.2s, transform 0.2s;
            /* Added transform */
            border-radius: 5px;
            /* Rounded corners */
            display: flex;
            /* Center icon and text */
            align-items: center;
            justify-content: center;
        }

        .quantity-controls button:hover {
            background-color: #0056b3;
            /* Darker shade on hover */
            transform: scale(1.05);
            /* Slight lift on hover */
        }

        .quantity-controls input {
            width: 50px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 0 5px;
            padding: 5px;
            /* Added padding for input */
        }

        .heading_container h2 span {
            color: #007bff;
        }

        /* Category Buttons */
        .category-buttons {
            margin: 20px 0;
        }

        .category-buttons .btn {
            margin: 5px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .quantity-controls {
                flex-direction: column;
                /* Stack buttons vertically on small screens */
            }

            .quantity-controls button {
                width: 100%;
                /* Full width buttons on small screens */
                margin-bottom: 5px;
                /* Space between buttons */
            }
        }
    </style>

</head>

<body>
    <?php if(session()->has('message')): ?>
    <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert"
        aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
        <div class="d-flex">
            <div class="toast-body toast-body-custom">
                <?php echo e(session()->get('message')); ?>

                <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="hero_area">
        <!-- header section starts -->
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header section -->

        <div class="container mt-5">
            <section class="product_section layout_padding">
                <div class="container">
                    <div class="heading_container heading_center">
                        <h2>
                            Our <span>products</span>
                        </h2>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4 col-lg-4">
                            <div class="product-card">
                                <a href="<?php echo e(url('product_details', $product->id)); ?>">
                                    <div class="img-box">
                                        <img src="<?php echo e(asset('product/' . $product->image)); ?>" alt="<?php echo e($product->title); ?>">
                                        <?php if($product->discount_price != null): ?>
                                        <span class="discount-badge">Discount</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="detail-box">
                                        <h5><?php echo e($product->title); ?></h5>
                                        <?php if($product->discount_price != null): ?>
                                        <h6 class="discount-price">
                                            $<?php echo e($product->discount_price); ?>

                                        </h6>
                                        <h6 class="original-price">
                                            <span style="text-decoration: line-through;">$<?php echo e($product->price); ?></span>
                                        </h6>
                                        <?php else: ?>
                                        <h6 class="price">
                                            $<?php echo e($product->price); ?>

                                        </h6>
                                        <?php endif; ?>
                                    </div>
                                </a>

                                <?php if($product->quantity > 0): ?>
                                <form action="<?php echo e(url('add_cart', $product->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="quantity-controls">
                                        <button type="button" class="decrement"><i class="fas fa-minus" style="font-weight: bolder;"></i></button>
                                        <input type="text" name="quantity" value="1" min="1" class="quantity-input" style="font-weight: bolder;">
                                        <button type="button" class="increment"><i class="fas fa-plus" style="font-weight: bolder;"></i></button>
                                    </div>
                                    <button type="submit" class="add-to-cart">Add To Cart</button>
                                </form>
                                <?php else: ?>
                                <div class="not-available">
                                    <span class="unavailable-text">Now This Product is Not Available</span>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <span style="padding-top:20px">
                        <?php echo $products->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </span>
                    <div class="btn-box">
                        <a href="">
                            View All products
                        </a>
                    </div>
                </div>
            </section>
        </div> <!-- Close the container div -->
    </div>

    <!-- footer start -->
    <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer end -->
    <div class="cpy_">
        <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
        </p>
    </div>
    <!-- jQery -->
    <script src="<?php echo e(asset('home/js/jquery-3.4.1.min.js')); ?>"></script>
    <!-- popper js -->
    <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
    <!-- custom js -->
    <script src="<?php echo e(asset('home/js/custom.js')); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var toastEl = document.getElementById('toastMessage');
            if (toastEl) { // Check if the toast element exists
                var toast = new bootstrap.Toast(toastEl, {
                    delay: 3000 // Show for 3 seconds
                });
                toast.show();
            }

            // Quantity increment and decrement functionality
            const quantityInputs = document.querySelectorAll('.quantity-controls');

            quantityInputs.forEach(input => {
                const decrementButton = input.querySelector('.decrement');
                const incrementButton = input.querySelector('.increment');
                const quantityInput = input.querySelector('.quantity-input');

                decrementButton.addEventListener('click', () => {
                    let quantity = parseInt(quantityInput.value);
                    if (quantity > 1) {
                        quantityInput.value = quantity - 1;
                    }
                });

                incrementButton.addEventListener('click', () => {
                    let quantity = parseInt(quantityInput.value);
                    quantityInput.value = quantity + 1;
                });
            });
        });
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/product/index.blade.php ENDPATH**/ ?>