<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link rel="icon" href="<?php echo e(asset('home/images/favicon.png')); ?>" type="image/png">

    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        /* Custom Scrollbar Styles */
        /* For Webkit browsers (Chrome, Safari) */
        ::-webkit-scrollbar {
            width: 8px;
            background-color: #f1f1f1;
            /* Scrollbar background */
        }

        ::-webkit-scrollbar-thumb {
            background-color: red;
            /* Scroll thumb color */
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background-color: tomato;
            /* Scroll thumb color on hover */
        }

        /* For Firefox */
        scrollbar-width: thin;
        /* Firefox */
        scrollbar-color: #111 #f1f1f1;
        /* Thumb and track color */

        /* Ensure full height and background color */
        html,
        body {
            height: 100%;
            /* Set full height */
            margin: 0;
            /* Remove default margin */
        }

        .bg-gray-100 {
            min-height: 100%;
            /* Ensure full height */
            background-color: #f7fafc;
            padding-top: 50px;
            /* Gray background color */
        }
    </style>
    <!-- Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-gray-100">
    <div class="flex-container">
        <div class="font-sans text-gray-900 antialiased">
            <?php echo e($slot); ?>

        </div>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/layouts/guest.blade.php ENDPATH**/ ?>