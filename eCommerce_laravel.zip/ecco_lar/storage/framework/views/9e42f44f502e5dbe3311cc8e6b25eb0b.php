<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Product Category</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />

    <style>
        .content-wrapper {
            padding: 30px;
        }

        .h2_font {
            font-size: 30px;
            color: #000;
            margin-bottom: 20px;
        }

        .card {
            border: none;
            border-radius: 10px;
            transition: transform 0.2s;
            margin: 15px 0;
            text-align: center;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            border-radius: 10px 10px 0 0;
            max-height: 150px;
            object-fit: cover;
        }

        .card-body {
            padding: 10px;
        }

        .btn-edit {
            font-size: 0.8rem;
        }

        .pagination {
            margin-top: 20px;
        }

        .no-products {
            text-align: center;
            margin-top: 20px;
            font-size: 1.2rem;
            color: #888;
        }

        #modalImage {
            width: 100%;
            height: auto;
            display: block;
        }

        .btn-back {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            margin-bottom: 20px;
            transition: background-color 0.3s;
        }

        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-panel">
            <div class="content-wrapper">
                <h2 class="h2_font">Products in Category: <?php echo e($category->catagory_name); ?></h2>

                <!-- Back Button -->
                <div class="mb-3 text-start">
                    <a href="<?php echo e(url('/view_catagory')); ?>" class="btn btn-secondary">
                        <i class="fa-solid fa-arrow-left"></i> Back
                    </a>
                </div>

                <?php if($products->count()): ?>
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6"> <!-- Responsive columns -->
                        <div class="card mb-4">
                            <img src="<?php echo e(asset('product/' . ($product->image ?: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALgAAACUCAMAAAAXgxO4AAAASFBMVEXv7+9mZmbz8/NhYWHY2Njf39+vr69tbW2Ojo5zc3OgoKB9fX3q6urn5+f39/ddXV3S0tLJyclXV1eEhIS2traXl5fDw8Onp6cRkM0nAAAB7klEQVR4nO3ZYW+qMBSAYdrCEJG2gLr//0/XgiLF3WXjJusxe59kH6ZZ8nI81LkVBQAAAAAAAAAAAAAAAAAAf5W2O+nM3de3nfq85fowmD3UcMzaHcJbX+7gm/zhJ73DSUL4np/rQnjWJf+f8KwI/23fCNe3r4T8cF2cW9Ocu026/PDiOBhl3OWUlosP172auKtNHhcfXry7OfzwauHHOdy8QLheb7M+myl8eBMfrn25KtddG0dumkr6zWn72pSr6epqNE6NXvpxaMvamMYnM++v/fYYFxduy8bExUhmHj6mSX/nDKf2dC8ak8z81q1Xb0Kywq1v5jNEmXo189tnB9uPj40RFT7vya28Le0y6bnbN8OhsvM3osK1f3RPe34f7607bJFpw8ylhcdzUK0YdS+Podq7+Kxr5nJB4eEcdCqxzDyO+H5Vbqxs/F1XTPh6v1d7rudw65dXw8x3qJTwVVmyLdOpqMOePB50TbxDhYRb/zzv+6kY9iS9Ktd2Vkj4Z3uy7LnV26sKey4j/KksLfdm+6wbOwl/ySq+6I7bop6fdW2VP3z023PwG9xYZw9XX8373y+Eyx1+2ZMdZ547/PCy4T9fcML/ZHhxUfUu6j3z/wu7aqcub/fyifLncocDAAAAAAAAAAAAAAAAABYfx1se+dV8iIAAAAAASUVORK5CYII='))); ?>"
                                class="card-img-top product-image" alt="<?php echo e($product->title); ?>"
                                data-bs-toggle="modal" data-bs-target="#imageModal"
                                data-image="<?php echo e(asset('product/' . ($product->image ?: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALgAAACUCAMAAAAXgxO4AAAASFBMVEXv7+9mZmbz8/NhYWHY2Njf39+vr69tbW2Ojo5zc3OgoKB9fX3q6urn5+f39/ddXV3S0tLJyclXV1eEhIS2traXl5fDw8Onp6cRkM0nAAAB7klEQVR4nO3ZYW+qMBSAYdrCEJG2gLr//0/XgiLF3WXjJusxe59kH6ZZ8nI81LkVBQAAAAAAAAAAAAAAAAAAf5W2O+nM3de3nfq85fowmD3UcMzaHcJbX+7gm/zhJ73DSUL4np/rQnjWJf+f8KwI/23fCNe3r4T8cF2cW9Ocu026/PDiOBhl3OWUlosP172auKtNHhcfXry7OfzwauHHOdy8QLheb7M+myl8eBMfrn25KtddG0dumkr6zWn72pSr6epqNE6NXvpxaMvamMYnM++v/fYYFxduy8bExUhmHj6mSX/nDKf2dC8ak8z81q1Xb0Kywq1v5jNEmXo189tnB9uPj40RFT7vya28Le0y6bnbN8OhsvM3osK1f3RPe34f7607bJFpw8ylhcdzUK0YdS+Podq7+Kxr5nJB4eEcdCqxzDyO+H5Vbqxs/F1XTPh6v1d7rudw65dXw8x3qJTwVVmyLdOpqMOePB50TbxDhYRb/zzv+6kY9iS9Ktd2Vkj4Z3uy7LnV26sKey4j/KksLfdm+6wbOwl/ySq+6I7bop6fdW2VP3z023PwG9xYZw9XX8373y+Eyx1+2ZMdZ547/PCy4T9fcML/ZHhxUfUu6j3z/wu7aqcub/fyifLncocDAAAAAAAAAAAAAAAAABYfx1se+dV8iIAAAAAASUVORK5CYII='))); ?>">


                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product->title); ?></h5>
                                <p class="card-text">$<?php echo e(number_format($product->price, 2)); ?></p>
                                <a href="<?php echo e(url('update_product', $product->id)); ?>"
                                    class="btn btn-secondary btn-edit">
                                    <i class="fa-solid fa-pen"></i> Edit
                                </a>
                            </div>
                        </div>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination -->
                <div class="text-center">
                    <?php echo e($products->links('pagination::bootstrap-4')); ?>

                </div>
                <?php else: ?>
                <p class="no-products">No products found in this category.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Image Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Product Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <img id="modalImage" src="" alt="" />
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modalImage = document.getElementById('modalImage');
        const productImages = document.querySelectorAll('.product-image');

        productImages.forEach(image => {
            image.addEventListener('click', function() {
                const src = this.getAttribute('data-image');
                modalImage.src = src;
            });
        });
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/product/product_by_category.blade.php ENDPATH**/ ?>