<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">

    <link rel="stylesheet" href="path/to/your/styles.css"> <!-- Link to your main CSS -->
    <style>
        ::-webkit-scrollbar {
            width: 8px;
            background-color: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background-color: red;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background-color: tomato;
        }

        .bg-gray-100 {
            min-height: 100vh;
        }

        .sidebar {
            height: 100vh;
            overflow: hidden;
        }

        body.sidebar-open {
            overflow: hidden;
        }

        .modal-dialog {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 1rem);
        }
    </style>
</head>

<body class="bg-gray-100">
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
            <a class="sidebar-brand brand-logo-mini" href="index.html">
                <img src="<?php echo e(asset('admin/assets/images/logo-mini.svg')); ?>" alt="logo" />
            </a>
        </div>
        <ul class="nav">
            <li class="nav-item profile">
                <div class="profile-desc">
                    <a href="<?php echo e(route('profile.show')); ?>" style="text-decoration: none;" data-toggle="tooltip"
                        title="View Profile">
                        <div class="profile-pic">
                            <div class="count-indicator">
                                <img class="img-xs rounded-circle"
                                    src="<?php echo e(asset('admin/assets/images/faces/face15.jpg')); ?>" alt="">
                                <span class="count bg-success"></span>
                            </div>
                            <div class="profile-name">
                                <h5 class="mb-0 font-weight-normal" style="text-transform: uppercase; color:white;">
                                    <?php echo e(Auth::user()->name); ?>

                                </h5>
                            </div>
                        </div>
                    </a>
                    <script>
                        $(document).ready(function() {
                            $('[data-toggle="tooltip"]').tooltip();
                        });
                    </script>
                </div>
            </li>

            <li class="nav-item menu-items">
                <a class="nav-link" href="<?php echo e(url('redirect')); ?>">
                    <span class="menu-icon">
                        <i class="fa-solid fa-gauge"></i>
                    </span>
                    <span class="menu-title">Dashboard</span>
                </a>
            </li>
            <li class="nav-item menu-items">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false"
                    aria-controls="ui-basic">
                    <span class="menu-icon">
                        <i class="fa-solid fa-laptop"></i>
                    </span>
                    <span class="menu-title">Products</span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="collapse" id="ui-basic">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/view_product')); ?>">Add Products</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/show_product')); ?>">Show Products</a>
                        </li>
                        <li class="nav-item" style="display: none;">
                            <a class="nav-link" href="<?php echo e(url('/update_product')); ?>">Update Products</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item menu-items">
                <a class="nav-link" href="<?php echo e(url('view_catagory')); ?>">
                    <span class="menu-icon">
                        <i class="fa-solid fa-list"></i>
                    </span>
                    <span class="menu-title">Category</span>
                </a>
            </li>
            <li class="nav-item menu-items">
                <a class="nav-link" href="<?php echo e(url('order')); ?>">
                    <span class="menu-icon">
                        <i class="fa-solid fa-table-list"></i>
                    </span>
                    <span class="menu-title">Orders</span>
                </a>
            </li>

            <li class="nav-item menu-items">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic1" aria-expanded="false"
                    aria-controls="ui-basic1">
                    <span class="menu-icon">
                        <i class="fa-solid fa-laptop"></i>
                    </span>
                    <span class="menu-title">Coupons</span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="collapse" id="ui-basic1">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/show_coupon')); ?>">View Coupons</a>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/coupons')); ?>">Generate Coupons</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item menu-items">
                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <span class="menu-icon">
                        <i class="fa-solid fa-sign-out-alt"></i>
                    </span>
                    <span class="menu-title">Logout</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- Logout Confirmation Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirm Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to logout?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmLogout">Logout</button>
                </div>
            </div>
        </div>
    </div>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('confirmLogout').addEventListener('click', function() {
            document.getElementById('logout-form').submit();
        });
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/sidebar.blade.php ENDPATH**/ ?>