<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="<?php echo e(asset('home/css/bootstrap.css')); ?>" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="<?php echo e(asset('home/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('home/css/style.css')); ?>" rel="stylesheet" />
    <!-- responsive style -->
    <link href="<?php echo e(asset('home/css/responsive.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css"
        integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <?php if(session()->has('message')): ?>
        <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert"
            aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
            <div class="d-flex">
                <div class="toast-body toast-body-custom">
                    <?php echo e(session()->get('message')); ?>

                    <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"
                        aria-label="Close"></button>
                </div>

            </div>
        </div>
    <?php endif; ?>

    <style>
        .toast {

            background-color: aquamarine;
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            min-width: 300px;
        }

        .toast-body-custom {
            font-size: 16px;
            padding: 15px;
        }

        .btn-close-custom {
            color: #fff;
        }
    </style>

    <div class="hero_area">
        <!-- header section strats -->
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header section -->

        <div class="container mt-5">
            <table class="table table-striped table-hover table-bordered text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Product Title</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Payment Status</th>
                        <th>Delivery Status</th>
                        <th>Image</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->product_title); ?></td>
                            <td><?php echo e($order->quantity); ?></td>
                            <td>$ <?php echo e($order->price); ?></td>
                            <td><?php echo e($order->payment_status); ?></td>
                            <td><?php echo e($order->delivery_status); ?></td>
                            <td><img src="product/<?php echo e($order->image); ?>" style="margin:0 auto;" alt="Product Image"
                                    width="50"></td>

                            <?php if($order->delivery_status == 'processing'): ?>
                                <td>
                                    <a href="<?php echo e(url('cancel_order', $order->id)); ?>" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to cancel the order?');">Cancel
                                        Order</a>
                                </td>
                            <?php else: ?>
                                
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

    <!-- footer start -->
    <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer end -->
    <div class="cpy_">
        <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>

            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>

        </p>
    </div>
    <!-- jQery -->
    <script src="<?php echo e(asset('home/js/jquery-3.4.1.min.js')); ?>"></script>
    <!-- popper js -->
    <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
    <!-- custom js -->
    <script src="<?php echo e(asset('home/js/custom.js')); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var toastEl = document.getElementById('toastMessage');
            var toast = new bootstrap.Toast(toastEl, {
                delay: 3000 // Show for 5 seconds
            });
            toast.show();
        });
    </script>
</body>

</html>
<?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/home/order.blade.php ENDPATH**/ ?>