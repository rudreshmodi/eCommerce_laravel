<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link href="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">



    <!-- Layout styles -->
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/images/favicon.png')); ?>" rel="stylesheet" />

    <style>
        body {
            background-color: #212529;
        }

        .container {
            margin-top: 80px;
            max-height: 550px;
            max-width: 1000px;
            padding: 2px 20px;
            background-color: #424242;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #007bff;
            text-align: center;
        }

        label {
            color: white;
            font-weight: bold;
        }

        table th,
        table td {
            text-align: center;
        }



        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 5px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            transition: border-color 0.3s;
            /* margin-bottom: 20px; */
        }

        input:focus,
        select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-submit {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 5px 15px;
            margin-top: 25px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }

        /* .alert {
            margin-bottom: 20px;
        } */

        .error-message {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="text-start">
                <h2>Add Category</h2>
            </div>

            <form action="<?php echo e('/add_catagory'); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-10 form-group">
                        <label for="catagory">Category Name:</label>
                        <input type="text" id="catagory" class="input_color" name="catagory"
                            placeholder="Write Category Name">
                    </div>
                    <div class="col-md-2 form-group">
                        <input type="submit" value="Add Category" class="btn-submit">
                    </div>
                </div>
            </form>

            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th style="color:#fff;">Category Name</th>
                        <th style="color:#fff;">Action</th>
                        <th style="color:#fff;">View Products</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: left; font-size:18px;"><strong><?php echo e($data->catagory_name); ?></strong>
                        </td>
                        <td>
                            <a onclick="return confirm('Are you sure to delete this category?')"
                                class="btn btn-danger" href="<?php echo e(url('delete_catagory', $data->id)); ?>">Delete</a>
                        </td>
                        <td>
                            <a class="btn btn-info"
                                href="<?php echo e(route('product.product_by_category', $data->id)); ?>">View
                                Products</a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class=" mt-2 text-center">
                
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    
                    <?php if($datas->onFirstPage()): ?>
                    <li class="page-item disabled">
                        <span class="page-link">Previous</span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($datas->previousPageUrl()); ?>" rel="prev">Previous</a>
                    </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $datas->getUrlRange(1, $datas->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $datas->currentPage()): ?>
                    <li class="page-item active" aria-current="page">
                        <span class="page-link"><?php echo e($page); ?></span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($datas->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($datas->nextPageUrl()); ?>" rel="next">Next</a>
                    </li>
                    <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">Next</span>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>

    </div>
    </div>

    <!-- JS Links -->
    <script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/catagory.blade.php ENDPATH**/ ?>