<!DOCTYPE html>
<html>

<head>
    <title>Order Delivered</title>
</head>

<body>
    <h1>Your Order #<?php echo e($order->id); ?> has been Delivered!</h1>
    <p>Thank you for shopping with us!</p>
</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/emails/order-delivered.blade.php ENDPATH**/ ?>