<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link href="<?php echo e(asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .content-wrapper {
            padding: 30px;
        }

        .h2_font {
            font-size: 30px;
            color: #fff;
            /* Changed to dark text for visibility */
            margin-bottom: 20px;
        }

        .table {
            margin-top: 20px;
            border-radius: 0.5rem;
            border-radius: 12px;
            background-color: white;
            /* Set table background to white */
        }

        .table thead {
            background-color: Black;
            /* Bootstrap primary color for header */
            color: white;
            border-radius: 12px;
        }

        .table tbody tr:hover {
            background-color: #e9ecef;
            /* Light gray for row hover */
        }

        .table img {
            border-radius: 5px;
            width: 40px;
            height: auto;
            cursor: pointer;
            /* Change cursor to pointer for images */
        }

        .btn-group .btn {
            margin-right: 5px;
        }

        .modal-body {
            font-size: 1rem;
        }

        .pagination .page-item.active .page-link {
            background-color: #007bff;
            /* Active page color */
            border-color: #007bff;
        }

        .alert {
            margin-top: 20px;
        }

        /* Style for the image preview modal */
        .modal-img {
            max-width: fit-content;
            max-height: 400px;
            object-fit: contain;
        }

        .modal-dialog {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(90% - 1rem);
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-panel">
            <div class="content-wrapper">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session()->get('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>

                <h2 class="h2_font">All Products</h2>

                <table class="table text-center">
                    <thead>
                        <tr>
                            <th style="color:#fff;">ID</th>
                            <th style="color:#fff;">Product Name</th>
                            <th style="color:#fff;">Quantity</th>
                            <th style="color:#fff;">Price</th>
                            <th style="color:#fff;">Discount Price</th>
                            <th style="color:#fff;">Category</th>
                            <th style="color:#fff;">Image</th>
                            <th style="color:#fff;">Description</th>
                            <th style="color:#fff;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><strong><?php echo e($product->title); ?></strong></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                            <td>$<?php echo e(number_format($product->discount_price, 2)); ?></td>
                            <td><?php echo e($product->catagory); ?></td>
                            <td>
                                <img src="/product/<?php echo e($product->image); ?>" alt="<?php echo e($product->title); ?>"
                                    class="rounded" data-bs-toggle="modal" data-bs-target="#imageModal"
                                    data-image="/product/<?php echo e($product->image); ?>">
                            </td>
                            <td>
                                <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                    data-bs-target="#descriptionModal"
                                    data-description="<?php echo e($product->description); ?>" title="Show Description">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a class="btn btn-danger delete-btn" data-id="<?php echo e($product->id); ?>"
                                        data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>

                                    <a class="btn btn-secondary" href="<?php echo e(url('update_product', $product->id)); ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="text-center mt-3">
                    <div class="mb-3">
                        Showing <?php echo e($products->firstItem()); ?> to <?php echo e($products->lastItem()); ?> of
                        <?php echo e($products->total()); ?> results
                    </div>
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <?php echo e($products->links('pagination::bootstrap-4')); ?>

                        </ul>
                    </nav>
                </div>

            </div>
        </div>
    </div>

    <!-- JS Links -->
    <script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Modal for Description -->
    <div class="modal fade" id="descriptionModal" tabindex="-1" aria-labelledby="descriptionModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="descriptionModalLabel">Product Title - Description</h5>
                </div>
                <div class="modal-body" id="modal-description"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Image Preview -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Product Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="modal-image" src="" alt="Product Image" class="modal-img" />
                </div>

            </div>
        </div>
    </div>

    <!-- Modal for Delete Confirmation -->
    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this product? This action cannot be undone.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // For description modal
            const buttons = document.querySelectorAll('[data-bs-toggle="modal"]');
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const description = this.getAttribute('data-description');
                    const title = this.closest('tr').querySelector('td:nth-child(2)')
                        .textContent; // Adjust if title position changes

                    document.getElementById('modal-description').textContent = description;
                    document.getElementById('descriptionModalLabel').textContent =
                        `${title} - Description`; // Set the title dynamically
                });
            });

            // For image modal
            const imgButtons = document.querySelectorAll('img[data-bs-toggle="modal"]');
            imgButtons.forEach(img => {
                img.addEventListener('click', function() {
                    const imageUrl = this.getAttribute('data-image');
                    document.getElementById('modal-image').src = imageUrl;
                });
            });
        });



        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.delete-btn');
            let deleteProductId;

            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    deleteProductId = this.getAttribute('data-id');
                });
            });

            document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
                if (deleteProductId) {
                    window.location.href = "<?php echo e(url('delete_product')); ?>/" + deleteProductId;
                }
            });
        });
    </script>

</body>

</html><?php /**PATH /home/xceltec-28/Documents/ecco_lar/resources/views/admin/show_product.blade.php ENDPATH**/ ?>