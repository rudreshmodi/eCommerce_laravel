<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Coupon extends Model
{
    use HasFactory;

    protected $fillable = ['code', 'discount', 'valid_from', 'valid_to', 'usage_option']; // Added usage_option

    public function isValid(): bool
    {
        $now = now(); // Get the current date and time

        // Check if the coupon is active and within the valid date range
        return $this->is_active && $this->valid_from <= $now && $this->valid_to >= $now;
    }

    public function canBeUsed($user): bool
    {
        // Logic for checking if the coupon can be used based on the usage_option
        if ($this->usage_option === 'once') {
            // Check if the coupon has been used by the user
            return !$this->hasBeenUsedByUser($user);
        } elseif ($this->usage_option === 'repeating') {
            // Allow repeated use
            return true;
        }

        return false; // Default case, if usage_option is invalid
    }

    private function hasBeenUsedByUser($user): bool
    {
        // Check if the user has used this coupon
        return $this->users()->where('user_id', $user->id)->exists();
    }

    public function users(): BelongsToMany
    {
        // Define many-to-many relationship with User model
        return $this->belongsToMany(User::class, 'coupon_user');
    }

    // public function coupons()
    // {
    //     return $this->belongsToMany(Coupon::class, 'coupon_user');
    // }
}