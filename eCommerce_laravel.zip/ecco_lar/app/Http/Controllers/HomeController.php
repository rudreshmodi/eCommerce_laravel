<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Order;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Catagory;
use App\Models\Contact;
use App\Models\Reply;
use App\Models\User;
use App\Models\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index()
    {
        $comments = comment::orderBy('id', 'desc')->get();
        $product = Product::paginate(6);
        $reply = reply::all();
        return view('home.userpage', compact('product', 'comments', 'reply'));
    }

    public function contact()
    {
        $contact = []; // Initialize the variable here (you can set actual values as needed)

        return view('home.contact', compact('contact'));
    }


    public function redirect()
    {
        $product = Product::paginate(6);

        $thisusertype = Auth::user()->usertype;

        if ($thisusertype == '1') { // Regular admin
            $total_product = Product::count();
            $total_order = Order::count();
            $total_user = User::count();
            $total_catagory = Catagory::count();

            $orders = Order::paginate(5);
            $contacts = Contact::all();
            $total_revenue = 0;

            foreach ($orders as $order) {
                $total_revenue += $order->price; // Calculate total revenue
            }

            $total_delivered = Order::where('delivery_status', 'delivered')->count();
            $total_processing = Order::where('delivery_status', 'Processing')->count();

            return view('admin.home', compact('total_product', 'total_order', 'contacts', 'total_user', 'total_revenue', 'total_delivered', 'total_processing', 'total_catagory', 'orders'));
        } elseif ($thisusertype == '2') { // Master admin

            $total_admin = User::where('usertype', 1)->count();
            $total_user = User::where('usertype', 0)->count();
            $orders = Order::paginate(5);
            $total_revenue = 0;

            foreach ($orders as $order) {
                $total_revenue += $order->price; // Calculate total revenue
            }

            // You can add more data or analytics specific to the master admin here

            return view('masteradmin.masteradmin', compact('total_admin', 'total_user', 'total_revenue'));
        } else { // Regular user
            $reply = Reply::all();
            $comments = Comment::orderBy('id', 'desc')->get();
            return view('home.userpage', compact('product', 'comments', 'reply'));
        }
    }


    public function product_details($id)
    {
        if (Auth::id()) {
            $product = product::find($id);
            return view('home.product_details', compact('product'));
        } else {
            return redirect('login');
        }
    }


    public function add_cart(Request $request, $id)
    {
        if (Auth::id()) {
            $user = Auth::user();
            $product = Product::find($id);
            $requestedQuantity = $request->quantity;

            // Check if the product quantity is less than requested quantity
            if ($product->quantity < $requestedQuantity) {
                return redirect()->back()->with('error', 'Not enough stock available. Only ' . $product->quantity . ' left in stock.');
            }

            $cart = new Cart;

            $cart->name = $user->name;
            $cart->email = $user->email;
            $cart->phone = $user->phone;
            $cart->address = $user->address;
            $cart->user_id = $user->id;

            if ($product->discount_price != null) {
                $cart->price = $product->discount_price * $requestedQuantity;
            } else {
                $cart->price = $product->price * $requestedQuantity;
            }

            $cart->product_title = $product->title;
            $cart->image = $product->image;
            $cart->product_id = $product->id;
            $cart->quantity = $requestedQuantity;

            // Reduce the product quantity from stock after adding to cart
            $product->quantity -= $requestedQuantity;
            $product->save();

            $cart->save();

            return redirect()->back()->with('message', 'Product added successfully. See your cart.');
        } else {
            return redirect('login');
        }
    }

    public function show_cart()
    {
        if (Auth::id()) {
            $id = Auth::user()->id;
            $cart = cart::where('user_id', '=', $id)->get();
            return view('home.show_cart', compact('cart'));
        } else {
            return redirect('login');
        }
    }

    public function remove_cart($id)
    {
        $cart = cart::find($id);
        $cart->delete();
        return redirect()->back();
    }

    public function cash_order()
    {
        $user = Auth::user();
        $userid = $user->id;

        // Fetch all items in the user's cart
        $data = cart::where('user_id', '=', $userid)->get();

        // Prepare variables to store aggregated product details
        $productTitles = [];
        $productQuantities = [];
        $productimage = [];
        $productid = [];
        $totalPrice = 0;


        foreach ($data as $cartItem) {
            // Collect product titles and quantities
            $productTitles[] = $cartItem->product_title;
            $productQuantities[] = $cartItem->quantity;
            $productimage[] = $cartItem->image;
            $productid[] = $cartItem->product_id;
            $totalPrice += $cartItem->price * $cartItem->quantity; // Calculate total price

            // Update product quantity in the product table
            $product = product::find($cartItem->product_id);
            if ($product) {
                $product->quantity -= $cartItem->quantity; // Decrease the product quantity
                $product->save(); // Save the updated product
            }

            // Delete the cart item
            $cartItem->delete();
        }

        // Create a single order
        $order = new order;

        $order->name = $user->name; // Assuming user's name is to be used
        $order->email = $user->email;
        $order->phone = $user->phone; // Assuming phone is stored in the user model
        $order->address = $user->address; // Assuming address is stored in the user model
        $order->user_id = $userid;
        $order->product_title = implode(', ', $productTitles); // Concatenate product titles
        $order->image = implode(', ', $productimage);
        $order->quantity = implode(', ', $productQuantities); // Concatenate quantities
        $order->product_id = implode(', ', $productid);
        $order->price = $totalPrice; // Total price for the order
        $order->payment_status = 'cash on delivery';
        $order->delivery_status = 'Processing';

        $order->save(); // Save the order

        return redirect('/')->with('message', 'We received your order. We will connect with you soon.');
    }


    public function stripe($totalprice)
    {
        return view('home.stripe', compact('totalprice'));
    }



    public function show_order()
    {
        if (Auth::id()) {
            $user = Auth::user();
            $userid = $user->id;

            $order = order::where('user_id', '=', $userid)->get();
            return view('home.order', compact('order'));
        } else {
            return redirect('login');
        }
    }

    public function cancel_order($id)
    {
        $order = order::find($id);
        $order->delivery_status = 'You canceled the order';

        $order->save();

        return redirect()->back();
    }

    public function add_comment(Request $request)
    {
        if (Auth::id()) {
            $comment = new comment;
            $comment->name = Auth::user()->name;
            $comment->user_id = Auth::user()->id;
            $comment->comment = $request->comment;

            $comment->save();

            return redirect()->back();
        } else {
            return redirect('login');
        }
    }

    public function add_reply(Request $request)
    {
        if (Auth::id()) {

            $reply = new reply;

            $reply->name = Auth::user()->name;
            $reply->user_id = Auth::user()->id;
            $reply->comment_id = $request->commentId;
            $reply->reply = $request->reply;
            $reply->save();

            return redirect()->back();
        } else {
            return redirect('login');
        }
    }

    // contact us controller


    public function showForm()
    {
        if (Auth::id()) {
            return view('home.contact'); // Your contact form view
        } else {
            return redirect('login');
        }
    }

    public function submitContact(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
        ]);

        Contact::create($request->all());

        return redirect()->back()->with('message', 'Your message has been sent!');
    }
}
