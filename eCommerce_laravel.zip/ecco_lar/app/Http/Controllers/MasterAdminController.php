<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\Country;
use App\Models\new_web;
use App\Models\State;
use App\Models\User;
use Illuminate\Http\Request;

class MasterAdminController extends Controller
{
    public function admindetails()
    {
        // Get only users with is_admin = 1
        $admins = User::where('usertype', 1)->get();

        // Pass the data to the view
        return view('masteradmin.admindetails', compact('admins'));
    }

    public function create_new_web()
    {
        $countries = Country::where('active_deactive', true)->with(['country'])->get();
        $state = State::where('active_deactive', true)->with('country')->get(); // Ensure State model has 'id' and 'name' fields
        $city = City::with(['country', 'state'])->where('active_deactive', true)->with(relations: 'state')->get();

        return view('masteradmin.create_new_web', compact('countries', 'state', 'city'));
    }

    public function userdetails()
    {
        // Fetch paginated users where 'usertype' is 0 (admins), with 5 users per page
        $users = User::where('usertype', 0)->paginate(5); // Ensure you are using paginate() method

        return view('masteradmin.userdetails', compact('users'));
    }

    public function edit_admin($id)
    {
        $admin = user::find($id);

        // $catagory = catagory::all();
        return view('masteradmin.edit_admin', compact('admin'));
    }

    public function update_admin(Request $request, $id)
    {
        // dd($request);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id, // Unique, excluding current admin's email
            'phone' => 'required|numeric',
            'password' => 'nullable|string|min:6', // Optional for updates
            'usertype' => 'required|string|in:0,1,2', // Adjust as needed
            'address' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
        ]);

        $admin = user::findOrFail($id);
        $admins = User::where('usertype', 1)->get();
        $admin->name = $request->input('name');
        $admin->email = $request->input('email');
        $admin->phone = $request->input('phone');
        $admin->password = bcrypt($request->input('password'));
        $admin->usertype = $request->input('usertype');
        $admin->address = $request->input('address');
        $admin->image = $request->input('image');

        $admin->save();
        return redirect()->route('masteradmin.admindetails')->with('message', 'User type updated successfully.');
    }

    public function update_user(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id, // Unique, excluding current admin's email
            'phone' => 'required|numeric',
            'password' => 'nullable|string|min:6', // Optional for updates
            'usertype' => 'required|string|in:0,1,2', // Adjust as needed
            'address' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
        ]);

        $user = user::findOrFail($id);
        $users = User::where('usertype', 0)->get();
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->phone = $request->input('phone');
        $user->password = bcrypt($request->input('password'));
        $user->usertype = $request->input('usertype');
        $user->address = $request->input('address');
        $user->image = $request->input('image');

        $user->save();
        return redirect()->route('masteradmin.userdetails')->with('message', 'User type updated successfully.');
    }

    public function edit_user($id)
    {
        $user = user::find($id);
        // $catagory = catagory::all();
        return view('masteradmin.edit_user', compact('user'));
    }

    public function delete_admin($id)
    {
        $data = user::find($id);
        if ($data) {
            $data->delete();
            return redirect()->back()->with('message', 'Admin Deleted Successfully');
        } else {
            return redirect()->back()->with('error', 'Admin Not Found');
        }
    }

    public function delete_User($id)
    {
        $data = user::find($id);
        if ($data) {
            $data->delete();
            return redirect()->back()->with('message', 'User Deleted Successfully');
        } else {
            return redirect()->back()->with('error', 'Admin Not Found');
        }
    }

    public function toggleUserType($id, Request $request)
    {
        $user = User::findOrFail($id);
        $user->usertype = $request->input('usertype');
        $user->save();

        // Redirect back to the previous page with a success message
        return redirect()->back()->with('message', 'User type updated successfully.');
    }

    public function getCountries()
    {
        return response()->json(Country::all());
    }

    public function getStates($countryId)
    {
        return response()->json(State::where('country_id', $countryId)->get());
    }

    public function getCities($stateId)
    {
        $cities = City::where('state_id', $stateId)->get();
        return response()->json($cities);
    }

    public function add_new_web(Request $request)
    {
        // Validate the request
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phonenumber' => 'required|numeric',
            'password' => 'required|string|min:6',
            'country_id' => 'required|exists:countries,id',
            'state_id' => 'required|exists:states,id',
            'city_id' => 'required|exists:cities,id',
            'address' => 'required|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
        ]);

        // dd($request);
        // Create a new instance of the model
        $new_web = new New_Web; // Ensure you have the correct model name with casing

        // Assign values to the model
        $new_web->name = $request->name;
        $new_web->email = $request->email;
        $new_web->phonenumber = $request->phonenumber;
        $new_web->password = bcrypt($request->password);
        $new_web->country_id = $request->country_id;
        $new_web->state_id = $request->state_id;
        $new_web->city_id = $request->city_id;
        $new_web->address = $request->address;

        // Handle image upload
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            if ($image->isValid()) {
                $imagename = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('/new_web'), $imagename); // Use public_path for clarity
                $new_web->image = $imagename;
            } else {
                return redirect()->back()->withErrors(['image' => 'Invalid image file.']);
            }
        }

        // Save the new entry to the database
        $new_web->save();

        // Redirect with success message
        return redirect()->back()->with('message', 'New Web Added Successfully');
    }
}
