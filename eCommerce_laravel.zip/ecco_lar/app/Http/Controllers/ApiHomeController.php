<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Catagory;
use App\Models\Comment;
use App\Models\Contact;
use App\Models\Order;
use App\Models\Product;
use App\Models\Reply;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ApiHomeController extends Controller
{
    public function index()
    {
        $comments = Comment::orderBy('id', 'desc')->get();
        $products = Product::paginate(6);
        $replies = Reply::all();

        return response()->json([
            'products' => $products,
            'comments' => $comments,
            'replies' => $replies
        ], 200);
    }

    // API for submitting a contact form
    public function submitContact(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
        ]);

        Contact::create($request->all());

        return response()->json(['message' => 'Your message has been sent!'], 200);
    }

    // API for redirecting users based on their type
    public function redirect()
    {
        $userType = Auth::user()->usertype;

        if ($userType == '1') { // Admin
            $totalProduct = Product::count();
            $totalOrder = Order::count();
            $totalUser = User::count();
            $totalCatagory = Catagory::count();
            $orders = Order::paginate(5);
            $contacts = Contact::all();
            $totalRevenue = $orders->sum('price');
            $totalDelivered = Order::where('delivery_status', 'delivered')->count();
            $totalProcessing = Order::where('delivery_status', 'Processing')->count();

            return response()->json([
                'total_product' => $totalProduct,
                'total_order' => $totalOrder,
                'total_user' => $totalUser,
                'total_revenue' => $totalRevenue,
                'total_delivered' => $totalDelivered,
                'total_processing' => $totalProcessing,
                'orders' => $orders,
                'contacts' => $contacts,
                'total_catagory' => $totalCatagory
            ], 200);
        } elseif ($userType == '2') { // Master admin
            return response()->json(['message' => 'Master admin area'], 200);
        } else { // Regular user
            return response()->json(['message' => 'User page data'], 200);
        }
    }

    // API for fetching product details
    public function productDetails($id)
    {
        $product = Product::find($id);

        if ($product) {
            return response()->json($product, 200);
        } else {
            return response()->json(['message' => 'Product not found'], 404);
        }
    }

    // API for adding a product to the cart
    public function addCart(Request $request, $id)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        $user = Auth::user();
        $product = Product::find($id);

        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }

        // Check if the product is already in the cart
        $cartItem = Cart::where('user_id', $user->id)->where('product_id', $product->id)->first();

        if ($cartItem) {
            // Update the quantity if already in cart
            $cartItem->quantity += $request->quantity;
            $cartItem->save();
        } else {
            // Create a new cart entry
            $cart = new Cart;
            $cart->user_id = $user->id;
            $cart->product_id = $product->id;
            $cart->price = $product->discount_price ?? $product->price;
            $cart->quantity = $request->quantity;
            $cart->save();
        }

        return response()->json(['message' => 'Product added to cart successfully'], 200);
    }

    // API for showing the cart
    public function showCart()
    {
        // Fetch cart items for the authenticated user
        $cartItems = Cart::where('user_id', auth()->id())->get();

        // Return the cart data as JSON or to a view
        return response()->json($cartItems);
    }

    // API for removing an item from the cart
    public function removeCart($id)
    {
        $cartItem = Cart::find($id);

        if ($cartItem) {
            $cartItem->delete();
            return response()->json(['message' => 'Item removed from cart'], 200);
        } else {
            return response()->json(['message' => 'Cart item not found'], 404);
        }
    }

    // API for placing a cash order
    public function cashOrder()
    {
        $user = Auth::user();
        $cartItems = Cart::where('user_id', $user->id)->get();

        if ($cartItems->isEmpty()) {
            return response()->json(['message' => 'Cart is empty'], 400);
        }

        $totalPrice = 0;

        DB::beginTransaction(); // Start transaction

        try {
            foreach ($cartItems as $cartItem) {
                $product = Product::find($cartItem->product_id);
                if (!$product || $product->quantity < $cartItem->quantity) {
                    return response()->json(['message' => 'Insufficient stock for product: ' . $product->title], 400);
                }

                $totalPrice += $cartItem->price * $cartItem->quantity;
                $product->quantity -= $cartItem->quantity;
                $product->save();
                $cartItem->delete();
            }

            $order = new Order();
            $order->user_id = $user->id;
            $order->price = $totalPrice;
            $order->payment_status = 'cash on delivery';
            $order->delivery_status = 'Processing';
            $order->save();

            DB::commit(); // Commit transaction

            return response()->json(['message' => 'Order placed successfully', 'order_id' => $order->id], 200);
        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction on error
            return response()->json(['message' => 'Error placing order: ' . $e->getMessage()], 500);
        }
    }

    // API for showing user's orders
    public function showOrder()
    {
        $user = Auth::user();

        if (!$user) {
            return response()->json(['message' => 'User not authenticated'], 401);
        }

        $orders = Order::where('user_id', $user->id)->with('orderItems')->paginate(10); // Assuming you have a relation for order items

        return response()->json([
            'message' => 'Orders retrieved successfully',
            'data' => $orders,
        ], 200);
    }


    // API for canceling an order
    public function cancelOrder($id)
    {
        $user = Auth::user();

        // Find the order
        $order = Order::find($id);

        // Check if the order exists and belongs to the authenticated user
        if ($order && $order->user_id === $user->id) {
            // Check if the order is still cancelable
            if ($order->delivery_status === 'Processing') {
                $order->delivery_status = 'You canceled the order';
                $order->save();

                return response()->json(['message' => 'Order canceled successfully', 'order' => $order], 200);
            } else {
                return response()->json(['message' => 'Order cannot be canceled'], 400);
            }
        }

        return response()->json(['message' => 'Order not found or not authorized'], 404);
    }


    // API for adding a comment
    public function addComment(Request $request)
    {
        $comment = new Comment();
        $comment->user_id = Auth::id();
        $comment->comment = $request->comment;
        $comment->save();

        return response()->json(['message' => 'Comment added'], 200);
    }

    // API for adding a reply to a comment
    public function addReply(Request $request)
    {
        $reply = new Reply();
        $reply->user_id = Auth::id();
        $reply->comment_id = $request->comment_id;
        $reply->reply = $request->reply;
        $reply->save();

        return response()->json(['message' => 'Reply added'], 200);
    }

    public function product_details($id)
    {
        $product = Product::find($id);
        if ($product) {
            return response()->json([
                'success' => true,
                'product' => $product,
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Product not found',
            ], 404);
        }
    }

    public function update_product(Request $request, $id)
    {
        // Check if the user is authenticated
        if (Auth::id()) {
            // Find the product by ID
            $product = Product::find($id);

            // Check if the product exists
            if ($product) {
                // Validate incoming request
                $request->validate([
                    'title' => 'required|string|max:255',
                    'description' => 'required|string',
                    'quantity' => 'required|integer|min:0',
                    'price' => 'required|numeric',
                    'discount_price' => 'nullable|numeric',
                    'catagory' => 'required|string',
                    'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Optional image update
                ]);

                // Update product fields
                $product->title = $request->title;
                $product->description = $request->description;
                $product->quantity = $request->quantity;
                $product->price = $request->price;
                $product->discount_price = $request->discount_price;
                $product->catagory = $request->catagory;

                // Check if a new image is uploaded
                if ($request->hasFile('image')) {
                    $image = $request->file('image');
                    $imagename = time() . '.' . $image->getClientOriginalExtension();
                    $image->move('product', $imagename);
                    $product->image = $imagename; // Set the new image
                }

                // Save the updated product
                $product->save();

                return response()->json([
                    'success' => true,
                    'message' => 'Product updated successfully',
                    'product' => $product,
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Product not found',
                ], 404);
            }
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }
    }

    public function delete_product($id)
    {
        // Check if the user is authenticated
        if (Auth::id()) {
            // Find the product by ID
            $product = Product::find($id);

            // Check if the product exists
            if ($product) {
                $product->delete(); // Delete the product

                return response()->json([
                    'success' => true,
                    'message' => 'Product deleted successfully',
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Product not found',
                ], 404);
            }
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }
    }
}
