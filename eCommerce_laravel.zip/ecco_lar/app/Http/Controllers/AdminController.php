<?php

namespace App\Http\Controllers;

use App\Models\Catagory;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf as FacadePdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use PDF;

class AdminController extends Controller
{

    public function showDashboard() // or whatever method is appropriate
    {
        $users = User::all(); // Fetch all users
        return view('dashboard', compact('users')); // Ensure 'dashboard' is your view name
    }

    public function view_catagory()
    {
        // $data=catagory::all();
        $datas = catagory::paginate(5);
        return view('admin.catagory', compact('datas'));
    }
    public function add_catagory(Request $request)
    {
        $data = new catagory;
        $data->catagory_name = $request->catagory;
        $data->save();
        return redirect()->back()->with('message', 'Category Added Successfully');
    }

    public function delete_catagory($id)
    {
        $data = catagory::find($id);
        $data->delete();
        return redirect()->back()->with('message', 'Category Deleted Successfully');
    }

    public function view_product()
    {
        $catagory = catagory::all();
        return view('admin.product', compact('catagory'));
    }

    public function order_details($id)
    {
        $details = order::find($id);
        return view('admin.order_details', compact('details'));
    }

    public function add_product(Request $request)
    {
        // Validate incoming request
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'quantity' => 'required|integer|min:0',
            'price' => 'required|numeric',
            'discount_price' => 'nullable|numeric',
            'catagory' => 'required|string',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Add image validation
        ]);

        $product = new Product;

        $product->title = $request->title;
        $product->description = $request->description;
        $product->quantity = $request->quantity;
        $product->price = $request->price;
        $product->discount_price = $request->discount_price;
        $product->catagory = $request->catagory;

        // Check if an image is uploaded
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imagename = time() . '.' . $image->getClientOriginalExtension();

            // Move the uploaded image to the specified directory
            $image->move('product', $imagename);
            $product->image = $imagename; // Set the product image
        } else {
            return redirect()->back()->withErrors(['image' => 'Image is required.']);
        }

        $product->save();

        return redirect()->back()->with('message', 'Product Added Successfully');
    }


    public function show_product()
    {
        // $product=product::all();
        $products = product::paginate(5);
        return view('admin.show_product', compact('products'));
    }

    public function delete_product($id)
    {
        $data = product::find($id);
        $data->delete();
        return redirect()->back()->with('message', 'Category Deleted Successfully');
    }

    public function update_product($id)
    {
        $product = product::find($id);
        $catagory = catagory::all();
        return view('admin.update_product', compact('product', 'catagory'));
    }

    public function update_product_confirm(Request $request, $id)
    {
        $product = Product::find($id);

        // Update product fields with new values
        $product->title = $request->title;
        $product->description = $request->description;
        $product->quantity = $request->quantity;
        $product->price = $request->price;
        $product->discount_price = $request->discount_price;
        $product->catagory = $request->catagory;

        // Check if a new image is uploaded
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imagename = time() . '.' . $image->getClientOriginalExtension();
            $image->move('product', $imagename);
            $product->image = $imagename; // Set the new image
        }
        // If no new image is uploaded, the old image remains unchanged
        // Save the updated product
        $product->save();

        return redirect()->route('show.product')->with('message', 'Product updated successfully.');
    }

    public function order()
    {
        // $order=order::all();
        $orders = order::paginate(5);

        return view('admin.order', compact('orders'));
    }


    public function delivered($id)
    {
        $order = order::find($id);
        $order->delivery_status = "delivered";
        $order->payment_status = "Paid";

        $order->save();
        return redirect()->back();
    }

    public function cancel($id)
    {
        $order = Order::find($id);

        if ($order) {
            // Logic to cancel the order
            $order->delivery_status = 'Cancelled';
            $order->save();

            return redirect()->back()->with('success', 'Order cancelled successfully.');
        }
        return redirect()->back()->with('error', 'Order not found.');
    }

    public function print_pdf($id)
    {
        $order = order::find($id);

        $userName = $order->name;

        $fileName = preg_replace('/[^A-Za-z0-9_\-]/', '_', $userName) . '_order_details.pdf';

        $pdf = FacadePdf::loadView('admin.pdf', compact('order'));

        // Download the PDF with the user's name
        return $pdf->download($fileName);
    }


    public function searchdata(Request $request)
    {
        $searchText = $request->search;

        $orders = order::where('name', 'LIKE', "%$searchText%")->paginate(3);
        return view('admin.order', compact('orders'));
    }
}
