<?php

namespace App\Http\Controllers;

use App\Models\Catagory;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ApiAdminController extends Controller
{
    public function showDashboard()
    {
        $users = User::all();
        return response()->json([
            'success' => true,
            'data' => $users
        ]);
    }

    public function view_catagory()
    {
        $datas = Catagory::paginate(5);
        return response()->json([
            'success' => true,
            'data' => $datas
        ]);
    }

    public function add_catagory(Request $request)
    {
        $request->validate([
            'catagory' => 'required|string|max:255',
        ]);

        $data = new Catagory;
        $data->catagory_name = $request->catagory;
        $data->save();

        return response()->json([
            'success' => true,
            'message' => 'Category Added Successfully'
        ]);
    }

    public function delete_catagory($id)
    {
        $data = Catagory::find($id);

        if ($data) {
            $data->delete();
            return response()->json([
                'success' => true,
                'message' => 'Category Deleted Successfully'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Category not found'
        ], 404);
    }

    public function view_product()
    {
        $catagory = Catagory::all();
        return response()->json([
            'success' => true,
            'data' => $catagory
        ]);
    }

    public function order_details($id)
    {
        $details = Order::find($id);

        if ($details) {
            return response()->json([
                'success' => true,
                'data' => $details
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Order not found'
        ], 404);
    }

    public function add_product(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'quantity' => 'required|integer|min:0',
            'price' => 'required|numeric',
            'discount_price' => 'nullable|numeric',
            'catagory' => 'required|string',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $product = new Product;
        $product->title = $request->title;
        $product->description = $request->description;
        $product->quantity = $request->quantity;
        $product->price = $request->price;
        $product->discount_price = $request->discount_price;
        $product->catagory = $request->catagory;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imagename = time() . '.' . $image->getClientOriginalExtension();
            $image->move('product', $imagename);
            $product->image = $imagename;
        }

        $product->save();

        return response()->json([
            'success' => true,
            'message' => 'Product Added Successfully'
        ]);
    }

    public function show_product()
    {
        $products = Product::paginate(5);
        return response()->json([
            'success' => true,
            'data' => $products
        ]);
    }

    public function delete_product($id)
    {
        $data = Product::find($id);

        if ($data) {
            $data->delete();
            return response()->json([
                'success' => true,
                'message' => 'Product Deleted Successfully'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Product not found'
        ], 404);
    }

    public function update_product($id)
    {
        $product = Product::find($id);

        if ($product) {
            $catagory = Catagory::all();
            return response()->json([
                'success' => true,
                'data' => compact('product', 'catagory')
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Product not found'
        ], 404);
    }

    public function update_product_confirm(Request $request, $id)
    {
        $product = Product::find($id);

        if ($product) {
            $product->title = $request->title;
            $product->description = $request->description;
            $product->quantity = $request->quantity;
            $product->price = $request->price;
            $product->discount_price = $request->discount_price;
            $product->catagory = $request->catagory;

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imagename = time() . '.' . $image->getClientOriginalExtension();
                $image->move('product', $imagename);
                $product->image = $imagename;
            }

            $product->save();

            return response()->json([
                'success' => true,
                'message' => 'Product updated successfully'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Product not found'
        ], 404);
    }

    public function order()
    {
        $orders = Order::paginate(5);
        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }

    public function delivered($id)
    {
        $order = Order::find($id);

        if ($order) {
            $order->delivery_status = 'delivered';
            $order->payment_status = 'Paid';
            $order->save();

            return response()->json([
                'success' => true,
                'message' => 'Order marked as delivered'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Order not found'
        ], 404);
    }

    public function cancel($id)
    {
        $order = Order::find($id);

        if ($order) {
            $order->delivery_status = 'Cancelled';
            $order->save();

            return response()->json([
                'success' => true,
                'message' => 'Order cancelled successfully'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Order not found'
        ], 404);
    }

    public function print_pdf($id)
    {
        $order = Order::find($id);

        if ($order) {
            $pdf = \PDF::loadView('admin.pdf', compact('order'));
            return $pdf->download('order_details.pdf');
        }

        return response()->json([
            'success' => false,
            'message' => 'Order not found'
        ], 404);
    }

    public function searchdata(Request $request)
    {
        $searchText = $request->search;

        $orders = Order::where('name', 'LIKE', "%$searchText%")->paginate(3);
        return response()->json([
            'success' => true,
            'data' => $orders
        ]);
    }
}
