<?php

namespace App\Http\Controllers;

use App\Mail\OrderDelivered;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class OrderController extends Controller
{
    public function markAsDelivered($id)
    {
        $order = Order::with('user')->find($id); // Eager load the user

        if (!$order) {
            return redirect()->back()->with('error', 'Order not found.');
        }

        if (!$order->user) {
            return redirect()->back()->with('error', 'User not found for this order.');
        }

        // Update the delivery status
        $order->delivery_status = 'Delivered';
        $order->save();

        // Send email to the user
        Mail::to($order->user->email)->send(new OrderDelivered($order));

        return redirect()->back()->with('success', 'Order marked as delivered and email sent.');
    }
}
