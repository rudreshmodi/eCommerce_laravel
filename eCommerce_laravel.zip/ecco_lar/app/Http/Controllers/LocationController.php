<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\Country;
use App\Models\State;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    public function storeCountry(Request $request)
    {
        $request->validate([
            'country' => 'required|string|max:255|unique:countries,country',
            'country_code' => 'required|integer|min:1|unique:countries,country_code',
        ]);
        $data = new Country;
        $data->country = $request->country;
        $data->country_code = $request->country_code;

        $data->save();

        return redirect()->back()->with('success', 'Country added successfully!');
    }

    public function storeState(Request $request)
    {
        $request->validate([
            'state' => 'required|string|max:255|unique:states,state,NULL,id,country_id,' . $request->country_id,
            'country_id' => 'required|integer|exists:countries,id',
        ]);
        $data = new State;

        $data->state = $request->state;
        $data->country_id = $request->country_id;

        $data->save();

        return redirect()->back()->with('success', 'State added successfully!');
    }

    public function storeCity(Request $request)
    {
        $request->validate([
            'city' => 'required|string|max:255|unique:cities,city,NULL,id,state_id,' . $request->state_id,
            'country_id' => 'required|integer|exists:countries,id',
            'state_id' => 'required|integer|exists:states,id',
        ]);
        $data = new City;

        $data->city = $request->city;
        $data->state_id = $request->state_id;
        $data->country_id = $request->country_id;
        $data->save();

        return redirect()->back()->with('success', 'City added successfully!');
    }

    public function getStates($countryId)
    {
        $states = State::where('country_id', $countryId)->get();
        return response()->json($states);
    }
    public function add_country()
    {
        $countries = Country::all();
        return view('location.add_country', compact('countries'));
    }

    public function add_state()
    {
        $states = State::where('active_deactive', true)->with('country')->get();
        $countries = Country::where('active_deactive', true)->get(['country', 'id']);
        return view('location.add_state', compact('countries', 'states'));
    }

    public function add_city()
    {
        $countries = Country::where('active_deactive', true)->get(['id', 'country']); // Include 'id' for AJAX
        $states = State::where('active_deactive', true)->get(['id', 'state']);
        $citys = City::with(['country', 'state'])->where('active_deactive', true)->get();

        return view('location.add_city', compact('countries', 'states', 'citys'));
    }
    public function edit_country($id)
    {

        $country = Country::findOrFail($id);
        $countries = Country::all();
        return view('location.edit_country', compact('country', 'countries'));
    }

    public function edit_state($id)
    {
        $state = State::find($id);
        $countries = Country::where('active_deactive', true)->get(); // Only active countries
        return view('location.edit_state', compact('state', 'countries'));
    }

    public function edit_city($id)
    {
        $city = City::find($id);
        $countries = Country::where('active_deactive', true)->get(); // Only active countries
        $state = State::where('id', $city->state_id)->first();

        return view('location.edit_city', compact('city', 'state', 'countries'));
    }

    public function update_country(Request $request, $id)
    {

        $country = Country::findOrFail($id);

        // Update fields
        $country->country = $request->input('country'); // Update to country name
        $country->country_code = $request->input('country_code');
        $country->save();

        // Redirect with success message
        return redirect()->route('location.add_country')->with('success', 'Country updated successfully.');
    }

    public function update_state(Request $request, $id)
    {
        $state = state::findOrFail($id);

        $state->country_id = $request->input('country_id');
        $state->state = $request->input('state');

        $state->save();

        // Redirect with success message
        return redirect()->route('location.add_state')->with('success', 'Country updated successfully.');
    }

    public function update_city(Request $request, $id)
    {
        $city = city::findOrFail($id);

        $city->country_id = $request->input('country_id');
        $city->state_id = $request->input('state_id');
        $city->city = $request->input('city');

        $city->save();

        // Redirect with success message
        return redirect()->route('location.add_city')->with('success', 'Country updated successfully.');
    }

    public function delete_country($id)
    {
        $data = Country::find($id);
        $data->delete();
        return redirect()->back()->with('message', 'Country Deleted Successfully');
    }

    public function delete_state($id)
    {
        $data = state::find($id);
        $data->delete();
        return redirect()->back()->with('message', 'State Deleted Successfully');
    }

    public function delete_city($id)
    {
        $data = city::find($id);
        $data->delete();
        return redirect()->back()->with('message', 'State Deleted Successfully');
    }

    public function toggleCountryStatus($id, Request $request)
    {
        $country = Country::findOrFail($id);
        $country->active_deactive = $request->input('active');
        $country->save();

        // Optionally deactivate related states and cities
        if (!$country->active_deactive) {
            State::where('country_id', $id)->update(['active_deactive' => false]);
            City::where('country_id', $id)->update(['active_deactive' => false]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Country status updated successfully',
            'active' => $country->active_deactive,
        ]);
    }

    public function toggleStateStatus($id, Request $request)
    {
        // Find the country by ID
        $state = State::findOrFail($id);
        // Update the active status based on the request
        $state->active_deactive = $request->input('active');
        $state->save();

        // Optionally, return a response
        return response()->json([
            'success' => true,
            'message' => 'State status updated successfully',
            'active' => $state->active_deactive,
        ]);
    }

    public function toggleCityStatus($id, Request $request)
    {
        // Find the country by ID
        $city = City::findOrFail($id);
        // Update the active status based on the request
        $city->active_deactive = $request->input('active');
        $city->save();

        // Optionally, return a response
        return response()->json([
            'success' => true,
            'message' => 'City status updated successfully',
            'active' => $city->active_deactive,
        ]);
    }
}
