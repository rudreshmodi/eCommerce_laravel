<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Coupon;
use Illuminate\Http\Request;

class CouponController extends Controller
{
    public function create(Request $request)
    {
        $request->validate([
            'code' => 'required|unique:coupons|max:50',
            'discount' => 'required|numeric',
            'valid_from' => 'required|date',
            'usage_option' => 'required', // Corrected this line
            'valid_to' => 'required|date|after_or_equal:valid_from',
        ]);

        Coupon::create($request->all());

        return redirect()->back()->with('success', 'Coupon created successfully.');
    }



    public function show_coupon()
    {
        // $coupon = Coupon::all();
        $coupons = Coupon::paginate(5);

        return view('admin.show_coupon', compact('coupons'));
    }

    public function coupon_delete($id)
    {
        $coupon = coupon::find($id);

        $coupon->delete();
        return redirect()->back()->with('message', 'Coupon Deleted Successfully');
    }

    public function edit_coupon($id)
    {
        $coupon = coupon::find($id);
        // $catagory = catagory::all();
        return view('admin.edit_coupon', compact('coupon'));
    }

    public function validateCoupon(Request $request)
    {
        $user_id = auth()->user()->id;
        $cartItems = Cart::where('user_id', $user_id)->get();
        $totalPrice = $cartItems->sum('price');
        $couponCode = $request->input('coupon_code');
        $coupon = Coupon::where('code', $couponCode)->first();

        if ($coupon && $couponCode) {
            // Check if the coupon is valid based on dates
            $currentDate = now(); // Use the current date and time

            if ($currentDate->isBetween($coupon->valid_from, $coupon->valid_to)) {
                // Check if the coupon can be used by the user
                if ($coupon->canBeUsed(auth()->user())) {
                    $discount = $coupon->discount;
                    $discountedPrice = max(0, $totalPrice - $discount); // Ensure we don't have a negative price

                    // If the coupon is for "once" usage, you should mark it as used
                    if ($coupon->usage_option === 'once') {
                        $coupon->users()->attach($user_id); // Record the coupon usage
                    }

                    return redirect()->back()->with([
                        'discounted_price' => $discountedPrice,
                        'message' => 'Coupon applied successfully!',
                        'total_price' => $totalPrice // Send original total for reference
                    ]);
                } else {
                    return redirect()->back()->with('message', 'You have already used this coupon!');
                }
            } else {
                return redirect()->back()->with('message', 'Coupon code is expired or not yet valid!');
            }
        }

        return redirect()->back()->with('message', 'Invalid coupon code!');
    }
}
