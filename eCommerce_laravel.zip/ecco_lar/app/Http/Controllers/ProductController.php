<?php

namespace App\Http\Controllers;

use App\Models\Catagory;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        // Fetch products with pagination
        $products = Product::paginate(6); // Adjust the number as per your requirement

        // Return the view with products
        return view('product.index', compact('products')); // Adjust the view name as per your file structure
    }

    public function showByCategory($id)
    {
        // Fetch the category
        $category = Catagory::findOrFail($id);

        // Fetch products belonging to this category
        $products = Product::where('catagory', $category->catagory_name)->paginate(10);

        // Return a view with the products
        return view('product.product_by_category', compact('products', 'category'));
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }
}
