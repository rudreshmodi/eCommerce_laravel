<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="{{ asset('home/css/bootstrap.css') }}" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="{{ asset('home/css/font-awesome.min.css') }}" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="{{ asset('home/css/style.css') }}" rel="stylesheet" />
    <link rel="shortcut icon" href="public/favicon.png" />

    <!-- responsive style -->
    <link href="{{ asset('home/css/responsive.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css"
        integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    @if (session()->has('message'))
    <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert"
        aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
        <div class="d-flex">
            <div class="toast-body toast-body-custom">
                {{ session()->get('message') }}
                <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>
    @endif

    <style>
        .toast {
            background-color: aquamarine;
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            min-width: 300px;
        }

        .toast-body-custom {
            font-size: 16px;
            padding: 15px;
        }

        /* Comment section styles */
        .comment-box {
            background-color: #f8f9fa;
            border: 1px solid #e2e6ea;
            border-radius: 8px;
            transition: 0.3s;
        }

        .comment-box:hover {
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }

        .comment-author {
            color: #007bff;
            font-size: 1.1rem;
        }

        .comment-time {
            color: #6c757d;
            font-size: 0.85rem;
        }

        .reply-box {
            padding-left: 20px;
            border-left: 2px solid #007bff;
            margin-top: 10px;
            background-color: #ffffff;
            border-radius: 8px;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .reply-box {
                padding-left: 10px;
            }
        }
    </style>

    <div class="hero_area">
        <!-- header section starts -->
        @include('home.header')
        <!-- end header section -->
        <!-- slider section -->
        @include('home.slider')
        <!-- end slider section -->
    </div>

    <!-- why section -->
    @include('home.why')
    <!-- end why section -->

    <!-- arrival section -->
    @include('home.new_arival')
    <!-- end arrival section -->

    <div class="container mt-5">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-dark text-white text-center">
                <h5 class="mb-0"><i class="bi bi-chat-left-text"></i> Comments</h5>
            </div>
            <div class="card-body p-4">
                <form action="{{ url('add_comment') }}" method="POST">
                    @csrf
                    <div class="mb-4">
                        <label for="comment" class="form-label fw-bold">Your Comment <span
                                class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text bg-primary text-white">
                                <i class="bi bi-pencil-fill"></i>
                            </span>
                            <textarea class="form-control" id="comment" name="comment" rows="4" placeholder="Write your comment here..."
                                required></textarea>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-4 py-2">
                            <i class="bi bi-send"></i> Submit Comment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="d-flex align-items-center justify-content-center mb-5">
            <h1 class="text-uppercase fw-bold display-6 mb-0" style="letter-spacing: 2px; color: #343a40;">
                <i class="bi bi-chat-dots-fill"></i> All Comments
            </h1>
        </div>

        <!-- Comments Section -->
        @foreach ($comments as $comment)
        <div class="comment-box mb-4 p-4 border rounded shadow-sm">
            <div class="d-flex align-items-center">
                <strong class="comment-author me-2">{{ $comment->name }}</strong>
                <span class="comment-time" data-timestamp="{{ $comment->created_at }}">
                    • Just now
                </span>
            </div>
            <p class="mt-2 mb-3" style="font-size: 1.1rem; line-height: 1.5; color: #495057;">
                {{ $comment->comment }}
            </p>
            <a onclick="reply(this)" data-Commentid="{{ $comment->id }}" href="javascript:void(0);"
                class="text-primary fw-bold" style="text-decoration: none;">
                <i class="bi bi-reply-fill"></i> Reply
            </a>
            @foreach ($reply as $rep)
            @if ($rep->comment_id == $comment->id)
            <div class="reply-box mt-3">
                <strong>{{ $rep->name }}</strong>
                <p>{{ $rep->reply }}</p>
                <a onclick="reply(this)" data-Commentid="{{ $comment->id }}" href="javascript:void(0);"
                    class="text-primary fw-bold" style="text-decoration: none;">
                    <i class="bi bi-reply-fill"></i> Reply
                </a>
            </div>
            @endif
            @endforeach
        </div>
        @endforeach

        <!-- Reply Form (Hidden until Reply is clicked) -->
        <div class="replyDiv" style="display: none;">
            <form action="{{ url('add_reply') }}" method="POST">
                @csrf
                <div class="reply-box mt-3">
                    <input type="text" id="commentId" name="commentId" hidden="">
                    <textarea name="reply" class="form-control mb-2" rows="3" placeholder="Write a reply..."
                        style="resize: none;"></textarea>
                    <button type="submit" class="btn btn-primary btn-sm me-2">
                        <i class="bi bi-send-fill"></i> Submit Reply
                    </button>
                    <a class="btn btn-secondary btn-sm" onclick="reply_close(this)"
                        href="javascript:void(0);">Close</a>
                </div>
            </form>
        </div>

        <hr class="my-4" style="border: 2px solid #6c757d; width: 150px; opacity: 0.7;">
    </div>

    <!-- JavaScript -->
    <script>
        function reply(caller) {
            document.getElementById('commentId').value = $(caller).data('Commentid');
            $('.replyDiv').insertAfter($(caller)).show();
        }

        function reply_close() {
            $('.replyDiv').hide();
        }

        function timeAgo(timestamp) {
            const now = new Date();
            const postedTime = new Date(timestamp);
            const secondsAgo = Math.floor((now - postedTime) / 1000);

            if (secondsAgo < 60) return `${secondsAgo} seconds ago`;
            const minutesAgo = Math.floor(secondsAgo / 60);
            if (minutesAgo < 60) return `${minutesAgo} minutes ago`;
            const hoursAgo = Math.floor(minutesAgo / 60);
            if (hoursAgo < 24) return `${hoursAgo} hours ago`;
            const daysAgo = Math.floor(hoursAgo / 24);
            if (daysAgo < 30) return `${daysAgo} days ago`;
            const monthsAgo = Math.floor(daysAgo / 30);
            if (monthsAgo < 12) return `${monthsAgo} months ago`;
            const yearsAgo = Math.floor(monthsAgo / 12);
            return `${yearsAgo} years ago`;
        }

        function updateTimestamps() {
            const elements = document.querySelectorAll('[data-timestamp]');
            elements.forEach(el => {
                const timestamp = el.getAttribute('data-timestamp');
                el.textContent = `• ${timeAgo(timestamp)}`;
            });
        }

        setInterval(updateTimestamps, 60000);
        updateTimestamps();
    </script>

    <!-- Footer and other includes -->
    @include('home.subscribe')
    @include('home.client')
    @include('home.footer')

    <div class="cpy_">
        <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
        </p>
    </div>

    <!-- JavaScript Files -->
    <script src="{{ asset('home/js/jquery-3.4.1.min.js') }}"></script>
    <script src="{{ asset('home/js/popper.min.js') }}"></script>
    <script src="{{ asset('home/js/bootstrap.js') }}"></script>
    <script src="{{ asset('home/js/custom.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var toastEl = document.getElementById('toastMessage');
            var toast = new bootstrap.Toast(toastEl, {
                delay: 3000
            });
            toast.show();
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function(event) {
            var scrollpos = localStorage.getItem('scrollpos');
            if (scrollpos) window.scrollTo(0, scrollpos);
        });

        window.onbeforeunload = function() {
            localStorage.setItem('scrollpos', window.scrollY);
        };
    </script>
</body>

</html>