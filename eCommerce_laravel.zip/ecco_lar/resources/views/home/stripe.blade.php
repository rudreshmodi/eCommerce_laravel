<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Complete Your Purchase</title>
  <link rel="icon" href="./images/icon.png" type="image/png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      color: #333;
      background-color: #4863A0;
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }

    .payment-container {
      background: white;
      padding: 30px;
      border-radius: 5px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      max-width: 600px;
      width: 100%;
    }

    .form-control {
      border: none;
      border-bottom: 2px solid #3c8dbc;
      font-size: 14px;
      margin-top: -10px;
    }

    h1 {
      color: #3c8dbc;
      margin-bottom: 20px;
      text-align: center;
      font-size: 28px;
      font-weight: 700;
    }

    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 2px;
      margin-bottom: 10px;
    }

    .amount-container {
      background-color: #ffffff;
      padding: 20px 40px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      transition: transform 0.3s;
    }

    .amount-container:hover {
      transform: scale(1.05);
    }

    .amount-text {
      font-size: 2rem;
      color: #007BFF;
      font-weight: bold;
    }

    .amount-label {
      font-size: 1.2rem;
      color: #666;
    }

    .pay {
      background-color: #3c8dbc;
      width: 100px;
      margin: 0px 0px 0px 50%;
      border-radius: 12px;
      color: white;

      font-weight: bold;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .pay:hover {
      background-color: #1397c5;
      transform: translateY(-2px);
    }

    .footer {
      margin-top: 10px;
    }

    .custom-btn {
      background-color: gainsboro;
      border-radius: 30px;
      padding: 10px 20px;
      color: white;
      font-weight: bold;
      text-transform: uppercase;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
    }

    .custom-btn:hover {
      background-color: #0056b3;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
      text-decoration: none;
    }
  </style>
</head>

<body>
  <div class="payment-container">
    <h1>Make a Payment</h1>
    <form method="" action="">
      <!-- Your existing form fields -->
      <div class="form-group">
        <input type="hidden" name="amount">
        <div class="amount-container">
          <p class="amount-label">Total Amount:</p>
          <p class="amount-text">$ {{ number_format($totalprice, 2) }}</p>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="card_holder_name">Cardholder Name<span style="color:red;">*</span></label>
          <input type="text" id="card_holder_name" name="card_holder_name" class="form-control"
            placeholder="Full Name" value=""
            oninput="clearError('card_holder_name');">
          <div class="error-message"></div>
        </div>

        <div class="form-group col-md-6">
          <label for="card_number">Card Number<span style="color:red;">*</span></label>
          <input type="text" id="card_number" name="card_number" class="form-control" maxlength="19"
            placeholder="XXXX XXXX XXXX XXXX" oninput="clearError('card_number'); formatCardNumber(this);">
          <img id="card_type_icon" src="{{asset('home/images/default.png')}}"
            style="width: 30px; float:right; z-index:1000; margin-top:-32px; margin-right:8px;" />
          <div class="error-message"></div>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="expiration_date">Expiration <small>(MM/YYYY)</small><span
              style="color:red;">*</span></label>
          <input type="text" name="expiration_date" class="form-control" placeholder="--/----" maxlength="7"
            value="" oninput="formatExpirationDate(this);">
          <i class="fa-regular fa-clock"
            style="width: 30px; float:right; z-index:1000; margin-top:-25px; margin-right:0px;"></i>
          <div class="error-message"></div>
        </div>

        <div class="form-group col-md-6">
          <label for="cvv">CVV<span style="color:red;">*</span></label>
          <div style="position: relative;">
            <input type="password" id="cvv" name="cvv" class="form-control" maxlength="4" placeholder="XXXX"
              value=""
              oninput="clearError('cvv'); this.value = this.value.replace(/[^0-9]/g, '');">

            <button type="button" id="toggleCVV" onclick="toggleCVVVisibility()"
              style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: none; border: none;">
              <i class="fas fa-eye"></i>
            </button>
          </div>
          <div class="error-message"></div>
        </div>

        <script>
          function toggleCVVVisibility() {
            var cvvField = document.getElementById("cvv");
            var toggleBtn = document.getElementById("toggleCVV");
            var icon = toggleBtn.querySelector("i");

            if (cvvField.type === "password") {
              cvvField.type = "text";
              icon.classList.remove("fa-eye");
              icon.classList.add("fa-eye-slash");
            } else {
              cvvField.type = "password";
              icon.classList.remove("fa-eye-slash");
              icon.classList.add("fa-eye");
            }
          }
        </script>
      </div>
      <!-- <a class="pay btn text-white" value="Pay Now" target="_blank"
                href="https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_xclick&no_note=1&lc=UK&bn=PP-BuyNowBF%3Abtn_buynow_LG.gif%3ANonHostedGuest&first_name=Customer%27s+First+Name&last_name=Customer%27s+Last+Name&payer_email=customer%40example.com&item_number=123456&submit=Submit+Payment&business=user%40example.com&return=http%3A%2F%2Fexample.com%2Fpayment-successful.html&cancel_return=http%3A%2F%2Fexample.com%2Fpayment-cancelled.html&notify_url=http%3A%2F%2Fexample.com%2Fpayments.php&item_name=Test+Item&amount=5&currency_code=GBP">submit</a> -->

      <a href="#" class="btn btn-primary custom-btn">
        <i class="fas fa-arrow-left"></i> Back
      </a>
      <input type="submit" class="pay btn text-white" value="Pay Now">


    </form>
    <div class="footer text-center">
      <p><i class="fas fa-lock"></i> Your information is secure.</p>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    function validateAmount(input) {
      // Validation logic
    }

    function formatCardNumber(input) {
      let value = input.value.replace(/\s+/g, '').replace(/[^0-9]/g, '');
      let formattedValue = '';
      for (let i = 0; i < value.length; i++) {
        if (i > 0 && i % 4 === 0) {
          formattedValue += ' ';
        }
        formattedValue += value[i];
      }
      input.value = formattedValue;

      // Check the card type
      const cardType = detectCardType(value);
      displayCardType(cardType);
    }

    function displayCardType(cardType) {
      const cardIcon = document.getElementById('card_type_icon');
      if (cardType === 'visa') {
        cardIcon.src = "{{asset('home/images/visa.png')}}"; // Replace with actual Visa icon path
      } else if (cardType === 'mastercard') {
        cardIcon.src = "{{asset('home/images/mastercard.png')}}"; // Replace with actual MasterCard icon path
      } else if (cardType === 'amex') {
        cardIcon.src = "{{asset('home/images/amex.png')}}"; // Replace with actual AmEx icon path
      } else {
        cardIcon.src = "{{asset('home/images/default.png')}}"; // Default icon if no type matches
      }
    }

    function detectCardType(cardNumber) {
      const cardNumberClean = cardNumber.replace(/\s+/g, '');
      if (/^4\d{12}(\d{3})?$/.test(cardNumberClean)) {
        return 'visa';
      } else if (/^5[1-5]\d{14}$/.test(cardNumberClean)) {
        return 'mastercard';
      } else if (/^3[47]\d{13}$/.test(cardNumberClean)) {
        return 'amex';
      }
      return null; // No match
    }

    function clearError(field) {
      const errorMessage = document.getElementById(`error-${field}`);
      if (errorMessage) {
        errorMessage.innerHTML = '';
      }
    }

    function formatExpirationDate(input) {
      let value = input.value.replace(/\D/g, '');
      if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 6);
      }
      input.value = value;
    }
  </script>

</body>

</html>