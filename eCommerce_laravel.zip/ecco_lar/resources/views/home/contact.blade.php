<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="{{ asset('home/css/bootstrap.css') }}" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="{{ asset('home/css/font-awesome.min.css') }}" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="{{ asset('home/css/style.css') }}" rel="stylesheet" />
    <!-- responsive style -->
    <link href="{{ asset('home/css/responsive.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css" integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    @if (session()->has('message'))
    <div id="toastMessage" class="toast align-items-center text-bg-primary border-0 toast-custom" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
        <div class="d-flex">
            <div class="toast-body toast-body-custom">
                {{ session()->get('message') }}
                <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>

        </div>
    </div>
    @endif

    <style>
        .toast {

            background-color: aquamarine;
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            min-width: 300px;
        }

        .toast-body-custom {
            font-size: 16px;
            padding: 15px;
        }

        .btn-close-custom {
            color: #fff;
        }
    </style>

    <div class="hero_area">
        <!-- header section strats -->
        @include('home.header')
        <!-- end header section -->
        <div>
            <section class="inner_page_head">
                <div class="container_fuild">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="full">
                                <h3>Contact us</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- end inner page section -->
            <!-- why section -->
            <section class="why_section layout_padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                            <div class="full">
                                <form action="{{url('submit-contact')}}" method="POST">
                                    @csrf
                                    <fieldset>
                                        <!-- Name field -->
                                        <p>Name<span style="color: red;"> *</span></p>
                                        <input type="text" placeholder="Enter your full name" name="name" value="{{ old('name') }}" />
                                        @if($errors->has('name'))
                                        <span style="color: red; margin-top: 0;">{{ $errors->first('name') }}</span>
                                        @endif

                                        <!-- Email field -->
                                        <p>Email<span style="color: red;"> *</span></p>
                                        <input type="email" placeholder="Enter your email address" name="email" value="{{ old('email') }}" />
                                        @if($errors->has('email'))
                                        <span style="color: red;">{{ $errors->first('email') }}</span>
                                        @endif

                                        <!-- Subject field -->
                                        <p>Subject<span style="color: red;"> *</span></p>
                                        <input type="text" placeholder="Enter subject" name="subject" value="{{ old('subject') }}" />
                                        @if($errors->has('subject'))
                                        <span style="color: red;">{{ $errors->first('subject') }}</span>
                                        @endif

                                        <!-- Message field -->
                                        <p>Message<span style="color: red;"> *</span></p>
                                        <textarea name="message" placeholder="Enter your message">{{ old('message') }}</textarea>
                                        @if($errors->has('message'))
                                        <span style="color: red;">{{ $errors->first('message') }}</span>
                                        @endif

                                        <input type="submit" value="Submit" />
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        @include('home.footer')
        <!-- footer end -->
        <div class="cpy_">
            <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>

                Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>

            </p>
        </div>
        <!-- jQery -->
        <script src="{{ asset('home/js/jquery-3.4.1.min.js') }}"></script>
        <!-- popper js -->
        <script src="{{ asset('home/js/popper.min.js') }}"></script>
        <!-- bootstrap js -->
        <script src="{{ asset('home/js/bootstrap.js') }}"></script>
        <!-- custom js -->
        <script src="{{ asset('home/js/custom.js') }}"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var toastEl = document.getElementById('toastMessage');
                var toast = new bootstrap.Toast(toastEl, {
                    delay: 3000 // Show for 5 seconds
                });
                toast.show();
            });
        </script>
</body>

</html>
<!-- mzg7I4i6CiPvEP
rudresh.modi@xceltec.in -->