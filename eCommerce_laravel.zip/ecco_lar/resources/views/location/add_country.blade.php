<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Super Admin Dashboard</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('masteradmin/images/apple-touch-icon.png') }}" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('masteradmin/images/favicon-32x32.png') }}" />
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('masteradmin/images/favicon-16x16.png') }}" />

    <!-- Mobile Specific Metas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <!-- Google Font -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Bootstrap JavaScript (Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/css/styles/core.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/cssstyles/icon-font.min.css') }}" />
    <link rel="stylesheet" type="text/css"
        href="{{ asset('masteradmin/src/plugins/datatables/css/dataTables.bootstrap4.min.css') }}" />
    <link rel="stylesheet" type="text/css"
        href="{{ asset('masteradmin/src/plugins/datatables/css/responsive.bootstrap4.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/css/style.css') }}" />

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
        crossorigin="anonymous"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-GBZ3SGGX85");
    </script>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                "gtm.start": new Date().getTime(),
                event: "gtm.js"
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != "dataLayer" ? "&l=" + l : "";
            j.async = true;
            j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, "script", "dataLayer", "GTM-NXZMQSS");
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- End Google Tag Manager -->
</head>
<style>
    .text-danger {
        color: red;
        /* Change this to whatever color you want */
        display: block;
        /* Ensure it is displayed */
    }

    .switch-container {
        position: relative;
        display: inline-block;
        width: 55px;
        height: 30px;
    }

    .switch-btn {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .switch-label {
        position: absolute;
        cursor: pointer;
        background-color: #ccc;
        border-radius: 40px;
        width: 100%;
        height: 90%;
        transition: background-color 0.4s;
    }

    .switch-label:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        border-radius: 50%;
        background-color: white;
        transition: transform 0.4s;
        transform: translateX(2px);
    }

    .switch-btn:checked+.switch-label {
        background-color: #41ccba;
    }

    .switch-btn:checked+.switch-label:before {
        transform: translateX(28px);
    }

    .action-buttons a {
        margin: 0 5px;
        display: inline-block;
        padding: 8px 12px;
        border-radius: 50px;
        /* Makes buttons more rounded */
        transition: background-color 0.3s, transform 0.2s;
    }

    .action-buttons a:hover {
        transform: scale(1.1);
        /* Grows the button slightly on hover */
        text-decoration: none;
    }

    .btn-action.eye {
        background-color: #007bff;
        /* Blue for view */
        color: white;
    }

    .btn-action.eye:hover {
        background-color: #0056b3;
        /* Darker blue on hover */
    }

    .btn-action.delete {
        background-color: #dc3545;
        /* Red for delete */
        color: white;
    }

    .btn-action.delete:hover {
        background-color: #c82333;
        /* Darker red on hover */
    }

    .btn-action.edit {
        background-color: #ffc107;
        /* Yellow for edit */
        color: white;
    }

    .btn-action.edit:hover {
        background-color: #e0a800;
        /* Darker yellow on hover */
    }

    .btn-submit {
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 15px;
        float: right;
        cursor: pointer;
    }

    .btn-submit:hover {
        background-color: #0056b3;
    }
</style>


<body>
    @include('masteradmin.header')
    @include('masteradmin.sidebar')
    <div class="pd-20 card-box mb-30 " style="margin-left:21%; margin-top:80px;">
        <div class="container mt-5">
            <h2>Add Country</h2>
            <form action="{{ route('store-country') }}" method="POST">
                @csrf
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="country">Country Name <span style="color:red;">*</span></label>
                            <input type="text" name="country" id="country" class="form-control" value="{{ old('country') }}">
                            @error('country')
                            <small class="text-danger error-message mt-1">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="country_code">Country Code <span style="color:red;">*</span></label>
                            <input type="number" name="country_code" id="country_code" class="form-control" value="{{ old('country_code') }}">
                            @error('country_code')
                            <small class="text-danger error-message mt-1">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Add Country</button>
            </form>

            <script>
                $(document).ready(function() {
                    // Hide error messages when typing or changing input
                    $('.form-control').on('keyup change', function() {
                        const errorMessage = $(this).siblings('.error-message');
                        if (errorMessage.length) {
                            errorMessage.hide();
                        }
                    });
                });
            </script>


        </div>
        <!-- Striped table start -->
        <div class="pd-20 card-box mb-30 mt-5">
            <div class="clearfix mb-20">
                <div class="clearfix mb-20 d-flex align-items-center">
                    <i class="fa-solid fa-earth-americas fa-lg" style="color: #74C0FC;"></i>
                    <h4 class="text-blue h4 mb-0 ms-2 ml-2">Country</h4>
                </div>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col"># ID</th>
                        <th scope="col">Country Name</th>
                        <th scope="col">Country Code</th>
                        <th scope="col">Status</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($countries as $country)
                    <tr>
                        <th scope="row">{{ $loop->iteration }}</th>
                        <td>{{ $country->country }}</td>
                        <td>{{ $country->country_code }}</td>
                        <td>
                            <!-- {{ $country->active_deactive ? 'Active' : 'Inactive' }} -->
                            <div class="switch-container">
                                <input type="checkbox" id="switch-btn-{{ $country->id }}" {{ $country->active_deactive ? 'checked' : '' }} class="switch-btn" onchange="toggleStatus({{ $country->id }}, this.checked)" />
                                <label for="switch-btn-{{ $country->id }}" class="switch-label"></label>
                            </div>
                        </td>
                        <script>
                            function toggleStatus(countryId, isActive) {
                                const url = `/countries/${countryId}/toggle`;

                                fetch(url, {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json',
                                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                        },
                                        body: JSON.stringify({
                                            active: isActive
                                        })
                                    })
                                    .then(response => {
                                        if (!response.ok) {
                                            throw new Error('Network response was not ok');
                                        }
                                        return response.json();
                                    })
                                    .then(data => {
                                        console.log('Success:', data);

                                        // Show the modal with the success message
                                        document.getElementById('statusChangeMessage').innerText = `Country status updated to ${data.active ? 'Active' : 'Inactive'}.`;
                                        $('#statusChangeModal').modal('show'); // Show the modal
                                    })
                                    .catch(error => {
                                        console.error('Error:', error);
                                        document.getElementById(`switch-btn-${countryId}`).checked = !isActive; // Revert the checkbox state
                                        // Optionally show an error message
                                        document.getElementById('statusChangeMessage').innerText = 'Failed to update status. Please try again.';
                                        $('#statusChangeModal').modal('show'); // Show the modal
                                    });
                            }
                        </script>
                        <td class="action-buttons">

                            <a class="btn btn-danger delete-btn" data-id="{{ $country->id }}"
                                data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                                <i class="fa-solid fa-trash-can"></i>
                            </a>
                            <a href="{{ url('edit_country',$country->id) }}" class="btn btn-sm btn-warning btn-action edit" title="Edit">
                                <i class="fa-solid fa-edit"></i>
                            </a>
                        </td>

                    </tr>
                    @endforeach
                </tbody>
            </table>

            <pre><code class="xml copy-pre" id="striped-table-code">

        </div>
    </div>
    </div>
    <!-- Striped table End -->
    <!-- Modal for Delete Confirmation -->
    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this state? This action cannot be undone.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="statusChangeModal" tabindex="-1" aria-labelledby="statusChangeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="statusChangeModalLabel">Status Update</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="statusChangeMessage">
                    Status has been updated successfully.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            let userId, currentType, toggleButton;

            $('.btn-toggle').click(function() {
                userId = $(this).data('user-id');
                currentType = $(this).data('user-type');
                toggleButton = $(this);
                $('#confirmToggleModal').modal('show');
            });

            $('#confirmToggleBtn').click(function() {
                var newType = currentType == 1 ? 0 : 1;

                $.ajax({
                    url: '/users/toggle-type/' + userId,
                    method: 'POST',
                    data: {
                        usertype: newType,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.usertype == 1) {
                            toggleButton.prev('.badge').removeClass('badge-secondary').addClass(
                                'badge-success').text('Admin');
                        } else {
                            toggleButton.prev('.badge').removeClass('badge-success').addClass(
                                'badge-secondary').text('User');
                        }
                        toggleButton.data('user-type', response.usertype);
                        $('#confirmToggleModal').modal('hide');
                        location.reload();
                    },
                    error: function(xhr) {
                        alert('An error occurred: ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Toggle submenu on click
            $('.dropdown-toggle').on('click', function() {
                // Close other open submenus
                $('.submenu').not($(this).next()).slideUp();
                // Toggle the current submenu
                $(this).next('.submenu').slideToggle();
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // For description modal
            const buttons = document.querySelectorAll('[data-bs-toggle="modal"]');
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const description = this.getAttribute('data-description');
                    const title = this.closest('tr').querySelector('td:nth-child(2)')
                        .textContent; // Adjust if title position changes

                    document.getElementById('modal-description').textContent = description;
                    document.getElementById('descriptionModalLabel').textContent =
                        `${title} - Description`; // Set the title dynamically
                });
            });

            // For image modal
            const imgButtons = document.querySelectorAll('img[data-bs-toggle="modal"]');
            imgButtons.forEach(img => {
                img.addEventListener('click', function() {
                    const imageUrl = this.getAttribute('data-image');
                    document.getElementById('modal-image').src = imageUrl;
                });
            });
        });



        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.delete-btn');
            let deleteProductId;

            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    deleteProductId = this.getAttribute('data-id');
                });
            });

            document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
                if (deleteProductId) {
                    window.location.href = "{{ url('delete_country') }}/" + deleteProductId;
                }
            });
        });
    </script>
</body>

</html>