<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- Plugin css for this page -->
    <link href="{{ asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">

    <!-- Layout styles -->
    <link href="{{ asset('admin/assets/css/style.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="">
    <link href="{{ asset('admin/assets/images/favicon.png') }}" rel="stylesheet" />

    <style>
        body {
            background-color: #f8f9fa;
            /* Light background for contrast */
        }

        .container {
            margin-top: 100px;
            max-width: 900px;
            /* Adjusted for better spacing */
            height: 480px;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            /* Slightly more rounded corners */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
            color: #007bff;
            text-align: center;
            /* Centered heading */
        }

        .form-group {
            margin-bottom: 20px;
            /* Increased margin for better spacing */
        }

        .text-start {
            text-align: left;
            /* Ensures the text is aligned to the left */
        }


        label {
            color: #333;
            /* Ensure the label color contrasts with the background */
            font-weight: bold;
            /* Optional: make labels bold */
        }


        input[type="text"],
        input[type="number"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            color: black;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s;
        }

        input[readonly] {
            background-color: #e9ecef;
            /* Light background for readonly fields */
            cursor: not-allowed;
            /* Change cursor for readonly fields */
        }

        .success-message {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
            color: #155724;
        }

        .btn-primary {
            margin-right: 10px;
        }

        .btn {
            border-radius: 5px;
            /* Rounded button corners */
        }

        .image-preview {
            max-width: 100px;
            /* Responsive image */
            height: auto;

            /* Maintain aspect ratio */
            border-radius: 5px;
            /* Rounded corners for image */
        }

        .status-text {
            font-size: 1.1rem;
            font-weight: bold;
            text-align: center;
            /* Centered status text */
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        <!-- Sidebar and Header -->
        @include('admin.sidebar')
        @include('admin.header')

        <div class="container">
            <div class="text-start">
                <a href="{{ url('order') }}" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Back
                </a>
                <h2>Order Details</h2>
            </div>

            <div class="row">
                <div class="col-lg-4 form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" placeholder="{{ $details->name }}" required
                        readonly>
                </div>

                <div class="col-lg-4 form-group">
                    <label for="email">Email</label>
                    <input type="text" id="email" name="email" placeholder="{{ $details->email }}" required
                        readonly>
                </div>

                <div class="col-lg-4 form-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" placeholder="{{ $details->phone }}" required
                        readonly>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4 form-group">
                    <label for="product_name">Product Name</label>
                    <input type="text" id="product_name" name="product_name"
                        placeholder="{{ $details->product_title }}" required readonly>
                </div>

                <div class="col-lg-4 form-group">
                    <label for="quantity">Quantity</label>
                    <input type="text" id="quantity" name="quantity" placeholder="{{ $details->quantity }}"
                        required readonly>
                </div>

                <div class="col-lg-4 form-group">
                    <label for="price">Price</label>
                    <input type="text" id="price" name="price" placeholder="{{ $details->price }}" required
                        readonly>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4 form-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" placeholder="{{ $details->address }}" required
                        readonly>
                </div>

                <div class="col-lg-4 form-group">
                    <label for="payment_status">Payment Status</label>
                    <input type="text" id="payment_status" name="payment_status"
                        placeholder="{{ $details->payment_status }}" required readonly>
                </div>

                <div class="col-lg-4 form-group">
                    <label for="delivery_status">Delivery Status</label>
                    <input type="text" id="delivery_status" name="delivery_status"
                        placeholder="{{ $details->delivery_status }}" required readonly>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-lg-4 form-group">
                    <label for="image">Image</label>
                    <img src="/product/{{ $details->image }}" class="image-preview" alt="Product Image">
                </div>

                <div class="col-lg-8 form-group text-center">
                    <label>Actions</label>
                    <div>
                        @if ($details->delivery_status == 'Processing' || $details->delivery_status == 'Pending')
                        <a href="{{ route('order.delivered', $details->id) }}"
                            onclick="return confirm('Are you sure this Product is Delivered?')"
                            class="btn btn-primary">
                            <i class="fa-solid fa-check"></i> Mark as Delivered
                        </a>
                        <a href="{{ url('cancel', $details->id) }}"
                            onclick="return confirm('Are you sure you want to cancel this order?')"
                            class="btn btn-danger">
                            <i class="fa-solid fa-xmark"></i> Cancel Order
                        </a>
                        @endif

                    </div>
                </div>
            </div>
        </div>

        <!-- JS Links -->
        <script src="{{ asset('admin/assets/vendors/js/vendor.bundle.base.js') }}"></script>
        <script src="{{ asset('admin/assets/js/off-canvas.js') }}"></script>
        <script src="{{ asset('admin/assets/js/hoverable-collapse.js') }}"></script>
        <script src="{{ asset('admin/assets/js/misc.js') }}"></script>
        <script src="{{ asset('admin/assets/js/settings.js') }}"></script>
        <script src="{{ asset('admin/assets/js/todolist.js') }}"></script>
        <script src="{{ asset('admin/assets/js/dashboard.js') }}"></script>
    </div>
</body>

</html>