<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- CSS Links -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link href="{{ asset('admin/assets/vendors/jvectormap/jquery-jvectormap.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">


    <!-- Layout styles -->
    <link href="{{ asset('admin/assets/css/style.css') }}" rel="stylesheet" />
    <link href="{{ asset('admin/assets/images/favicon.png') }}" rel="stylesheet" />

    <style>
        body {
            background-color: black;
        }

        .container {
            margin-top: 80px;
            max-width: 900px;
            padding: 20px;
            background-color: #424242;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #007bff;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .text-start {
            text-align: left;
        }

        label {
            color: white;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            transition: border-color 0.3s;
        }

        input:focus,
        select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-submit {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            float: right;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }

        .alert {
            margin-bottom: 20px;
        }

        .error-message {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .image-preview {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
            margin-left: 15px;
        }

        .image-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <div class="container-scroller">
        @include('admin.sidebar')
        @include('admin.header')

        <div class="container">
            @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif

            <div class="text-start">
                <a href="{{ url('show_product') }}" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Back
                </a>
                <h2>{{ isset($product) ? 'Update Product' : 'Add Product' }}</h2>
            </div>

            <form action="{{ isset($product) ? route('update.product', $product->id) : url('/add_product') }}"
                method="POST" enctype="multipart/form-data">

                @csrf
                @if (isset($product))
                @method('PUT')
                @endif
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="title">Product Title:</label>
                        <input id="title" type="text" name="title" placeholder="Title"
                            value="{{ $product->title ?? old('title') }}">
                        @error('title')
                        <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="catagory">Product Category:</label>
                        <select name="catagory" id="catagory">
                            <option value="" selected>Select a Category</option>
                            @foreach ($catagory as $cat)
                            <option value="{{ $cat->catagory_name }}"
                                {{ (isset($product) && $product->catagory == $cat->catagory_name) || old('catagory') == $cat->catagory_name ? 'selected' : '' }}>
                                {{ $cat->catagory_name }}
                            </option>
                            @endforeach
                        </select>
                        @error('catagory')
                        <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="quantity">Product Quantity:</label>
                        <input id="quantity" type="number" min="0" name="quantity" placeholder="Quantity"
                            value="{{ $product->quantity ?? old('quantity') }}">
                        @error('quantity')
                        <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="price">Product Price:</label>
                        <input id="price" type="number" name="price" placeholder="Price"
                            value="{{ $product->price ?? old('price') }}">
                        @error('price')
                        <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="discount_price">Discount Price:</label>
                        <input id="discount_price" type="number" name="discount_price" placeholder="Discount Price"
                            value="{{ $product->discount_price ?? old('discount_price') }}">
                        @error('discount_price')
                        <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 form-group image-container">
                        <label for="image">Product Image:</label>
                        <img src="/product/{{ $product->image }}" style="width:auto;height:100px;"
                            alt="{{ $product->title }}" class="rounded" data-bs-toggle="modal"
                            data-bs-target="#imageModal" data-image="/product/{{ $product->image }}">&nbsp;
                        <input id="image" type="file" name="image" accept="image/*"
                            onchange="previewImage(event)">
                        <img id="imagePreview" class="image-preview"
                            src="{{ isset($product) && $product->image ? asset($product->image) : '#' }}"
                            alt=""
                            style=" display:{{ isset($product) && $product->image ? 'block' : 'none' }};">
                        @error('image')
                        <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Product Description:</label>
                    <textarea id="description" name="description" placeholder="Description">{{ $product->description ?? old('description') }}</textarea>
                    @error('description')
                    <div class="error-message">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group">
                    <input type="submit" value="{{ isset($product) ? 'Update Product' : 'Add Product' }}"
                        class="btn-submit">
                </div>
            </form>
        </div>
    </div>

    <!-- JS Links -->
    <script src="{{ asset('admin/assets/vendors/js/vendor.bundle.base.js') }}"></script>
    <script src="{{ asset('admin/assets/js/off-canvas.js') }}"></script>
    <script src="{{ asset('admin/assets/js/hoverable-collapse.js') }}"></script>
    <script src="{{ asset('admin/assets/js/misc.js') }}"></script>
    <script src="{{ asset('admin/assets/js/settings.js') }}"></script>
    <script src="{{ asset('admin/assets/js/todolist.js') }}"></script>
    <script src="{{ asset('admin/assets/js/dashboard.js') }}"></script>

    <script>
        function previewImage(event) {
            const imagePreview = document.getElementById('imagePreview');
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
            }

            if (file) {
                reader.readAsDataURL(file);
            } else {
                imagePreview.style.display = 'none';
            }
        }
    </script>
</body>

</html>