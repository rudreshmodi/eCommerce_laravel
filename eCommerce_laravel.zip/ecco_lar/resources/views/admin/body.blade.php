   <!-- partial -->
   <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">
   <style>
       .icon-item {
           font-size: 24px;
           color: green;
           /* You can set this color or any other */
       }

       .icon-box-success {
           background-color: #e0ffe0;
           /* Example background for success icon */
           border-radius: 50%;
           display: inline-flex;
           justify-content: center;
           align-items: center;
           width: 40px;
           height: 40px;
       }
   </style>

   <div class="main-panel">
       <div class="content-wrapper">
           <div class="row">
               <div class="col-12 grid-margin stretch-card">
                   <div class="card corona-gradient-card">
                       <div class="card-body py-0 px-0 px-sm-3">
                           <div class="row align-items-center">
                               <div class="col-4 col-sm-3 col-xl-2">
                                   <img src="{{ asset('admin/assets/images/dashboard/Group126@2x.png') }}"
                                       class="gradient-corona-img img-fluid" alt="">
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
           <div class="row">
               <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                   <div class="card">
                       <a href="{{ url('show_product') }}" style="text-decoration: changes in master admin and admin pagenone; color:white;">
                           <div class="card-body">
                               <div class="row">
                                   <div class="col-9">
                                       <div class="d-flex align-items-center align-self-start">
                                           <h3 class="mb-0">{{ $total_product }}</h3>
                                       </div>
                                   </div>
                                   <div class="col-3">
                                       <div class="icon icon-box-success ">
                                           <i class="fa-solid fa-bag-shopping"></i>
                                       </div>
                                   </div>
                               </div>
                               <h6 class="text-muted font-weight-normal">Total Products</h6>
                           </div>
                       </a>
                   </div>
               </div>
               <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                   <div class="card">
                       <a href="{{ url('order') }}" style="text-decoration: none; color:white;">
                           <div class="card-body">
                               <div class="row">
                                   <div class="col-9">
                                       <div class="d-flex align-items-center align-self-start">
                                           <h3 class="mb-0">{{ $total_order }}</h3>
                                       </div>
                                   </div>
                                   <div class="col-3">
                                       <div class="icon icon-box-success">
                                           <i class="fa-solid fa-layer-group"></i>
                                       </div>
                                   </div>
                               </div>
                               <h6 class="text-muted font-weight-normal">Total Orders</h6>
                           </div>
                       </a>
                   </div>
               </div>
               <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                   <div class="card">
                       <a href="{{ url('user') }}" style="text-decoration: none; color:white;">
                           <div class="card-body">
                               <div class="row">
                                   <div class="col-9">
                                       <div class="d-flex align-items-center align-self-start">
                                           <h3 class="mb-0">{{ $total_user }}</h3>
                                       </div>
                                   </div>
                                   <div class="col-3">
                                       <div class="icon icon-box-danger">
                                           <i class="fa-solid fa-users"></i>
                                       </div>
                                   </div>
                               </div>
                               <h6 class="text-muted font-weight-normal">Total Customers</h6>
                           </div>
                       </a>
                   </div>
               </div>
               <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                   <div class="card">
                       <div class="card-body">
                           <div class="row">
                               <div class="col-9">
                                   <div class="d-flex align-items-center align-self-start">
                                       <h3 class="mb-0">$ {{ $total_revenue }}</h3>
                                   </div>
                               </div>
                               <div class="col-3">
                                   <div class="icon icon-box-success ">
                                       <span class="mdi mdi-arrow-top-right icon-item"></span>
                                   </div>
                               </div>
                           </div>
                           <h6 class="text-muted font-weight-normal">Total Revenue</h6>
                       </div>
                   </div>
               </div>

           </div>
           <div class="row">
               <div class="col-sm-4 grid-margin">
                   <div class="card">
                       <div class="card-body">
                           <h5>Order Delivered</h5>
                           <div class="row">
                               <div class="col-8 col-sm-12 col-xl-8 my-auto">
                                   <div class="d-flex d-sm-block d-md-flex align-items-center">
                                       <h2 class="mb-0">{{ $total_delivered }}</h2>
                                   </div>
                               </div>
                               <div class="col-4 col-sm-12 col-xl-4 text-center text-xl-right">
                                   <i class="icon-lg mdi mdi-codepen text-primary ml-auto"></i>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>



               <div class="col-sm-4 grid-margin">
                   <div class="card">
                       <div class="card-body">
                           <h5>Order Processing</h5>
                           <div class="row">
                               <div class="col-8 col-sm-12 col-xl-8 my-auto">
                                   <div class="d-flex d-sm-block d-md-flex align-items-center">
                                       <h2 class="mb-0">{{ $total_processing }}</h2>
                                   </div>
                               </div>
                               <div class="col-4 col-sm-12 col-xl-4 text-center text-xl-right">
                                   <i class="icon-lg mdi mdi-wallet-travel text-danger ml-auto"></i>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <div class="col-sm-4 grid-margin">
                   <div class="card">
                       <div class="card-body">
                           <h5>Total Catagory</h5>
                           <div class="row">
                               <div class="col-8 col-sm-12 col-xl-8 my-auto">
                                   <div class="d-flex d-sm-block d-md-flex align-items-center">
                                       <h2 class="mb-0">{{ $total_catagory }}</h2>
                                   </div>
                               </div>
                               <div class="col-4 col-sm-12 col-xl-4 text-center text-xl-right">
                                   <i class="icon-lg mdi mdi-monitor text-success ml-auto"></i>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>


           <div class="row ">
               <div class="col-12 grid-margin">
                   <div class="card">
                       <div class="card-body">
                           <h4 class="card-title">Order Status</h4>
                           <div class="table-responsive">
                               <table class="table">
                                   <thead>
                                       <tr>
                                           <th style="color:#fff;"> Client Name </th>
                                           <th style="color:#fff;"> Order No </th>
                                           <th style="color:#fff;"> Product Quantity </th>
                                           <th style="color:#fff;"> Product Cost </th>
                                           <th style="color:#fff;"> Payment Mode </th>
                                           <th style="color:#fff;"> Order Date </th>
                                           <th style="color:#fff;"> Payment Status </th>
                                       </tr>
                                   </thead>
                                   <tbody>
                                       @if (isset($orders) && $orders->count())
                                       @foreach ($orders as $order)
                                       <tr>
                                           <td><span class="pl-2">{{ $order->name }}</span></td>
                                           <td>{{ $order->id }}</td>
                                           <td>{{ $order->quantity }}</td>
                                           <td>$ {{ $order->price }}</td>
                                           <td>{{ $order->payment_status }}</td>
                                           <td>{{ $order->created_at }}</td>
                                           <td>
                                               @if ($order->delivery_status === 'delivered')
                                               <div class="badge badge-outline-success">
                                                   {{ $order->delivery_status }}
                                               </div>
                                               @elseif($order->delivery_status === 'Processing')
                                               <div class="badge badge-outline-danger">
                                                   {{ $order->delivery_status }}
                                               </div>
                                               @else
                                               <div class="badge badge-outline-secondary">
                                                   {{ $order->delivery_status }}
                                               </div>
                                               @endif
                                           </td>
                                       </tr>
                                       @endforeach
                                       @else
                                       <tr>
                                           <td colspan="6">No orders found.</td>
                                       </tr>
                                       @endif
                                   </tbody>

                               </table>
                               <div style="padding-top: 20px; text-align: center;">
                                   <div class="mb-3">
                                       Showing {{ $orders->firstItem() }} to {{ $orders->lastItem() }} of
                                       {{ $orders->total() }} results
                                   </div>
                                   <nav aria-label="Page navigation">
                                       <ul class="pagination justify-content-center">
                                           {{ $orders->links('pagination::bootstrap-4') }}
                                       </ul>
                                   </nav>
                               </div>


                           </div>
                       </div>
                   </div>
               </div>
           </div>
           <div class="row">
               <div class="col-md-6 col-xl-4 grid-margin stretch-card">
                   <div class="card">
                       <div class="card-body">
                           <div class="d-flex flex-row justify-content-between">
                               <h4 class="card-title">Contacts</h4>
                               <!-- <p class="text-muted mb-1 small">View all</p> -->
                           </div>
                           <div class="preview-list" style="max-height: 300px; overflow-y: auto;">
                               @foreach ($contacts as $contact)
                               <div class="preview-item border-bottom">
                                   <!-- <div class="preview-thumbnail">
                                       <img src="{{ asset('admin/assets/images/faces/face6.jpg') }}" alt="image" class="rounded-circle" />
                                   </div> -->
                                   <div class="preview-item-content d-flex flex-grow">
                                       <div class="flex-grow">
                                           <div class="d-flex d-md-block d-xl-flex justify-content-between">
                                               <h6 class="preview-subject">{{ $contact->name }}</h6>
                                               <p class="text-muted text-small">{{ $contact->created_at->diffForHumans() }}</p>
                                           </div>
                                           <p class="text-muted">{{ $contact->email }}</p>
                                           <p class="text-muted">{{ $contact->subject }}</p>
                                           <p class="text-muted">{{ $contact->message }}</p>
                                       </div>
                                   </div>
                               </div>
                               @endforeach
                           </div>
                       </div>
                   </div>
               </div>

               <div class="col-md-6 col-xl-4 grid-margin stretch-card">
                   <div class="card">
                       <div class="card-body">
                           <h4 class="card-title">Portfolio Slide</h4>
                           <div class="owl-carousel owl-theme full-width owl-carousel-dash portfolio-carousel" id="owl-carousel-basic">
                               <div class="item">
                                   <img src="{{ asset('admin/assets/images/dashboard/Rectangle.jpg') }}" alt="">
                               </div>
                               <div class="item">
                                   <img src="{{ asset('admin/assets/images/dashboard/Img_5.jpg') }}" alt="">
                               </div>
                               <div class="item">
                                   <img src="{{ asset('admin/assets/images/dashboard/img_6.jpg') }}" alt="">
                               </div>
                           </div>
                           <div class="d-flex py-4">
                               <div class="preview-list w-100">
                                   <div class="preview-item p-0">
                                       <div class="preview-thumbnail">
                                           <img src="{{ asset('admin/assets/images/faces/face12.jpg') }}" class="rounded-circle" alt="">
                                       </div>
                                       <div class="preview-item-content d-flex flex-grow">
                                           <div class="flex-grow">
                                               <div class="d-flex d-md-block d-xl-flex justify-content-between">
                                                   <h6 class="preview-subject">CeeCee Bass</h6>
                                                   <p class="text-muted text-small">4 Hours Ago</p>
                                               </div>
                                               <p class="text-muted">Well, it seems to be working now.</p>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                           </div>
                           <p class="text-muted">Well, it seems to be working now. </p>
                           <div class="progress progress-md portfolio-progress">
                               <div class="progress-bar bg-success" role="progressbar" style="width: 50%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                       </div>
                   </div>
               </div>
               <div class="col-md-12 col-xl-4 grid-margin stretch-card">
                   <div class="card">
                       <div class="card-body">
                           <h4 class="card-title">To do list</h4>
                           <div class="add-items d-flex">
                               <input type="text" class="form-control todo-list-input" placeholder="enter task..">
                               <button class="add btn btn-primary todo-list-add-btn">Add</button>
                           </div>
                           <div class="list-wrapper">
                               <ul class="d-flex flex-column-reverse text-white todo-list todo-list-custom">
                                   <li>
                                       <div class="form-check form-check-primary">
                                           <label class="form-check-label">
                                               <input class="checkbox" type="checkbox"> Create invoice </label>
                                       </div>
                                       <i class="remove mdi mdi-close-box"></i>
                                   </li>
                                   <li>
                                       <div class="form-check form-check-primary">
                                           <label class="form-check-label">
                                               <input class="checkbox" type="checkbox"> Meeting with Alita </label>
                                       </div>
                                       <i class="remove mdi mdi-close-box"></i>
                                   </li>
                                   <li class="completed">
                                       <div class="form-check form-check-primary">
                                           <label class="form-check-label">
                                               <input class="checkbox" type="checkbox" checked> Prepare for presentation </label>
                                       </div>
                                       <i class="remove mdi mdi-close-box"></i>
                                   </li>
                                   <li>
                                       <div class="form-check form-check-primary">
                                           <label class="form-check-label">
                                               <input class="checkbox" type="checkbox"> Plan weekend outing </label>
                                       </div>
                                       <i class="remove mdi mdi-close-box"></i>
                                   </li>
                                   <li>
                                       <div class="form-check form-check-primary">
                                           <label class="form-check-label">
                                               <input class="checkbox" type="checkbox"> Pick up kids from school </label>
                                       </div>
                                       <i class="remove mdi mdi-close-box"></i>
                                   </li>
                               </ul>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
           <div class="row">
               <div class="col-12">
                   <div class="card">
                       <div class="card-body">
                           <h4 class="card-title">Visitors by Countries</h4>
                           <div class="row">
                               <div class="col-md-5">
                                   <div class="table-responsive">
                                       <table class="table">
                                           <tbody>
                                               <tr>
                                                   <td>
                                                       <i class="flag-icon flag-icon-us"></i>
                                                   </td>
                                                   <td>USA</td>
                                                   <td class="text-right"> 1500 </td>
                                                   <td class="text-right font-weight-medium"> 56.35% </td>
                                               </tr>
                                               <tr>
                                                   <td>
                                                       <i class="flag-icon flag-icon-de"></i>
                                                   </td>
                                                   <td>Germany</td>
                                                   <td class="text-right"> 800 </td>
                                                   <td class="text-right font-weight-medium"> 33.25% </td>
                                               </tr>
                                               <tr>
                                                   <td>
                                                       <i class="flag-icon flag-icon-au"></i>
                                                   </td>
                                                   <td>Australia</td>
                                                   <td class="text-right"> 760 </td>
                                                   <td class="text-right font-weight-medium"> 15.45% </td>
                                               </tr>
                                               <tr>
                                                   <td>
                                                       <i class="flag-icon flag-icon-gb"></i>
                                                   </td>
                                                   <td>United Kingdom</td>
                                                   <td class="text-right"> 450 </td>
                                                   <td class="text-right font-weight-medium"> 25.00% </td>
                                               </tr>
                                               <tr>
                                                   <td>
                                                       <i class="flag-icon flag-icon-ro"></i>
                                                   </td>
                                                   <td>Romania</td>
                                                   <td class="text-right"> 620 </td>
                                                   <td class="text-right font-weight-medium"> 10.25% </td>
                                               </tr>
                                               <tr>
                                                   <td>
                                                       <i class="flag-icon flag-icon-br"></i>
                                                   </td>
                                                   <td>Brasil</td>
                                                   <td class="text-right"> 230 </td>
                                                   <td class="text-right font-weight-medium"> 75.00% </td>
                                               </tr>
                                           </tbody>
                                       </table>
                                   </div>
                               </div>
                               <div class="col-md-7">
                                   <div id="audience-map" class="vector-map"></div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
       <!-- content-wrapper ends -->
       <!-- partial:partials/_footer.html -->
       <footer class="footer">
           <div class="d-sm-flex justify-content-center justify-content-sm-between">
               <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright ©
                   bootstrapdash.com 2020</span>
               <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Free <a
                       href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">Bootstrap admin
                       templates</a> from Bootstrapdash.com</span>
           </div>
       </footer>
       <!-- partial -->
   </div>
   <!-- main-panel ends -->
   <script>
       document.addEventListener("DOMContentLoaded", function(event) {
           var scrollpos = localStorage.getItem('scrollpos');
           if (scrollpos) window.scrollTo(0, scrollpos);
       });

       window.onbeforeunload = function(e) {
           localStorage.setItem('scrollpos', window.scrollY);
       };
   </script>