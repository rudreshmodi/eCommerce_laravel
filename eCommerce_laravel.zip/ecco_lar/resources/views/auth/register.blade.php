<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="{{ asset('home/css/bootstrap.css') }}" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="{{ asset('home/css/font-awesome.min.css') }}" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="{{ asset('home/css/style.css') }}" rel="stylesheet" />
    <link rel="shortcut icon" href="public/favicon.png" />
    <!-- responsive style -->
    <link href="{{ asset('home/css/responsive.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        /* Custom styles can be added here */
        .form-input {
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 6px;
            width: 100%;
            transition: border-color 0.3s;
        }

        .form-input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .form-label {
            font-weight: bold;
            margin-bottom: 5px;
            text-align: left;
        }

        .button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .button:hover {
            background-color: #0056b3;
        }

        /* New styles for image input */
        .image-input {
            position: relative;
            display: inline-block;
            width: 100px;
            /* Fixed width for smaller image */
            height: 100px;
            /* Fixed height */
            border-radius: 50%;
            overflow: hidden;
            background-color: #f0f0f0;
            margin: 0 auto;
            /* Center the image input */
        }

        .image-input img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .image-input input {
            position: absolute;
            top: 0;
            left: 0;
            /* Align to left */
            width: 100%;
            height: 100%;
            opacity: 0;
            /* Hide input */
            cursor: pointer;
            /* Pointer on hover */
        }

        .edit-icon {
            position: absolute;
            bottom: 5px;
            right: 8px;
            background: white;
            border-radius: 90%;
            padding: 4px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            /* Pointer on hover */
            font-size: 16px;
            /* Icon size */
        }

        .form-row {
            display: flex;
            flex-wrap: wrap;
            /* Ensures responsiveness on smaller screens */
            justify-content: center;
            /* Center align the form groups */
        }

        .form-group {
            flex: 1;
            /* Grow to fill available space */
            min-width: 250px;
            /* Minimum width for each input */
            margin-right: 10px;
            /* Space between inputs */
            text-align: center;
            /* Center text for labels */
        }

        .form-group:last-child {
            margin-right: 0;
            /* Remove right margin from last item */
        }
    </style>
</head>

<body>

    <x-guest-layout>
        @include('home.header')

        <x-authentication-card class="bg-white shadow-md rounded-lg p-6 max-w-sm mx-auto">
            <h2 class="text-center text-2xl font-semibold text-gray-800 mb-4">{{ __('Create an Account') }}</h2>

            <x-validation-errors class="mb-4" />

            <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">

                @csrf

                <div class="form-row mb-4">
                    <div class="form-group">
                        <div class="image-input">
                            <img src="{{ asset('default.png') }}" id="profilePreview" alt="Profile Image" />
                            <input type="file" id="profile_image" name="profile_image" accept="image/*"
                                onchange="previewImage(event)" required />
                            <span class="edit-icon" title="Edit Profile Image">
                                <i class="fas fa-pencil-alt"></i>
                            </span>
                        </div>
                        <x-label for="profile_image" value="{{ __('Profile Image') }}"
                            class="form-label text-center text-dark" style="font-weight: 900; font-size: 18px;" />
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <x-label for="name" value="{{ __('Name') }}" class="form-label" />
                        <x-input id="name" class="form-input block mt-1" type="text" name="name"
                            :value="old('name')" required autofocus autocomplete="name" />
                    </div>

                    <div class="form-group">
                        <x-label for="email" value="{{ __('Email') }}" class="form-label" />
                        <x-input id="email" class="form-input block" type="email" name="email" :value="old('email')"
                            required autocomplete="username" />
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <x-label for="phone" value="{{ __('Phone') }}" class="form-label" />
                        <x-input id="phone" class="form-input block mt-1" type="number" name="phone"
                            :value="old('phone')" required autocomplete="username" />
                    </div>

                    <div class="form-group">
                        <x-label for="address" value="{{ __('Address') }}" class="form-label" />
                        <x-input id="address" class="form-input block mt-1" type="text" name="address"
                            :value="old('address')" required autocomplete="username" />
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <x-label for="password" value="{{ __('Password') }}" class="form-label" />
                        <x-input id="password" class="form-input block" type="password" name="password" required
                            autocomplete="new-password" />
                    </div>

                    <div class="form-group">
                        <x-label for="password_confirmation" value="{{ __('Confirm Password') }}"
                            class="form-label" />
                        <x-input id="password_confirmation" class="form-input block mt-1" type="password"
                            name="password_confirmation" required autocomplete="new-password" />
                    </div>
                </div>

                @if (Laravel\Jetstream\Jetstream::hasTermsAndPrivacyPolicyFeature())
                    <div class="mt-4">
                        <x-label for="terms" class="flex items-center">
                            <x-checkbox name="terms" id="terms" required />
                            <div class="ml-2">
                                {!! __('I agree to the :terms_of_service and :privacy_policy', [
                                    'terms_of_service' =>
                                        '<a target="_blank" href="' .
                                        route('terms.show') .
                                        '" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">' .
                                        __('Terms of Service') .
                                        '</a>',
                                    'privacy_policy' =>
                                        '<a target="_blank" href="' .
                                        route('policy.show') .
                                        '" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">' .
                                        __('Privacy Policy') .
                                        '</a>',
                                ]) !!}
                            </div>
                        </x-label>
                    </div>
                @endif

                <div class="flex items-center justify-between mt-4">
                    <a class="text-sm text-gray-600 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        href="{{ route('login') }}">
                        {{ __('Already registered?') }}
                    </a>

                    <x-button class="button ms-4">
                        {{ __('Register') }}
                    </x-button>
                </div>
            </form>
        </x-authentication-card>
    </x-guest-layout>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const defaultImage = "{{ asset('default-profile.png') }}"; // Set the default image URL
            const preview = document.getElementById('profilePreview');
            preview.src = defaultImage; // Set the default image on initial load
        });

        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('profilePreview');
            const defaultImage = "{{ asset('default-profile.png') }}"; // Set the default image URL

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            } else {
                // If no file is selected, set the image to default
                preview.src = defaultImage;
            }
        }
    </script>


</body>

</html>
