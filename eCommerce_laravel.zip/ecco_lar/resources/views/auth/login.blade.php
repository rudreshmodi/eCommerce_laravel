<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>Famms - Fashion HTML Template</title>
    <!-- bootstrap core css -->
    <link href="{{ asset('home/css/bootstrap.css') }}" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="{{ asset('home/css/font-awesome.min.css') }}" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="{{ asset('home/css/style.css') }}" rel="stylesheet" />
    <link rel="shortcut icon" href="public/favicon.png" />
    <!-- responsive style -->
    <link href="{{ asset('home/css/responsive.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css"
        integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

    <x-guest-layout>
        <style>
            /* Add your styles here */
        </style>
        @include('home.header')

        <x-authentication-card class="bg-white shadow-md rounded-lg p-6 max-w-sm mx-auto">
            <x-slot name="logo">
                {{-- Uncomment and set your logo here if needed --}}
                {{-- <x-authentication-card-logo /> --}}
            </x-slot>

            <h2 class="text-center text-2xl font-semibold text-gray-800 mb-2">{{ __('Login to Your Account') }}</h2>

            <x-validation-errors class="mb-4" />

            @if (session('status'))
                <div class="mb-4 text-sm text-green-600">
                    {{ session('status') }}
                </div>
            @endif

            <form id="loginForm" method="POST" action="{{ route('login') }}">
                @csrf

                <div>
                    <x-label for="email" value="{{ __('Email') }}" class="font-medium text-gray-700" />
                    <x-input id="email"
                        class="block mt-1 w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200"
                        type="email" name="email" :value="old('email')" required autofocus autocomplete="username"
                        oninput="this.value = this.value.toLowerCase()" /> <!-- Convert input to lowercase -->
                </div>


                <div class="mt-4">
                    <x-label for="password" value="{{ __('Password') }}" class="font-medium text-gray-700" />
                    <x-input id="password"
                        class="block mt-1 w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200"
                        type="password" name="password" required autocomplete="current-password" />
                </div>

                <div class="block mt-4">
                    <label for="remember_me" class="flex items-center">
                        <x-checkbox id="remember_me" name="remember" />
                        <span class="ml-2 text-sm text-gray-600">{{ __('Remember me') }}</span>
                    </label>
                </div>

                <div class="flex items-center justify-between mt-4">
                    @if (Route::has('password.request'))
                        <a class="text-sm text-gray-600 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                            href="{{ route('password.request') }}">
                            {{ __('Forgot your password?') }}
                        </a>
                    @endif

                    <x-button class="bg-indigo-600 text-white hover:bg-indigo-700 rounded-md px-4 py-2">
                        {{ __('Log in') }}
                    </x-button>
                </div>
            </form>
        </x-authentication-card>

    </x-guest-layout>

    <script>
        // Function to set a cookie
        function setCookie(name, value, days) {
            var expires = "";
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = "; expires=" + date.toUTCString();
            }
            document.cookie = name + "=" + (value || "") + expires + "; path=/";
        }

        // Function to get a cookie
        function getCookie(name) {
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        }

        // Function to check cookies and populate the form
        function populateForm() {
            const email = getCookie('email');
            const password = getCookie('password');

            if (email) {
                document.getElementById('email').value = email;
            }

            if (password) {
                document.getElementById('password').value = password;
            }
        }

        // Add event listener for form submission
        document.getElementById('loginForm').onsubmit = function() {
            const rememberMe = document.getElementById('remember_me').checked;

            if (rememberMe) {
                // Set cookies for email and password for 1 day
                setCookie('email', document.getElementById('email').value, 1);
                setCookie('password', document.getElementById('password').value, 1);
            } else {
                // Clear cookies if not remembered
                setCookie('email', '', -1);
                setCookie('password', '', -1);
            }
        };

        // Call the function to populate the form when the page loads
        window.onload = populateForm;
    </script>
</body>

</html>
