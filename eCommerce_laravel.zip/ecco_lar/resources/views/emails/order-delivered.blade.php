<!DOCTYPE html>
<html>

<head>
    <title>Order Delivered</title>
</head>

<body>
    <h1>Your Order #{{ $order->id }} has been Delivered!</h1>
    <p>Thank you for shopping with us!</p>
</body>

</html>