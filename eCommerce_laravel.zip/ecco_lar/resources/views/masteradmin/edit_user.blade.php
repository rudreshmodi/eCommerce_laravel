<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Super Admin Dashboard</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('masteradmin/images/apple-touch-icon.png') }}" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('masteradmin/images/favicon-32x32.png') }}" />
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('masteradmin/images/favicon-16x16.png') }}" />

    <!-- Mobile Specific Metas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <!-- Google Font -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Bootstrap JavaScript (Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/css/styles/core.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/cssstyles/icon-font.min.css') }}" />
    <link rel="stylesheet" type="text/css"
        href="{{ asset('masteradmin/src/plugins/datatables/css/dataTables.bootstrap4.min.css') }}" />
    <link rel="stylesheet" type="text/css"
        href="{{ asset('masteradmin/src/plugins/datatables/css/responsive.bootstrap4.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/css/style.css') }}" />

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
        crossorigin="anonymous"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-GBZ3SGGX85");
    </script>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                "gtm.start": new Date().getTime(),
                event: "gtm.js"
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != "dataLayer" ? "&l=" + l : "";
            j.async = true;
            j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, "script", "dataLayer", "GTM-NXZMQSS");
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- End Google Tag Manager -->
</head>
<style>
    .text-danger {
        color: red;
        /* Change this to whatever color you want */
        display: block;
        /* Ensure it is displayed */
    }

    .btn-submit {
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 15px;
        float: right;
        cursor: pointer;
    }

    .btn-submit:hover {
        background-color: #0056b3;
    }
</style>

<body>
    @include('masteradmin.header')
    @include('masteradmin.sidebar')
    <div class="pd-20 card-box mb-30 " style="margin-left:21%; margin-top:80px;">
        <div class="wizard-content">
            <form action="{{ route('update_user', $user->id) }}" method="POST" class="tab-wizard wizard-circle wizard">
                @csrf
                @method('PUT')
                <h5 class="text-blue ml-4">Personal Info</h5>
                <section>
                    <div class="row ml-4 mt-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Name <span style="color:red;">*</span></label>
                                <input type="text" name="name" value="{{ $user->name }}" class="form-control" />
                                @error('name')
                                <small class="text-danger error-message mt-1">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Email Address <span style="color:red;">*</span></label>
                                <input type="email" name="email" value="{{ $user->email }}" class="form-control" />
                                @error('email')
                                <small class="text-danger error-message mt-1">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="row ml-4">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Phone Number <span style="color:red;">*</span></label>
                                <input type="number" name="phone" value="{{ $user->phone }}" class="form-control" />
                                @error('phone')
                                <small class="text-danger error-message mt-1">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Password</label>
                                <input type="text" name="password" placeholder="Leave blank to keep current password" class="form-control" autocomplete="off" />
                                @error('password')
                                <small class="text-danger error-message mt-1">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="row ml-4">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Select User-Type <span style="color:red;">*</span></label>
                                <select name="usertype" class="custom-select form-control">
                                    <option style="background-color:#a7ccc3;" value="">Select User-Type</option>
                                    <option value="2" {{ $user->usertype == '2' ? 'selected' : '' }}>Super Admin</option>
                                    <option value="1" {{ $user->usertype == '1' ? 'selected' : '' }}>Admin</option>
                                    <option value="0" {{ $user->usertype == '0' ? 'selected' : '' }}>User</option>
                                </select>
                                @error('usertype')
                                <small class="text-danger error-message mt-1">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Address <span style="color:red;">*</span></label>
                                <input value="{{ $user->address }}"
                                    type="text"
                                    name="address"
                                    class="form-control date-picker"
                                    placeholder="Address" />
                                @error('address')
                                <small class="text-danger error-message mt-1">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="row ml-4">
                        <div class="col-md-12 form-group image-container">
                            <label for="image">Product Image <span style="color:red;">*</span></label>
                            <img src="/product/{{ $user->image }}" style="width:auto;height:100px;"
                                alt="{{ $user->title }}" class="rounded" data-bs-toggle="modal"
                                data-bs-target="#imageModal" data-image="/product/{{ $user->image }}">&nbsp;
                            <input id="image" type="file" name="image" accept="image/*"
                                onchange="previewImage(event)">
                            <img id="imagePreview" class="image-preview"
                                src="{{ isset($user) && $user->image ? asset($user->image) : '#' }}"
                                alt=""
                                style="display:{{ isset($user) && $user->image ? 'block' : 'none' }};">
                            @error('image')
                            <div class="error-message">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                </section>
                <div class="form-group">
                    <button class="btn-submit" type="submit">UPDATE</button>
                </div>
            </form>
        </div>
    </div>



    <script>
        $(document).ready(function() {
            let userId, currentType, toggleButton;

            $('.btn-toggle').click(function() {
                userId = $(this).data('user-id');
                currentType = $(this).data('user-type');
                toggleButton = $(this);
                $('#confirmToggleModal').modal('show');
            });

            $('#confirmToggleBtn').click(function() {
                var newType = currentType == 1 ? 0 : 1;

                $.ajax({
                    url: '/users/toggle-type/' + userId,
                    method: 'POST',
                    data: {
                        usertype: newType,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.usertype == 1) {
                            toggleButton.prev('.badge').removeClass('badge-secondary').addClass(
                                'badge-success').text('Admin');
                        } else {
                            toggleButton.prev('.badge').removeClass('badge-success').addClass(
                                'badge-secondary').text('User');
                        }
                        toggleButton.data('user-type', response.usertype);
                        $('#confirmToggleModal').modal('hide');
                        location.reload();
                    },
                    error: function(xhr) {
                        alert('An error occurred: ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Toggle submenu on click
            $('.dropdown-toggle').on('click', function() {
                // Close other open submenus
                $('.submenu').not($(this).next()).slideUp();
                // Toggle the current submenu
                $(this).next('.submenu').slideToggle();
            });
        });
    </script>
</body>

</html>