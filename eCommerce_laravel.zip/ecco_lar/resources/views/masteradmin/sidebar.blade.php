<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Super Admin Dashboard</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('masteradmin/images/apple-touch-icon.png') }}" />
    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="{{ asset('masteradmin/images/favicon-32x32.png') }}" />
    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="{{ asset('masteradmin/images/favicon-16x16.png') }}" />

    <!-- Mobile Specific Metas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <!-- Google Font -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Bootstrap JavaScript (Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/css/styles/core.css') }}" />
    <link
        rel="stylesheet"
        type="text/css"
        href="{{ asset('masteradmin/cssstyles/icon-font.min.css') }}" />
    <link
        rel="stylesheet"
        type="text/css"
        href="{{ asset('masteradmin/src/plugins/datatables/css/dataTables.bootstrap4.min.css') }}" />
    <link
        rel="stylesheet"
        type="text/css"
        href="{{ asset('masteradmin/src/plugins/datatables/css/responsive.bootstrap4.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('masteradmin/css/style.css') }}" />

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script
        async
        src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"></script>
    <script
        async
        src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
        crossorigin="anonymous"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-GBZ3SGGX85");
    </script>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                "gtm.start": new Date().getTime(),
                event: "gtm.js"
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != "dataLayer" ? "&l=" + l : "";
            j.async = true;
            j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, "script", "dataLayer", "GTM-NXZMQSS");
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- End Google Tag Manager -->
</head>
<div class="left-side-bar">
    <div class="brand-logo">
        <a href="{{ url('redirect') }}">
            <img src="{{ asset('masteradmin/images/deskapp-logo.svg') }}" alt="" class="dark-logo" />
            <img
                src="{{ asset('masteradmin/images/deskapp-logo-white.svg') }}"
                alt=""
                class="light-logo" />
        </a>
        <div class="close-sidebar" data-toggle="left-sidebar-close">
            <i class="ion-close-round"></i>
        </div>
    </div>

    <div class="menu-block customscroll">
        <div class="sidebar-menu">
            <ul id="accordion-menu">
                <li>
                    <a href="{{ url('redirect') }}" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-house" style="color: #63bdd4;"></span><span class="mtext">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="{{ url('/admindetails') }}" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-person-gear" style="color: #63bdd4;"></span><span class=" mtext">Admin Details</span>
                    </a>
                </li>
                <li>
                    <a href="{{ url('/userdetails') }}" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-people" style="color: #63bdd4;"></span><span class="mtext">Users Details</span>
                    </a>
                </li>
                <li>
                    <a href="{{ url('/create_new_web') }}" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-calendar4-week" style="color: #63bdd4;"></span><span class="mtext">Create New Web</span>
                    </a>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-geo-alt" style="color: #63bdd4;"></span></span><span class="mtext">Location</span>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="{{ url('/add_country') }}">
                                <i class="fa-solid fa-earth-americas fa-lg mr-2" style="color: #63bdd4;"></i>
                                Country
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('/add_state') }}">
                                <i class="fa-solid fa-flag-usa fa-lg mr-2" style="color: #63bdd4;"></i> State
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('/add_city') }}">
                                <i class="fa-solid fa-tree-city fa-xl mr-2" style="color: #63bdd4;"></i> City
                            </a>
                        </li>
                    </ul>

                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-bug" style="color: #63bdd4;"></span><span class="mtext">Error Pages</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="404.html">404</a></li>
                    </ul>
                </li>

                <li>
                    <a href="chat.html" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-chat-right-dots" style="color: #63bdd4;"></span><span class="mtext">Chat</span>
                    </a>
                </li>
                <li>
                    <a href="invoice.html" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-receipt-cutoff" style="color: #63bdd4;"></span><span class="mtext">Invoice</span>
                    </a>
                </li>
                <li>
                    <div class="dropdown-divider"></div>
                </li>

            </ul>
        </div>
    </div>
</div>
<!-- js -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="{{ asset('masteradmin/scripts/js/core.js') }}"></script>
<script src="{{ asset('masteradmin/scripts/js/script.min.js') }}"></script>
<script src="{{ asset('masteradmin/scripts/js/process.js') }}"></script>
<script src="{{ asset('masteradmin/scripts/js/layout-settings.js') }}"></script>
<script src="{{ asset('masteradmin/src/plugins/apexcharts/apexcharts.min.js') }}"></script>
<script src="{{ asset('masteradmin/js/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('masteradmin/js/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('masteradmin/js/datatables/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('masteradmin/js/datatables/js/responsive.bootstrap4.min.js') }}"></script>
<script src="{{ asset('masteradmin/js/dashboard3.js') }}"></script>

</body>

</html>